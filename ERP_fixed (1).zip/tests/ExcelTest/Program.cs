// هارنس تست ورود اکسل (گروه/کالا/BOM) + تولید فایل‌های نمونه
using Inventory.Application.Common;
using Inventory.Application.DTOs;
using Inventory.Application.Services;
using Inventory.Domain.Enums;
using Inventory.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

var export = new ExcelExportService();
var options = new DbContextOptionsBuilder<AppDbContext>().UseSqlite("Data Source=exceltest.db").Options;
if (File.Exists("exceltest.db")) File.Delete("exceltest.db");
var db = new AppDbContext(options);
db.Database.EnsureCreated();
try { db.Database.ExecuteSqlRaw("CREATE TABLE IF NOT EXISTS AppSettings (Key TEXT NOT NULL PRIMARY KEY, Value TEXT NULL)"); } catch { }

var audit = new AuditService(db);
var importer = new ExcelImportService(db, audit);

int fails = 0;
void Check(string name, bool ok, string detail = "")
{
    Console.WriteLine($"{(ok ? "✅" : "❌")} {name} {(detail == "" ? "" : "— " + detail)}");
    if (!ok) fails++;
}

// ================= فایل‌های نمونه =================
// --- گروه‌ها ---
var groupCols = new List<(string, double)> { ("کد گروه", 12), ("نام گروه", 28), ("گروه والد", 14), ("توضیح", 36), ("فعال", 8) };
string[] G(string c, string t, string p, string d, string a) => new[] { c, t, p, d, a };
var groupRows = new List<string[]>
{
    G("G-01", "مبلمان اداری", "", "گروه اصلی مبلمان", "بله"),
    G("G-02", "میز", "G-01", "", ""),
    G("G-03", "صندلی", "G-01", "", ""),
    G("G-04", "یراق‌آلات", "", "پیچ و مهره و پایه", "بله"),
    G("G-05", "گروه منسوخ", "G-01", "نمونه‌ی گروه غیرفعال", "خیر"),
};
var sampleGroups = export.Build("گروه‌های کالا", groupCols, groupRows);

// --- کالاها ---
var prodCols = new List<(string, double)>
{
    ("کد", 10), ("نام", 30), ("نام لاتین", 16), ("بارکد", 16), ("نوع کالا", 14), ("گروه", 12),
    ("واحد اصلی", 10), ("قیمت خرید", 14), ("قیمت فروش", 14), ("نقطه سفارش", 10), ("حداقل موجودی", 10),
    ("حداکثر موجودی", 10), ("روش ارزشیابی", 14), ("رهگیری سریال", 10), ("رهگیری انقضا", 10), ("رهگیری لوت", 10),
    ("فعال", 8), ("توضیح", 30), ("روش تأمین", 18), ("زمان تحویل (روز)", 10), ("موجودی اطمینان", 10),
    ("سیاست اندازه سفارش", 16), ("تعداد ثابت سفارش", 12), ("حداقل مقدار سفارش", 12), ("درصد ضایعات", 10),
    ("تأمین‌کننده", 18),
};
string[] P(params string[] v) => Enumerable.Range(0, 26).Select(i => i < v.Length ? v[i] : "").ToArray();
var prodRows = new List<string[]>
{
    P("P-1001", "میز اداری چوبی", "Office Desk", "6261234567890", "محصول نهایی", "G-02", "عدد",
        "15000000", "22000000", "5", "2", "20", "میانگین موزون", "خیر", "خیر", "خیر", "بله", "",
        "ساخت داخلی", "7", "2", "مقدار به مقدار", "", "", "10", "V-01"),
    P("P-2001", "صفحه‌ی میز چوبی", "Desk Top", "", "مواد اولیه", "G-02", "عدد",
        "3000000", "", "", "", "50", "", "", "", "", "بله", "",
        "خرید از تأمین‌کننده", "14", "", "مقدار به مقدار", "", "", "", "V-01"),
    P("P-2002", "پایه‌ی میز فلزی", "Desk Leg", "", "مواد اولیه", "G-04", "عدد",
        "450000", "", "", "", "100", "", "", "", "", "بله", "",
        "خرید از تأمین‌کننده", "7", "5", "مقدار به مقدار", "", "40", "", "V-01"),
    P("P-2003", "پیچ و مهره (بسته‌ی ۸تایی)", "Screw Pack", "", "مواد اولیه", "G-04", "بسته",
        "120000", "", "10", "", "200", "", "", "", "", "بله", "",
        "خرید از تأمین‌کننده", "1", "", "تعداد ثابت", "500", "", "", "V-01"),
    P("P-3001", "صندلی مدیریتی", "Manager Chair", "", "محصول نهایی", "G-03", "عدد",
        "8000000", "13500000", "3", "1", "15", "", "", "", "", "بله", "",
        "ساخت داخلی", "10", "3", "مقدار به مقدار", "", "", "5", "V-01"),
};
var sampleProducts = export.Build("کالاها", prodCols, prodRows);

// --- BOM ---
var bomCols = new List<(string, double)> { ("کد محصول", 14), ("کد قطعه", 14), ("مقدار", 12) };
string[] B(string p, string c, string q) => new[] { p, c, q };
var bomRows = new List<string[]>
{
    B("P-1001", "P-2001", "1"),
    B("P-1001", "P-2002", "4"),
    B("P-1001", "P-2003", "2"),
    B("P-3001", "P-2002", "4"),
    B("P-3001", "P-2003", "6"),
};
var sampleBoms = export.Build("BOM", bomCols, bomRows);

// کپی فایل‌های نمونه: wwwroot/samples + ورک‌اسپیس کاربر
string webroot = "/home/user/ERP/Inventory/src/Inventory.Web/wwwroot/samples";
string userdir = "/home/user/نمونه-اکسل";
foreach (var dir in new[] { webroot, userdir }) Directory.CreateDirectory(dir);
File.WriteAllBytes(Path.Combine(webroot, "sample-groups.xlsx"), sampleGroups);
File.WriteAllBytes(Path.Combine(webroot, "sample-products.xlsx"), sampleProducts);
File.WriteAllBytes(Path.Combine(webroot, "sample-boms.xlsx"), sampleBoms);
File.WriteAllBytes(Path.Combine(userdir, "نمونه-ورود-گروه-کالا.xlsx"), sampleGroups);
File.WriteAllBytes(Path.Combine(userdir, "نمونه-ورود-کالا.xlsx"), sampleProducts);
File.WriteAllBytes(Path.Combine(userdir, "نمونه-ورود-BOM.xlsx"), sampleBoms);
Console.WriteLine("📦 نمونه‌ها ذخیره شدند (wwwroot/samples + نمونه-اکسل)");

// ================= ۱) ورود گروه‌ها =================
var r1 = await importer.ImportGroupsAsync(new MemoryStream(sampleGroups), "تستر");
Check("گروه‌ها: موفق", r1.Ok, r1.Message);
Check("گروه‌ها: ۵ جدید، ۰ خطا", r1.Created == 5 && r1.Errors.Count == 0, $"{r1.Created}/{r1.Errors.Count}");

var g1 = await db.ProductGroups.AsNoTracking().FirstAsync(g => g.Code == "G-01");
var g2 = await db.ProductGroups.AsNoTracking().FirstAsync(g => g.Code == "G-02");
var g5 = await db.ProductGroups.AsNoTracking().FirstAsync(g => g.Code == "G-05");
Check("گروه‌ها: والدِ G-02 = G-01 و G-05 غیرفعال", g2.ParentId == g1.Id && g5.IsActive == false);

// ================= ۲) ورود کالاها =================
var r2 = await importer.ImportProductsAsync(new MemoryStream(sampleProducts), "تستر");
Check("کالاها: موفق", r2.Ok, r2.Message);
Check("کالاها: ۵ جدید، ۰ خطا", r2.Created == 5 && r2.Errors.Count == 0, $"{r2.Created}/{r2.Errors.Count}");
Check("کالاها: ۵ هشدار تأمین‌کننده‌ی ناموجود (V-01)", r2.Warnings.Count == 5, $"{r2.Warnings.Count}");

var p1 = await db.Products.AsNoTracking().Include(p => p.Group).FirstAsync(p => p.Code == "P-1001");
var p4 = await db.Products.AsNoTracking().FirstAsync(p => p.Code == "P-2003");
Check("کالا: P-1001 محصول نهایی/ساخت/LT=7/اطمینان=2/ضایعات=۱۰٪",
    p1.Type == ProductType.Finished && p1.Procurement == ProcurementType.Make &&
    p1.LeadTimeDays == 7 && p1.SafetyStock == 2 && p1.ScrapPercent == 10);
Check("کالا: P-1001 گروه G-02 و بارکد عددی سالم",
    p1.Group!.Code == "G-02" && p1.Barcode == "6261234567890", $"{p1.Group.Code} | {p1.Barcode}");
Check("کالا: P-2003 سیاست FOQ=500 و واحد بسته",
    p4.LotSizing == LotSizingPolicy.FixedQty && p4.FixedOrderQty == 500 && p4.MainUnitId == 4);

// ================= ۳) ورود BOM =================
var r3 = await importer.ImportBomsAsync(new MemoryStream(sampleBoms), "تستر");
Check("BOM: موفق", r3.Ok, r3.Message);
Check("BOM: ۲ BOM جدید، ۰ خطا", r3.Created == 2 && r3.Errors.Count == 0, $"{r3.Created}/{r3.Errors.Count}");

var bom1 = await db.Boms.Include(b => b.Lines).AsNoTracking().FirstAsync(b => b.ProductId == p1.Id);
var bomChair = await db.Boms.Include(b => b.Lines).AsNoTracking().FirstAsync(b => b.Product!.Code == "P-3001");
Check("BOM: میز ۳ جزء با مقادیر درست", bom1.Lines.Count == 3 &&
    bom1.Lines.Any(l => l.Quantity == 4m) && bom1.Lines.Any(l => l.Quantity == 2m));
Check("BOM: صندلی ۲ جزء", bomChair.Lines.Count == 2);

// ================= ۴) ورود مجدد = به‌روزرسانی =================
var r4 = await importer.ImportProductsAsync(new MemoryStream(sampleProducts), "تستر");
Check("کالاها دوباره: ۰ جدید، ۵ به‌روزرسانی", r4.Ok && r4.Created == 0 && r4.Updated == 5, $"{r4.Created}/{r4.Updated}");
var r5 = await importer.ImportBomsAsync(new MemoryStream(sampleBoms), "تستر");
Check("BOM دوباره: ۰ جدید، ۲ جایگزین و ردیف‌ها دوبل نشدند",
    r5.Ok && r5.Created == 0 && r5.Updated == 2 &&
    await db.BomLines.CountAsync() == 5, $"lines={await db.BomLines.CountAsync()}");

// ================= ۵) خطای ردیف، ادامه‌ی بقیه =================
var badRows = new List<string[]> { P("P-9999", "کالای بد", "", "", "", "G-99", "عدد"), P("P-9998", "کالای خوب", "", "", "", "G-02", "عدد") };
var badFile = export.Build("کالاها", prodCols, badRows);
var r6 = await importer.ImportProductsAsync(new MemoryStream(badFile), "تستر");
Check("ردیف خطادار: ۱ خطا (گروه ناموجود) ولی ۱ کالا وارد شد",
    r6.Ok && r6.Errors.Count == 1 && r6.Created == 1, $"{r6.Errors.Count}خطا/{r6.Created}جدید");

// ================= ۶) فایل خراب =================
var r7 = await importer.ImportGroupsAsync(new MemoryStream(new byte[] { 1, 2, 3, 4, 5 }), "تستر");
Check("فایل خراب: خطای دوستانه", !r7.Ok && r7.Message.Length > 0, r7.Message);

// ================= ۷) فایل بدون سرستون درست =================
var noHead = export.Build("برگه", new List<(string, double)> { ("ستون۱", 10), ("ستون۲", 10) }, new List<string[]> { new[] { "a", "b" } });
var r8 = await importer.ImportBomsAsync(new MemoryStream(noHead), "تستر");
Check("سرستون نامعتبر: پیام راهنما", !r8.Ok && r8.Message.Contains("ستون‌های الزامی"), r8.Message);

Console.WriteLine(fails == 0 ? "\n🎉 همه‌ی تست‌های اکسل سبز" : $"\n💥 {fails} تست قرمز");
return fails == 0 ? 0 : 1;
