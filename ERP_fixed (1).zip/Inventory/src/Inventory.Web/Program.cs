using System.Security.Claims;
using Inventory.Application.Services;
using Inventory.Infrastructure;
using Inventory.Infrastructure.Persistence;
using Inventory.Web.Components;
using Inventory.Web.Services;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();

// احراز هویت با کوکی
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/login";
        options.Cookie.Name = "inventory.auth";
        options.ExpireTimeSpan = TimeSpan.FromHours(8);
        options.SlidingExpiration = true;
    });
builder.Services.AddAuthorization();
builder.Services.AddCascadingAuthenticationState();
builder.Services.AddHttpContextAccessor();

// لایه‌های برنامه
builder.Services.AddInfrastructure(builder.Configuration);
builder.Services.AddScoped<IGroupsService, GroupsService>();
builder.Services.AddScoped<IUnitsService, UnitsService>();
builder.Services.AddScoped<IWarehousesService, WarehousesService>();
builder.Services.AddScoped<IProductsService, ProductsService>();
builder.Services.AddScoped<IDocumentsService, DocumentsService>();
builder.Services.AddScoped<IDashboardService, DashboardService>();
builder.Services.AddScoped<IAuthService, AuthService>();
builder.Services.AddScoped<IAccountingService, AccountingService>();
builder.Services.AddScoped<IStocktakeService, StocktakeService>();
builder.Services.AddScoped<IReportsService, ReportsService>();
builder.Services.AddScoped<CurrentUserService>();
builder.Services.AddScoped<IAuditService, AuditService>();
builder.Services.AddScoped<IBinsService, BinsService>();
builder.Services.AddScoped<IVendorsService, VendorsService>();
builder.Services.AddScoped<IPurchaseOrdersService, PurchaseOrdersService>();
builder.Services.AddScoped<IPriceChangeService, PriceChangeService>();
builder.Services.AddScoped<IBomService, BomService>();
builder.Services.AddScoped<IQualityService, QualityService>();
builder.Services.AddScoped<IMrpService, MrpService>();
builder.Services.AddScoped<IExcelExportService, ExcelExportService>();
builder.Services.AddScoped<ICustomersService, CustomersService>();
builder.Services.AddScoped<ISettingsService, SettingsService>();
builder.Services.AddScoped<ISalesOrdersService, SalesOrdersService>();
builder.Services.AddScoped<ISalesInvoicesService, SalesInvoicesService>();

var app = builder.Build();

// ایجاد / ارتقای دیتابیس
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    var provider = builder.Configuration["Database:Provider"] ?? "Sqlite";

    if (provider.Equals("SqlServer", StringComparison.OrdinalIgnoreCase))
    {
        // اگر پروژه مایگریشن داشت اعمال کن؛ وگرنه ساخت کامل اسکیما (بدون از دست رفتن داده‌ی موجود)
        var pending = db.Database.GetPendingMigrations().ToList();
        if (pending.Count > 0)
            db.Database.Migrate();
        else
            db.Database.EnsureCreated();

        // خودتعمیر: جدول تنظیمات برای دیتابیس‌های قدیمی
        try
        {
            db.Database.ExecuteSqlRaw(@"IF OBJECT_ID(N'[dbo].[AppSettings]', N'U') IS NULL
                CREATE TABLE [dbo].[AppSettings] ([Key] nvarchar(450) NOT NULL PRIMARY KEY, [Value] nvarchar(max) NULL)");
        }
        catch { }
    }
    else
    {
        db.Database.EnsureCreated();

        // خودتعمیر: جدول تنظیمات برای دیتابیس‌های قدیمی
        try
        {
            db.Database.ExecuteSqlRaw(@"CREATE TABLE IF NOT EXISTS AppSettings (
                Key TEXT NOT NULL PRIMARY KEY,
                Value TEXT NULL)");
        }
        catch { }
    }
}

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
    app.UseHsts();
}

app.UseHttpsRedirection();

app.UseStaticFiles();
app.UseAuthentication();
app.UseAuthorization();
app.UseAntiforgery();

// ورود و خروج (برای فرم ساده‌ی HTML — مسیر مجزا تا با صفحه‌ی Blazor تداخل نکند)
app.MapPost("/login-post", async (HttpContext ctx, IAuthService auth,
    [Microsoft.AspNetCore.Mvc.FromForm] string username,
    [Microsoft.AspNetCore.Mvc.FromForm] string password) =>
{
    var user = await auth.ValidateAsync(username, password);
    if (user is null)
    {
        ctx.Response.Redirect("/login?error=1");
        return;
    }

    var claims = new List<Claim>
    {
        new(ClaimTypes.Name, user.DisplayName),
        new(ClaimTypes.NameIdentifier, user.Username),
        new(ClaimTypes.Role, user.Role.ToString())
    };
    var principal = new ClaimsPrincipal(new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme));
    await ctx.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal);
    ctx.Response.Redirect("/");
}).DisableAntiforgery();

app.MapPost("/logout", async (HttpContext ctx) =>
{
    await ctx.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
    ctx.Response.Redirect("/login");
}).DisableAntiforgery();

app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode();

app.Run();
