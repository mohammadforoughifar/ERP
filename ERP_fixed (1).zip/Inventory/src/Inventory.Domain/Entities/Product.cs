using Inventory.Domain.Enums;

namespace Inventory.Domain.Entities;

/// <summary>کالا</summary>
public class Product
{
    public int Id { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? LatinName { get; set; }
    public string? Barcode { get; set; }
    public ProductType Type { get; set; } = ProductType.Finished;
    public string? Description { get; set; }
    public bool IsActive { get; set; } = true;

    public int GroupId { get; set; }
    public ProductGroup Group { get; set; } = null!;

    /// <summary>واحد اصلی</summary>
    public int MainUnitId { get; set; }
    public Unit MainUnit { get; set; } = null!;

    /// <summary>نقطه‌ی سفارش مجدد (Reorder Point)</summary>
    public decimal ReorderPoint { get; set; }

    /// <summary>حداقل موجودی</summary>
    public decimal MinStock { get; set; }

    /// <summary>حداکثر موجودی</summary>
    public decimal MaxStock { get; set; }

    /// <summary>قیمت خرید پایه</summary>
    public decimal PurchasePrice { get; set; }

    /// <summary>قیمت فروش پایه</summary>
    public decimal SalePrice { get; set; }

    /// <summary>روش ارزشیابی کالا (میانگین موزون / FIFO)</summary>
    public ValuationMethod ValuationMethod { get; set; } = ValuationMethod.Average;

    // ============ امکانات پیشرفته‌ی رهگیری (فاز ۳) ============

    /// <summary>رهگیری شماره سریال یکتا برای هر واحد کالا</summary>
    public bool TrackSerial { get; set; }

    /// <summary>رهگیری تاریخ انقضا (خروج به روش FIFO بر اساس انقضا)</summary>
    public bool TrackExpiry { get; set; }

    /// <summary>رهگیری لوت / بچ (گروه ورود)</summary>
    public bool TrackLot { get; set; }

    public ICollection<WarehouseItem> WarehouseItems { get; set; } = new List<WarehouseItem>();

    /// <summary>ویژگی‌های تکمیلی کالا (رنگ، سایز، وزن، ابعاد، مدل و...)</summary>
    public ICollection<ProductAttributeValue> AttributeValues { get; set; } = new List<ProductAttributeValue>();
}
