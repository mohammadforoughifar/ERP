namespace Inventory.Domain.Enums;

/// <summary>نوع سند انبار</summary>
public enum DocumentType
{
    /// <summary>رسید خرید از تأمین‌کننده</summary>
    PurchaseReceipt = 1,

    /// <summary>رسید برگشت از فروش</summary>
    SalesReturnReceipt = 2,

    /// <summary>رسید تولید</summary>
    ProductionReceipt = 3,

    /// <summary>رسید موجودی اولیه</summary>
    OpeningReceipt = 4,

    /// <summary>رسید انتقال از انبار دیگر</summary>
    TransferReceipt = 5,

    /// <summary>حواله فروش</summary>
    SalesIssue = 10,

    /// <summary>حواله مصرف در تولید</summary>
    ProductionIssue = 11,

    /// <summary>حواله برگشت به تأمین‌کننده</summary>
    PurchaseReturnIssue = 12,

    /// <summary>حواله ضایعات</summary>
    ScrapIssue = 13,

    /// <summary>حواله هدیه و مصارف داخلی</summary>
    InternalUseIssue = 14,

    /// <summary>حواله انتقال به انبار دیگر</summary>
    TransferIssue = 15,

    /// <summary>سند تعدیل موجودی</summary>
    Adjustment = 20,

    /// <summary>سند تعدیل موجودی — مازاد (ورود)</summary>
    AdjustmentReceipt = 21,

    /// <summary>سند تعدیل موجودی — کسری (خروج)</summary>
    AdjustmentIssue = 22,

    /// <summary>ورود کالای امانی (امانت‌گرفته)</summary>
    ConsignmentReceipt = 23,

    /// <summary>خروج کالای امانی (بازپس‌گیری)</summary>
    ConsignmentReturn = 24
}

/// <summary>وضعیت سند انبار</summary>
public enum DocumentStatus
{
    /// <summary>پیش‌نویس — اثری روی موجودی ندارد</summary>
    Draft = 0,

    /// <summary>تأیید و ثبت نهایی — روی موجودی اثر می‌گذارد</summary>
    Confirmed = 1,

    /// <summary>رد شده</summary>
    Rejected = 2
}

/// <summary>نوع کالا</summary>
public enum ProductType
{
    /// <summary>مواد اولیه</summary>
    RawMaterial = 1,

    /// <summary>کالای واسطه</summary>
    SemiFinished = 2,

    /// <summary>محصول نهایی</summary>
    Finished = 3,

    /// <summary>کالای امانی</summary>
    Consignment = 4,

    /// <summary>ضایعات</summary>
    Scrap = 5,

    /// <summary>خدمت (غیرانباری)</summary>
    Service = 6
}

/// <summary>دسته‌ی واحد سنجش</summary>
public enum UnitCategory
{
    /// <summary>عددی</summary>
    Count = 1,

    /// <summary>وزنی</summary>
    Weight = 2,

    /// <summary>طولی</summary>
    Length = 3,

    /// <summary>حجمی</summary>
    Volume = 4,

    /// <summary>سایر</summary>
    Other = 5
}

/// <summary>نقش کاربر در سیستم</summary>
public enum UserRole
{
    /// <summary>مدیر سیستم — دسترسی کامل</summary>
    Admin = 1,

    /// <summary>حسابدار — تأیید اسناد و ثبت حسابداری</summary>
    Accountant = 2,

    /// <summary>انباردار — ثبت اسناد و مدیریت انبار</summary>
    Storekeeper = 3
}

/// <summary>وضعیت برگه‌ی انبارگردانی</summary>
public enum StocktakeStatus
{
    /// <summary>شمارش هنوز ثبت نشده</summary>
    Draft = 0,

    /// <summary>شمارش اول توسط شمارنده ثبت شد</summary>
    Counted = 1,

    /// <summary>شمارش دوم (تأیید) انجام شد — مغایرت‌ها مشخص است</summary>
    Verified = 2,

    /// <summary>سندهای تعدیل صادر و روی موجودی اعمال شد</summary>
    Posted = 3
}

/// <summary>وضعیت ردیف سریال (رهگیری سریال)</summary>
public enum SerialStatus
{
    /// <summary>در انبار موجود است</summary>
    InStock = 0,

    /// <summary>صادر شده (از انبار خارج)</summary>
    Issued = 1
}

/// <summary>روش ارزشیابی کالا</summary>
public enum ValuationMethod
{
    /// <summary>میانگین موزون</summary>
    Average = 1,

    /// <summary>فایفو (خروج از اولین ورودی)</summary>
    Fifo = 2
}

/// <summary>وضعیت سفارش خرید</summary>
public enum PurchaseOrderStatus
{
    /// <summary>پیش‌نویس</summary>
    Draft = 0,

    /// <summary>تأییدشده (در انتظار رسید)</summary>
    Confirmed = 1,

    /// <summary>رسید کامل صادر شد</summary>
    Received = 2,

    /// <summary>لغو شده</summary>
    Cancelled = 3
}

/// <summary>نتیجه‌ی بازرسی کیفیت</summary>
public enum QualityStatus
{
    /// <summary>قبول — ورود به انبار</summary>
    Passed = 1,

    /// <summary>رد — صدور سند برگشت</summary>
    Rejected = 2
}

/// <summary>وضعیت سفارش فروش</summary>
public enum SalesOrderStatus
{
    /// <summary>پیش‌نویس</summary>
    Draft = 0,

    /// <summary>تأییدشده (در انتظار صدور فاکتور)</summary>
    Confirmed = 1,

    /// <summary>فاکتور صادر شد</summary>
    Invoiced = 2,

    /// <summary>لغو شده</summary>
    Cancelled = 3
}
