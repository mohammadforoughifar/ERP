using Inventory.Application.Common;
using Inventory.Domain.Entities;
using Inventory.Domain.Enums;
using Microsoft.EntityFrameworkCore;

namespace Inventory.Infrastructure.Persistence;

public class AppDbContext(DbContextOptions<AppDbContext> options) : DbContext(options), IAppDbContext
{
    public DbSet<ProductGroup> ProductGroups => Set<ProductGroup>();
    public DbSet<Unit> Units => Set<Unit>();
    public DbSet<Warehouse> Warehouses => Set<Warehouse>();
    public DbSet<Product> Products => Set<Product>();
    public DbSet<WarehouseItem> WarehouseItems => Set<WarehouseItem>();
    public DbSet<InventoryDocument> InventoryDocuments => Set<InventoryDocument>();
    public DbSet<InventoryDocumentLine> InventoryDocumentLines => Set<InventoryDocumentLine>();
    public DbSet<AccountingVoucher> AccountingVouchers => Set<AccountingVoucher>();
    public DbSet<AccountingVoucherLine> AccountingVoucherLines => Set<AccountingVoucherLine>();
    public DbSet<AppUser> Users => Set<AppUser>();
    public DbSet<StockBatch> StockBatches => Set<StockBatch>();
    public DbSet<SerialItem> SerialItems => Set<SerialItem>();
    public DbSet<Stocktake> Stocktakes => Set<Stocktake>();
    public DbSet<StocktakeLine> StocktakeLines => Set<StocktakeLine>();
    public void ClearTracker() => ChangeTracker.Clear();

    public DbSet<ProductAttributeDefinition> ProductAttributeDefinitions => Set<ProductAttributeDefinition>();
    public DbSet<ProductAttributeValue> ProductAttributeValues => Set<ProductAttributeValue>();
    public DbSet<StorageBin> StorageBins => Set<StorageBin>();
    public DbSet<BinStock> BinStocks => Set<BinStock>();
    public DbSet<Vendor> Vendors => Set<Vendor>();
    public DbSet<PurchaseOrder> PurchaseOrders => Set<PurchaseOrder>();
    public DbSet<PurchaseOrderLine> PurchaseOrderLines => Set<PurchaseOrderLine>();
    public DbSet<PriceChangeDocument> PriceChangeDocuments => Set<PriceChangeDocument>();
    public DbSet<Bom> Boms => Set<Bom>();
    public DbSet<BomLine> BomLines => Set<BomLine>();
    public DbSet<QualityInspection> QualityInspections => Set<QualityInspection>();
    public DbSet<AuditLog> AuditLogs => Set<AuditLog>();
    public DbSet<Customer> Customers => Set<Customer>();
    public DbSet<SalesOrder> SalesOrders => Set<SalesOrder>();
    public DbSet<SalesOrderLine> SalesOrderLines => Set<SalesOrderLine>();
    public DbSet<SalesInvoice> SalesInvoices => Set<SalesInvoice>();
    public DbSet<SalesInvoiceLine> SalesInvoiceLines => Set<SalesInvoiceLine>();
    public DbSet<AppSetting> AppSettings => Set<AppSetting>();

    protected override void OnModelCreating(ModelBuilder builder)
    {
        builder.Entity<ProductGroup>(e =>
        {
            e.HasKey(x => x.Id);
            e.Property(x => x.Code).HasMaxLength(20).IsRequired();
            e.Property(x => x.Title).HasMaxLength(100).IsRequired();
            e.HasOne(x => x.Parent).WithMany(x => x.Children).HasForeignKey(x => x.ParentId)
                .OnDelete(DeleteBehavior.Restrict);
            e.HasIndex(x => x.Code).IsUnique();
        });

        builder.Entity<Unit>(e =>
        {
            e.HasKey(x => x.Id);
            e.Property(x => x.Title).HasMaxLength(50).IsRequired();
            e.Property(x => x.Factor).HasPrecision(18, 6);
            e.HasOne(x => x.BaseUnit).WithMany().HasForeignKey(x => x.BaseUnitId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        builder.Entity<Warehouse>(e =>
        {
            e.HasKey(x => x.Id);
            e.Property(x => x.Code).HasMaxLength(20).IsRequired();
            e.Property(x => x.Title).HasMaxLength(100).IsRequired();
            e.HasIndex(x => x.Code).IsUnique();
        });

        builder.Entity<Product>(e =>
        {
            e.HasKey(x => x.Id);
            e.Property(x => x.Code).HasMaxLength(30).IsRequired();
            e.Property(x => x.Name).HasMaxLength(200).IsRequired();
            e.Property(x => x.Barcode).HasMaxLength(50);
            e.Property(x => x.PurchasePrice).HasPrecision(18, 2);
            e.Property(x => x.SalePrice).HasPrecision(18, 2);
            e.Property(x => x.ReorderPoint).HasPrecision(18, 3);
            e.Property(x => x.MinStock).HasPrecision(18, 3);
            e.Property(x => x.MaxStock).HasPrecision(18, 3);
            e.HasOne(x => x.Group).WithMany(x => x.Products).HasForeignKey(x => x.GroupId)
                .OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.MainUnit).WithMany().HasForeignKey(x => x.MainUnitId)
                .OnDelete(DeleteBehavior.Restrict);
            e.HasIndex(x => x.Code).IsUnique();
        });

        builder.Entity<WarehouseItem>(e =>
        {
            e.HasKey(x => x.Id);
            e.Property(x => x.Quantity).HasPrecision(18, 3);
            e.Property(x => x.TotalCost).HasPrecision(18, 2);
            e.HasOne(x => x.Warehouse).WithMany(x => x.Items).HasForeignKey(x => x.WarehouseId)
                .OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.Product).WithMany(x => x.WarehouseItems).HasForeignKey(x => x.ProductId)
                .OnDelete(DeleteBehavior.Restrict);
            e.HasIndex(x => new { x.WarehouseId, x.ProductId }).IsUnique();
        });

        builder.Entity<InventoryDocument>(e =>
        {
            e.HasKey(x => x.Id);
            e.Property(x => x.Number).HasMaxLength(30).IsRequired();
            e.Property(x => x.PartyName).HasMaxLength(200);
            e.Property(x => x.Description).HasMaxLength(500);
            e.Property(x => x.CreatedBy).HasMaxLength(100);
            e.Property(x => x.ConfirmedBy).HasMaxLength(100);
            e.HasOne(x => x.Warehouse).WithMany().HasForeignKey(x => x.WarehouseId)
                .OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.DestinationWarehouse).WithMany().HasForeignKey(x => x.DestinationWarehouseId)
                .OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.AccountingVoucher).WithOne().HasForeignKey<InventoryDocument>(x => x.AccountingVoucherId)
                .OnDelete(DeleteBehavior.SetNull);
            e.HasIndex(x => x.Number).IsUnique();
        });

        builder.Entity<AccountingVoucher>(e =>
        {
            e.HasKey(x => x.Id);
            e.Property(x => x.Number).HasMaxLength(30).IsRequired();
            e.Property(x => x.SourceType).HasMaxLength(50);
            e.Property(x => x.Description).HasMaxLength(500);
            e.Property(x => x.CreatedBy).HasMaxLength(100);
            e.HasIndex(x => x.Number).IsUnique();
            e.HasOne(x => x.Source).WithOne(x => x.AccountingVoucher)
                .HasForeignKey<AccountingVoucher>(x => x.SourceId)
                .OnDelete(DeleteBehavior.SetNull);
        });

        builder.Entity<AccountingVoucherLine>(e =>
        {
            e.HasKey(x => x.Id);
            e.Property(x => x.AccountCode).HasMaxLength(20);
            e.Property(x => x.AccountTitle).HasMaxLength(150);
            e.Property(x => x.Debit).HasPrecision(18, 2);
            e.Property(x => x.Credit).HasPrecision(18, 2);
            e.HasOne(x => x.Voucher).WithMany(x => x.Lines).HasForeignKey(x => x.VoucherId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        builder.Entity<StockBatch>(e =>
        {
            e.HasKey(x => x.Id);
            e.Property(x => x.LotNumber).HasMaxLength(60);
            e.Property(x => x.Quantity).HasPrecision(18, 3);
            e.Property(x => x.UnitCost).HasPrecision(18, 2);
            e.HasIndex(x => new { x.ProductId, x.WarehouseId });
            e.HasOne(x => x.Product).WithMany().HasForeignKey(x => x.ProductId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.Warehouse).WithMany().HasForeignKey(x => x.WarehouseId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.Document).WithMany().HasForeignKey(x => x.DocumentId).OnDelete(DeleteBehavior.SetNull);
        });

        builder.Entity<SerialItem>(e =>
        {
            e.HasKey(x => x.Id);
            e.Property(x => x.SerialNumber).HasMaxLength(80);
            e.HasIndex(x => x.SerialNumber).IsUnique();
            e.HasIndex(x => new { x.ProductId, x.WarehouseId });
            e.HasOne(x => x.Product).WithMany().HasForeignKey(x => x.ProductId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.Warehouse).WithMany().HasForeignKey(x => x.WarehouseId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.ReceivedDocument).WithMany().HasForeignKey(x => x.ReceivedDocumentId).OnDelete(DeleteBehavior.SetNull);
            e.HasOne(x => x.IssuedDocument).WithMany().HasForeignKey(x => x.IssuedDocumentId).OnDelete(DeleteBehavior.SetNull);
        });

        builder.Entity<Stocktake>(e =>
        {
            e.HasKey(x => x.Id);
            e.Property(x => x.Number).HasMaxLength(30).IsRequired();
            e.Property(x => x.Description).HasMaxLength(500);
            e.HasIndex(x => x.Number).IsUnique();
            e.HasOne(x => x.Warehouse).WithMany().HasForeignKey(x => x.WarehouseId).OnDelete(DeleteBehavior.Restrict);
        });

        builder.Entity<StocktakeLine>(e =>
        {
            e.HasKey(x => x.Id);
            e.Property(x => x.BookQuantity).HasPrecision(18, 3);
            e.Property(x => x.CountedQuantity).HasPrecision(18, 3);
            e.Property(x => x.CountedQuantity2).HasPrecision(18, 3);
            e.Property(x => x.Reason).HasMaxLength(200);
            e.HasOne(x => x.Stocktake).WithMany(x => x.Lines).HasForeignKey(x => x.StocktakeId)
                .OnDelete(DeleteBehavior.Cascade);
            e.HasOne(x => x.Product).WithMany().HasForeignKey(x => x.ProductId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.AdjustmentDocument).WithMany().HasForeignKey(x => x.AdjustmentDocumentId)
                .OnDelete(DeleteBehavior.SetNull);
        });

        builder.Entity<ProductAttributeDefinition>(e =>
        {
            e.HasKey(x => x.Id);
            e.Property(x => x.Name).HasMaxLength(60).IsRequired();
            e.HasIndex(x => x.Name).IsUnique();
        });

        builder.Entity<ProductAttributeValue>(e =>
        {
            e.HasKey(x => x.Id);
            e.Property(x => x.Value).HasMaxLength(200).IsRequired();
            e.HasIndex(x => new { x.ProductId, x.DefinitionId });
            e.HasOne(x => x.Product).WithMany(x => x.AttributeValues).HasForeignKey(x => x.ProductId)
                .OnDelete(DeleteBehavior.Cascade);
            e.HasOne(x => x.Definition).WithMany(x => x.Values).HasForeignKey(x => x.DefinitionId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        builder.Entity<StorageBin>(e =>
        {
            e.HasKey(x => x.Id);
            e.Property(x => x.Code).HasMaxLength(30).IsRequired();
            e.Property(x => x.Title).HasMaxLength(120);
            e.HasOne(x => x.Warehouse).WithMany().HasForeignKey(x => x.WarehouseId).OnDelete(DeleteBehavior.Restrict);
        });

        builder.Entity<BinStock>(e =>
        {
            e.HasKey(x => x.Id);
            e.Property(x => x.Quantity).HasPrecision(18, 3);
            e.Property(x => x.TotalCost).HasPrecision(18, 2);
            e.HasIndex(x => new { x.BinId, x.ProductId });
            e.HasOne(x => x.Bin).WithMany(x => x.Stocks).HasForeignKey(x => x.BinId).OnDelete(DeleteBehavior.Cascade);
            e.HasOne(x => x.Product).WithMany().HasForeignKey(x => x.ProductId).OnDelete(DeleteBehavior.Restrict);
        });

        builder.Entity<Vendor>(e =>
        {
            e.HasKey(x => x.Id);
            e.Property(x => x.Code).HasMaxLength(20).IsRequired();
            e.Property(x => x.Name).HasMaxLength(150).IsRequired();
            e.Property(x => x.Phone).HasMaxLength(30);
            e.Property(x => x.Address).HasMaxLength(300);
            e.Property(x => x.TaxId).HasMaxLength(30);
            e.HasIndex(x => x.Code).IsUnique();
        });

        builder.Entity<PurchaseOrder>(e =>
        {
            e.HasKey(x => x.Id);
            e.Property(x => x.Number).HasMaxLength(30).IsRequired();
            e.Property(x => x.Description).HasMaxLength(500);
            e.HasIndex(x => x.Number).IsUnique();
            e.HasOne(x => x.Vendor).WithMany().HasForeignKey(x => x.VendorId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.ReceiptDocument).WithOne().HasForeignKey<PurchaseOrder>(x => x.ReceiptDocumentId)
                .OnDelete(DeleteBehavior.SetNull);
            e.HasOne(x => x.Warehouse).WithMany().HasForeignKey(x => x.WarehouseId).OnDelete(DeleteBehavior.Restrict);
        });

        builder.Entity<PurchaseOrderLine>(e =>
        {
            e.HasKey(x => x.Id);
            e.Property(x => x.Quantity).HasPrecision(18, 3);
            e.Property(x => x.UnitPrice).HasPrecision(18, 2);
            e.Property(x => x.ReceivedQuantity).HasPrecision(18, 3);
            e.HasOne(x => x.Order).WithMany(x => x.Lines).HasForeignKey(x => x.OrderId).OnDelete(DeleteBehavior.Cascade);
            e.HasOne(x => x.Product).WithMany().HasForeignKey(x => x.ProductId).OnDelete(DeleteBehavior.Restrict);
        });

        builder.Entity<PriceChangeDocument>(e =>
        {
            e.HasKey(x => x.Id);
            e.Property(x => x.Number).HasMaxLength(30).IsRequired();
            e.Property(x => x.Reason).HasMaxLength(300);
            e.Property(x => x.OldPurchasePrice).HasPrecision(18, 2);
            e.Property(x => x.NewPurchasePrice).HasPrecision(18, 2);
            e.Property(x => x.OldSalePrice).HasPrecision(18, 2);
            e.Property(x => x.NewSalePrice).HasPrecision(18, 2);
            e.HasIndex(x => x.Number).IsUnique();
            e.HasOne(x => x.Product).WithMany().HasForeignKey(x => x.ProductId).OnDelete(DeleteBehavior.Restrict);
        });

        builder.Entity<Bom>(e =>
        {
            e.HasKey(x => x.Id);
            e.Property(x => x.Title).HasMaxLength(150);
            e.HasOne(x => x.Product).WithMany().HasForeignKey(x => x.ProductId).OnDelete(DeleteBehavior.Restrict);
        });

        builder.Entity<BomLine>(e =>
        {
            e.HasKey(x => x.Id);
            e.Property(x => x.Quantity).HasPrecision(18, 3);
            e.HasOne(x => x.Bom).WithMany(x => x.Lines).HasForeignKey(x => x.BomId).OnDelete(DeleteBehavior.Cascade);
            e.HasOne(x => x.ComponentProduct).WithMany().HasForeignKey(x => x.ComponentProductId).OnDelete(DeleteBehavior.Restrict);
        });

        builder.Entity<QualityInspection>(e =>
        {
            e.HasKey(x => x.Id);
            e.Property(x => x.Number).HasMaxLength(30).IsRequired();
            e.Property(x => x.Notes).HasMaxLength(500);
            e.HasIndex(x => x.Number).IsUnique();
            e.HasOne(x => x.Document).WithMany().HasForeignKey(x => x.DocumentId).OnDelete(DeleteBehavior.Restrict);
        });

        builder.Entity<AuditLog>(e =>
        {
            e.HasKey(x => x.Id);
            e.Property(x => x.UserName).HasMaxLength(100);
            e.Property(x => x.Action).HasMaxLength(80);
            e.Property(x => x.EntityType).HasMaxLength(80);
            e.Property(x => x.EntityId).HasMaxLength(50);
            e.Property(x => x.Details).HasMaxLength(2000);
            e.HasIndex(x => new { x.Date, x.EntityType });
        });

        builder.Entity<Customer>(e =>
        {
            e.HasKey(x => x.Id);
            e.Property(x => x.Code).HasMaxLength(20).IsRequired();
            e.Property(x => x.Name).HasMaxLength(150).IsRequired();
            e.Property(x => x.Phone).HasMaxLength(30);
            e.Property(x => x.Address).HasMaxLength(300);
            e.Property(x => x.NationalId).HasMaxLength(20);
            e.HasIndex(x => x.Code).IsUnique();
        });

        builder.Entity<SalesOrder>(e =>
        {
            e.HasKey(x => x.Id);
            e.Property(x => x.Number).HasMaxLength(30).IsRequired();
            e.Property(x => x.Description).HasMaxLength(500);
            e.HasIndex(x => x.Number).IsUnique();
            e.HasOne(x => x.Customer).WithMany().HasForeignKey(x => x.CustomerId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.Warehouse).WithMany().HasForeignKey(x => x.WarehouseId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.IssueDocument).WithOne().HasForeignKey<SalesOrder>(x => x.IssueDocumentId)
                .OnDelete(DeleteBehavior.SetNull);
            e.HasOne(x => x.Invoice).WithOne().HasForeignKey<SalesOrder>(x => x.InvoiceId)
                .OnDelete(DeleteBehavior.SetNull);
        });

        builder.Entity<SalesOrderLine>(e =>
        {
            e.HasKey(x => x.Id);
            e.Property(x => x.Quantity).HasPrecision(18, 3);
            e.Property(x => x.UnitPrice).HasPrecision(18, 2);
            e.HasOne(x => x.Order).WithMany(x => x.Lines).HasForeignKey(x => x.OrderId).OnDelete(DeleteBehavior.Cascade);
            e.HasOne(x => x.Product).WithMany().HasForeignKey(x => x.ProductId).OnDelete(DeleteBehavior.Restrict);
        });

        builder.Entity<SalesInvoice>(e =>
        {
            e.HasKey(x => x.Id);
            e.Property(x => x.Number).HasMaxLength(30).IsRequired();
            e.Property(x => x.Description).HasMaxLength(500);
            e.Property(x => x.DiscountPercent).HasPrecision(18, 2);
            e.Property(x => x.Subtotal).HasPrecision(18, 2);
            e.Property(x => x.DiscountAmount).HasPrecision(18, 2);
            e.Property(x => x.Total).HasPrecision(18, 2);
            e.HasIndex(x => x.Number).IsUnique();
            e.HasOne(x => x.Customer).WithMany().HasForeignKey(x => x.CustomerId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.Order).WithMany().HasForeignKey(x => x.OrderId).OnDelete(DeleteBehavior.SetNull);
            e.HasOne(x => x.IssueDocument).WithOne().HasForeignKey<SalesInvoice>(x => x.IssueDocumentId)
                .OnDelete(DeleteBehavior.SetNull);
            e.HasOne(x => x.ReturnDocument).WithOne().HasForeignKey<SalesInvoice>(x => x.ReturnDocumentId)
                .OnDelete(DeleteBehavior.SetNull);
        });

        builder.Entity<SalesInvoiceLine>(e =>
        {
            e.HasKey(x => x.Id);
            e.Property(x => x.Quantity).HasPrecision(18, 3);
            e.Property(x => x.UnitPrice).HasPrecision(18, 2);
            e.Property(x => x.UnitCost).HasPrecision(18, 2);
            e.HasOne(x => x.Invoice).WithMany(x => x.Lines).HasForeignKey(x => x.InvoiceId).OnDelete(DeleteBehavior.Cascade);
            e.HasOne(x => x.Product).WithMany().HasForeignKey(x => x.ProductId).OnDelete(DeleteBehavior.Restrict);
        });

        builder.Entity<AppUser>(e =>
        {
            e.HasKey(x => x.Id);
            e.Property(x => x.Username).HasMaxLength(50).IsRequired();
            e.Property(x => x.PasswordHash).HasMaxLength(100).IsRequired();
            e.Property(x => x.DisplayName).HasMaxLength(100).IsRequired();
            e.HasIndex(x => x.Username).IsUnique();
        });

        builder.Entity<InventoryDocumentLine>(e =>
        {
            e.HasKey(x => x.Id);
            e.Property(x => x.Quantity).HasPrecision(18, 3);
            e.Property(x => x.UnitPrice).HasPrecision(18, 2);
            e.Property(x => x.UnitCost).HasPrecision(18, 4);
            e.HasOne(x => x.Document).WithMany(x => x.Lines).HasForeignKey(x => x.DocumentId)
                .OnDelete(DeleteBehavior.Cascade);
            e.HasOne(x => x.Product).WithMany().HasForeignKey(x => x.ProductId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        Seed(builder);
    }

    private static void Seed(ModelBuilder b)
    {
        // --- کاربران ---
        b.Entity<Customer>().HasData(
            new Customer { Id = 1, Code = "C-001", Name = "بازرگانی امید", Phone = "021-33445566", Address = "تهران، خیابان ولیعصر", IsActive = true },
            new Customer { Id = 2, Code = "C-002", Name = "فروشگاه مرکزی پاساژ", Phone = "031-77889900", Address = "اصفهان، چهارباغ", IsActive = true });

        b.Entity<Vendor>().HasData(
            new Vendor { Id = 1, Code = "V-001", Name = "صنایع فولاد کویر", Phone = "031-12345678", Address = "اصفهان، شهرک صنعتی", IsActive = true },
            new Vendor { Id = 2, Code = "V-002", Name = "توزیع آریا", Phone = "021-88776655", Address = "تهران، بازار بزرگ", IsActive = true },
            new Vendor { Id = 3, Code = "V-003", Name = "پخش پارس کالا", Phone = "021-44556677", Address = "تهران، جاده مخصوص", IsActive = true });

        b.Entity<StorageBin>().HasData(
            new StorageBin { Id = 1, WarehouseId = 1, Code = "A1-01", Title = "قفسه شرقی - ردیف ۱", IsActive = true },
            new StorageBin { Id = 2, WarehouseId = 1, Code = "A1-02", Title = "قفسه شرقی - ردیف ۲", IsActive = true },
            new StorageBin { Id = 3, WarehouseId = 2, Code = "B1-01", Title = "قفسه غربی - ردیف ۱", IsActive = true },
            new StorageBin { Id = 4, WarehouseId = 3, Code = "C1-01", Title = "سالن مواد - ردیف ۱", IsActive = true });

        b.Entity<ProductAttributeDefinition>().HasData(
            new ProductAttributeDefinition { Id = 1, Name = "رنگ", IsActive = true },
            new ProductAttributeDefinition { Id = 2, Name = "سایز", IsActive = true },
            new ProductAttributeDefinition { Id = 3, Name = "وزن", IsActive = true },
            new ProductAttributeDefinition { Id = 4, Name = "ابعاد", IsActive = true },
            new ProductAttributeDefinition { Id = 5, Name = "مدل", IsActive = true },
            new ProductAttributeDefinition { Id = 6, Name = "جنس", IsActive = true },
            new ProductAttributeDefinition { Id = 7, Name = "کشور سازنده", IsActive = true },
            new ProductAttributeDefinition { Id = 8, Name = "گارانتی", IsActive = true });

        b.Entity<AppUser>().HasData(
            new AppUser { Id = 1, Username = "admin", PasswordHash = "240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9", DisplayName = "مدیر سیستم", Role = UserRole.Admin },
            new AppUser { Id = 2, Username = "acc", PasswordHash = "2159157cf71913278f89c4a16bd7462481e41463ea0f8444523cd1c6887d1e4e", DisplayName = "حسابدار", Role = UserRole.Accountant },
            new AppUser { Id = 3, Username = "store", PasswordHash = "8b3d9bca7c134a9190277204379941460eb33c39868309401f02fa8e0391d4a7", DisplayName = "انباردار", Role = UserRole.Storekeeper }
        );

        // --- گروه‌ها ---
        b.Entity<ProductGroup>().HasData(
            new ProductGroup { Id = 1, Code = "01", Title = "مواد اولیه", Description = "مواد خام مصرفی در تولید" },
            new ProductGroup { Id = 2, Code = "02", Title = "لوازم یدکی", Description = "قطعات یدکی ماشین‌آلات" },
            new ProductGroup { Id = 3, Code = "03", Title = "محصول نهایی", Description = "محصولات آماده فروش" },
            new ProductGroup { Id = 4, Code = "04", Title = "ملزومات اداری", Description = "لوازم مصرفی دفتر" }
        );

        // --- واحدها ---
        b.Entity<Unit>().HasData(
            new Unit { Id = 1, Title = "عدد", Category = UnitCategory.Count },
            new Unit { Id = 2, Title = "کیلوگرم", Category = UnitCategory.Weight },
            new Unit { Id = 3, Title = "کارتن", Category = UnitCategory.Count, BaseUnitId = 1, Factor = 24 },
            new Unit { Id = 4, Title = "بسته", Category = UnitCategory.Count, BaseUnitId = 1, Factor = 10 },
            new Unit { Id = 5, Title = "متر", Category = UnitCategory.Length },
            new Unit { Id = 6, Title = "لیتر", Category = UnitCategory.Volume }
        );

        // --- انبارها ---
        b.Entity<Warehouse>().HasData(
            new Warehouse { Id = 1, Code = "W1", Title = "انبار مرکزی", ManagerName = "علی رضایی", Address = "شهرک صنعتی، خیابان اول", Phone = "021-12345678" },
            new Warehouse { Id = 2, Code = "W2", Title = "انبار مواد اولیه", ManagerName = "مریم احمدی", Address = "سالن تولید" },
            new Warehouse { Id = 3, Code = "W3", Title = "انبار موقت", ManagerName = "حسین کریمی" }
        );

        // --- کالاها ---
        b.Entity<Product>().HasData(
            new Product { Id = 1, Code = "RM-001", Name = "ورق فولادی ۲ میلی‌متر", LatinName = "Steel Sheet 2mm", Type = ProductType.RawMaterial, GroupId = 1, MainUnitId = 2, ReorderPoint = 500, MinStock = 200, MaxStock = 5000, PurchasePrice = 85000, SalePrice = 95000 },
            new Product { Id = 2, Code = "RM-002", Name = "پروفیل آلومینیوم", Type = ProductType.RawMaterial, GroupId = 1, MainUnitId = 5, ReorderPoint = 300, MinStock = 100, MaxStock = 3000, PurchasePrice = 120000, SalePrice = 135000 },
            new Product { Id = 3, Code = "PR-001", Name = "محصول نهایی مدل A", Type = ProductType.Finished, GroupId = 3, MainUnitId = 1, ReorderPoint = 50, MinStock = 20, MaxStock = 500, PurchasePrice = 450000, SalePrice = 550000 },
            new Product { Id = 4, Code = "SP-001", Name = "بلبرینگ صنعتی ۶۲۰۴", Type = ProductType.SemiFinished, GroupId = 2, MainUnitId = 1, ReorderPoint = 100, MinStock = 50, MaxStock = 1000, PurchasePrice = 180000, SalePrice = 220000 },
            new Product { Id = 5, Code = "OF-001", Name = "کاغذ A4 (بسته ۵۰۰ برگ)", Type = ProductType.Finished, GroupId = 4, MainUnitId = 4, ReorderPoint = 20, MinStock = 10, MaxStock = 200, PurchasePrice = 280000, SalePrice = 350000 },
            new Product { Id = 6, Code = "PR-002", Name = "محصول نهایی مدل B", Type = ProductType.Finished, GroupId = 3, MainUnitId = 1, ReorderPoint = 40, MinStock = 15, MaxStock = 400, PurchasePrice = 620000, SalePrice = 750000 }
        );

        // --- موجودی اولیه ---
        b.Entity<WarehouseItem>().HasData(
            new WarehouseItem { Id = 1, WarehouseId = 1, ProductId = 1, Quantity = 1200, TotalCost = 98_000_000 },
            new WarehouseItem { Id = 2, WarehouseId = 2, ProductId = 2, Quantity = 800, TotalCost = 92_000_000 },
            new WarehouseItem { Id = 3, WarehouseId = 1, ProductId = 3, Quantity = 120, TotalCost = 52_000_000 },
            new WarehouseItem { Id = 4, WarehouseId = 1, ProductId = 4, Quantity = 250, TotalCost = 42_000_000 },
            new WarehouseItem { Id = 5, WarehouseId = 3, ProductId = 5, Quantity = 45, TotalCost = 12_000_000 },
            new WarehouseItem { Id = 6, WarehouseId = 1, ProductId = 6, Quantity = 60, TotalCost = 36_000_000 },
            new WarehouseItem { Id = 7, WarehouseId = 2, ProductId = 1, Quantity = 400, TotalCost = 33_000_000 }
        );

        // --- اسناد نمونه ---
        var d1 = DateTime.Now.AddDays(-6);
        var d2 = DateTime.Now.AddDays(-4);
        var d3 = DateTime.Now.AddDays(-2);
        var d4 = DateTime.Now.AddDays(-1);

        b.Entity<InventoryDocument>().HasData(
            new InventoryDocument { Id = 1, Number = $"{DateTime.Now.Year}-0001", Type = DocumentType.OpeningReceipt, Status = DocumentStatus.Confirmed, Date = d1, WarehouseId = 1, PartyName = "موجودی اولیه", Description = "موجودی افتتاحیه‌ی سال", CreatedBy = "مدیر سیستم", ConfirmedBy = "مدیر سیستم", ConfirmedAt = d1, CreatedAt = d1 },
            new InventoryDocument { Id = 2, Number = $"{DateTime.Now.Year}-0002", Type = DocumentType.PurchaseReceipt, Status = DocumentStatus.Confirmed, Date = d2, WarehouseId = 2, PartyName = "شرکت فولاد البرز", Description = "خرید ورق فولادی", CreatedBy = "مدیر سیستم", ConfirmedBy = "مدیر سیستم", ConfirmedAt = d2, CreatedAt = d2 },
            new InventoryDocument { Id = 3, Number = $"{DateTime.Now.Year}-0003", Type = DocumentType.SalesIssue, Status = DocumentStatus.Confirmed, Date = d3, WarehouseId = 1, PartyName = "فروشگاه صنعت پارس", Description = "فروش محصول نهایی", CreatedBy = "مدیر سیستم", ConfirmedBy = "مدیر سیستم", ConfirmedAt = d3, CreatedAt = d3 },
            new InventoryDocument { Id = 4, Number = $"{DateTime.Now.Year}-0004", Type = DocumentType.ScrapIssue, Status = DocumentStatus.Draft, Date = d4, WarehouseId = 1, PartyName = "", Description = "ضایعات تولید — در انتظار تأیید", CreatedBy = "انباردار", CreatedAt = d4 }
        );

        b.Entity<InventoryDocumentLine>().HasData(
            new InventoryDocumentLine { Id = 1, DocumentId = 1, ProductId = 1, Quantity = 1200, UnitPrice = 85000, UnitCost = 81666.6667m },
            new InventoryDocumentLine { Id = 2, DocumentId = 1, ProductId = 3, Quantity = 120, UnitPrice = 450000, UnitCost = 433333.3333m },
            new InventoryDocumentLine { Id = 3, DocumentId = 1, ProductId = 4, Quantity = 250, UnitPrice = 180000, UnitCost = 168000m },
            new InventoryDocumentLine { Id = 4, DocumentId = 1, ProductId = 6, Quantity = 60, UnitPrice = 620000, UnitCost = 600000m },
            new InventoryDocumentLine { Id = 5, DocumentId = 2, ProductId = 1, Quantity = 400, UnitPrice = 82500, UnitCost = 82500m },
            new InventoryDocumentLine { Id = 6, DocumentId = 2, ProductId = 2, Quantity = 800, UnitPrice = 115000, UnitCost = 115000m },
            new InventoryDocumentLine { Id = 7, DocumentId = 3, ProductId = 3, Quantity = 10, UnitPrice = 550000, UnitCost = 433333.3333m },
            new InventoryDocumentLine { Id = 8, DocumentId = 4, ProductId = 1, Quantity = 5, UnitPrice = 0, UnitCost = 0 }
        );
    }
}
