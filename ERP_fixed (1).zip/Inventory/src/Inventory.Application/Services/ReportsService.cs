using Inventory.Application.Common;
using Inventory.Application.DTOs;
using Inventory.Domain.Entities;
using Inventory.Domain.Enums;
using Microsoft.EntityFrameworkCore;

namespace Inventory.Application.Services;

public interface IReportsService
{
    Task<List<ReorderItemDto>> GetReorderAsync();
    Task<List<StaleItemDto>> GetStaleAsync(int months);
    Task<List<StockAgeDto>> GetStockAgeAsync();
    Task<List<TopSellerDto>> GetTopSellersAsync(DateTime from, DateTime to, int take = 10);
    Task<List<MovementDto>> GetMovementsAsync(DateTime from, DateTime to);
    Task<List<ExpiryItemDto>> GetExpiringAsync(int days);
    Task<List<StaffPerformanceDto>> GetStaffPerformanceAsync();
    Task<List<ConsignmentItemDto>> GetConsignmentBalanceAsync();
}

/// <summary>گزارش‌های تحلیلی فاز ۳ — نقطه سفارش، راکد، سن موجودی، پرفروش‌ها، گردش، انقضا، عملکرد، امانی</summary>
public class ReportsService(IAppDbContext db) : IReportsService
{
    /// <summary>کالاهای زیر نقطه‌ی سفارش</summary>
    public async Task<List<ReorderItemDto>> GetReorderAsync()
    {
        var items = await db.Products.AsNoTracking()
            .Include(p => p.Group)
            .Include(p => p.MainUnit)
            .Include(p => p.WarehouseItems)
            .Where(p => p.IsActive && p.ReorderPoint > 0)
            .ToListAsync();

        return items
            .Where(p => p.WarehouseItems.Sum(w => w.Quantity) <= p.ReorderPoint)
            .Select(p => new ReorderItemDto(p.Id, p.Code, p.Name, p.Group.Title, p.MainUnit.Title,
                p.WarehouseItems.Sum(w => w.Quantity), p.ReorderPoint))
            .OrderBy(r => r.Stock / (r.ReorderPoint > 0 ? r.ReorderPoint : 1))
            .ToList();
    }

    /// <summary>کالاهای راکد — بدون گردش در N ماه گذشته</summary>
    public async Task<List<StaleItemDto>> GetStaleAsync(int months)
    {
        var since = DateTime.Now.AddMonths(-months);
        var products = await db.Products.AsNoTracking()
            .Include(p => p.MainUnit)
            .Include(p => p.WarehouseItems)
            .Where(p => p.IsActive)
            .ToListAsync();

        var movedProductIds = await db.InventoryDocumentLines.AsNoTracking()
            .Where(l => l.Document.Status == DocumentStatus.Confirmed && l.Document.Date >= since)
            .Select(l => l.ProductId)
            .Distinct()
            .ToListAsync();

        var lastMovements = await db.InventoryDocumentLines.AsNoTracking()
            .Where(l => l.Document.Status == DocumentStatus.Confirmed)
            .GroupBy(l => l.ProductId)
            .Select(g => new { ProductId = g.Key, Last = g.Max(l => l.Document.Date) })
            .ToListAsync();

        var lastMap = lastMovements.ToDictionary(x => x.ProductId, x => x.Last);
        var movedSet = movedProductIds.ToHashSet();

        return products
            .Where(p => !movedSet.Contains(p.Id) && p.WarehouseItems.Sum(w => w.Quantity) > 0)
            .Select(p => new StaleItemDto(p.Id, p.Code, p.Name, p.MainUnit.Title,
                p.WarehouseItems.Sum(w => w.Quantity),
                lastMap.TryGetValue(p.Id, out var last) ? last.ToFa() : null,
                lastMap.TryGetValue(p.Id, out var last2)
                    ? Math.Max(0, (int)(DateTime.Now - last2).TotalDays / 30)
                    : months))
            .OrderByDescending(s => s.MonthsWithoutMovement)
            .ToList();
    }

    /// <summary>سن موجودی — قدیمی‌ترین لوت هر کالا/انبار</summary>
    public async Task<List<StockAgeDto>> GetStockAgeAsync()
    {
        var batches = await db.StockBatches.AsNoTracking()
            .Include(b => b.Product).ThenInclude(p => p.MainUnit)
            .Include(b => b.Warehouse)
            .Where(b => b.Quantity > 0)
            .ToListAsync();

        return batches
            .GroupBy(b => new { b.ProductId, b.WarehouseId })
            .Select(g => new StockAgeDto(
                g.Key.ProductId,
                g.First().Product.Code,
                g.First().Product.Name,
                g.First().Warehouse.Title,
                g.First().Product.MainUnit.Title,
                g.Sum(b => b.Quantity),
                g.Min(b => b.ReceivedAt).ToFa(),
                (int)(DateTime.Now - g.Min(b => b.ReceivedAt)).TotalDays))
            .OrderByDescending(a => a.AgeDays)
            .ToList();
    }

    /// <summary>پرفروش‌ترین کالاها در بازه — بر اساس حواله‌های خروج تأییدشده</summary>
    public async Task<List<TopSellerDto>> GetTopSellersAsync(DateTime from, DateTime to, int take = 10)
    {
        var lines = await db.InventoryDocumentLines.AsNoTracking()
            .Include(l => l.Product).ThenInclude(p => p.MainUnit)
            .Include(l => l.Document)
            .Where(l => l.Document.Status == DocumentStatus.Confirmed &&
                        l.Document.Type != DocumentType.PurchaseReceipt &&
                        l.Document.Type != DocumentType.SalesReturnReceipt &&
                        l.Document.Type != DocumentType.ProductionReceipt &&
                        l.Document.Type != DocumentType.OpeningReceipt &&
                        l.Document.Type != DocumentType.TransferReceipt &&
                        l.Document.Type != DocumentType.TransferIssue &&
                        l.Document.Type != DocumentType.AdjustmentReceipt &&
                        l.Document.Type != DocumentType.ConsignmentReceipt &&
                        l.Document.Date >= from && l.Document.Date <= to)
            .ToListAsync();

        return lines
            .GroupBy(l => l.ProductId)
            .Select(g => new TopSellerDto(
                g.First().Product.Code, g.First().Product.Name, g.First().Product.MainUnit.Title,
                g.Sum(l => l.Quantity), g.Sum(l => l.Quantity * l.UnitCost), g.Count()))
            .OrderByDescending(t => t.Quantity)
            .Take(take)
            .ToList();
    }

    /// <summary>گردش کالا در بازه — ورود/خروج هر کالا</summary>
    public async Task<List<MovementDto>> GetMovementsAsync(DateTime from, DateTime to)
    {
        var lines = await db.InventoryDocumentLines.AsNoTracking()
            .Include(l => l.Product).ThenInclude(p => p.MainUnit)
            .Include(l => l.Document)
            .Where(l => l.Document.Status == DocumentStatus.Confirmed &&
                        l.Document.Type != DocumentType.TransferReceipt &&
                        l.Document.Type != DocumentType.TransferIssue &&
                        l.Document.Date >= from && l.Document.Date <= to)
            .ToListAsync();

        return lines
            .GroupBy(l => l.ProductId)
            .Select(g =>
            {
                var receipts = g.Where(l =>
                    l.Document.Type == DocumentType.PurchaseReceipt ||
                    l.Document.Type == DocumentType.SalesReturnReceipt ||
                    l.Document.Type == DocumentType.ProductionReceipt ||
                    l.Document.Type == DocumentType.OpeningReceipt ||
                    l.Document.Type == DocumentType.AdjustmentReceipt ||
                    l.Document.Type == DocumentType.ConsignmentReceipt).ToList();
                var issues = g.Where(l =>
                    l.Document.Type == DocumentType.SalesIssue ||
                    l.Document.Type == DocumentType.ProductionIssue ||
                    l.Document.Type == DocumentType.PurchaseReturnIssue ||
                    l.Document.Type == DocumentType.ScrapIssue ||
                    l.Document.Type == DocumentType.InternalUseIssue ||
                    l.Document.Type == DocumentType.AdjustmentIssue ||
                    l.Document.Type == DocumentType.ConsignmentReturn).ToList();
                return new MovementDto(
                    g.Key,
                    g.First().Product.Code, g.First().Product.Name, g.First().Product.MainUnit.Title,
                    receipts.Sum(l => l.Quantity), issues.Sum(l => l.Quantity),
                    receipts.Sum(l => l.Quantity) - issues.Sum(l => l.Quantity),
                    receipts.Sum(l => l.Quantity * l.UnitCost), issues.Sum(l => l.Quantity * l.UnitCost));
            })
            .OrderBy(m => m.Code)
            .ToList();
    }

    /// <summary>کالاهای رو به انقضا — لوت‌هایی که تا N روز دیگر منقضی می‌شوند</summary>
    public async Task<List<ExpiryItemDto>> GetExpiringAsync(int days)
    {
        var today = DateTime.Today;
        var horizon = today.AddDays(days);

        var batches = await db.StockBatches.AsNoTracking()
            .Include(b => b.Product).ThenInclude(p => p.MainUnit)
            .Include(b => b.Warehouse)
            .Where(b => b.Quantity > 0 && b.ExpiryDate != null &&
                        b.ExpiryDate >= today && b.ExpiryDate <= horizon)
            .OrderBy(b => b.ExpiryDate)
            .ToListAsync();

        return batches.Select(b => new ExpiryItemDto(
            b.LotNumber, b.Product.Code, b.Product.Name, b.Warehouse.Title,
            b.ExpiryDate!.Value.ToFa(), (int)(b.ExpiryDate!.Value.Date - today).TotalDays,
            b.Quantity, b.Product.MainUnit.Title)).ToList();
    }

    /// <summary>عملکرد کاربران — تعداد اسناد به تفکیک وضعیت</summary>
    public async Task<List<StaffPerformanceDto>> GetStaffPerformanceAsync()
    {
        var docs = await db.InventoryDocuments.AsNoTracking()
            .ToListAsync();

        return docs
            .GroupBy(d => d.CreatedBy)
            .Select(g => new StaffPerformanceDto(
                g.Key,
                g.Count(),
                g.Count(d => d.Status == DocumentStatus.Draft),
                g.Count(d => d.Status == DocumentStatus.Confirmed),
                g.Count(d => d.Status == DocumentStatus.Rejected)))
            .OrderByDescending(s => s.Total)
            .ToList();
    }

    /// <summary>موجودی کالای امانی — کالاهای امانت‌گرفته (ورود امانی منهای بازپس‌گیری)</summary>
    public async Task<List<ConsignmentItemDto>> GetConsignmentBalanceAsync()
    {
        var docs = await db.InventoryDocuments.AsNoTracking()
            .Include(d => d.Warehouse)
            .Include(d => d.Lines).ThenInclude(l => l.Product).ThenInclude(p => p.MainUnit)
            .Where(d => d.Status == DocumentStatus.Confirmed &&
                        (d.Type == DocumentType.ConsignmentReceipt || d.Type == DocumentType.ConsignmentReturn))
            .ToListAsync();

        var rows = new List<ConsignmentItemDto>();
        foreach (var doc in docs)
        {
            var sign = doc.Type == DocumentType.ConsignmentReceipt ? +1 : -1;
            foreach (var line in doc.Lines)
            {
                rows.Add(new ConsignmentItemDto(
                    line.Product.Code, line.Product.Name, line.Product.MainUnit.Title,
                    doc.PartyName, doc.Warehouse?.Title ?? "—",
                    line.Quantity * sign, line.Quantity * sign * line.UnitCost));
            }
        }

        return rows
            .GroupBy(r => new { r.ProductCode, r.PartyName, r.WarehouseTitle })
            .Select(g => new ConsignmentItemDto(
                g.Key.ProductCode, g.First().ProductName, g.First().UnitTitle, g.Key.PartyName,
                g.Key.WarehouseTitle, g.Sum(r => r.Quantity), g.Sum(r => r.Value)))
            .Where(c => Math.Abs(c.Quantity) > 0.001m)
            .OrderBy(c => c.ProductCode)
            .ToList();
    }
}
