using Inventory.Application.Common;
using Inventory.Application.DTOs;
using Inventory.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace Inventory.Application.Services;

public interface IProductsService
{
    Task<List<ProductListItemDto>> GetListAsync(string? search, int? groupId, int? warehouseId);
    Task<ProductListItemDto?> GetByBarcodeAsync(string barcode);
    Task<ProductDto?> GetAsync(int id);
    Task<CheckResult> CreateAsync(Product product);
    Task<CheckResult> UpdateAsync(Product product);
    Task<CheckResult> DeleteAsync(int id);
    Task<List<ProductAttributeDefinitionDto>> GetAttributeDefinitionsAsync();
    Task<List<FifoLayerDto>> GetFifoLayersAsync(int? productId, int? warehouseId);
    Task<CheckResult> SaveAttributeValuesAsync(int productId, List<ProductAttributeDto> attributes);
}

public class ProductsService(IAppDbContext db) : IProductsService
{
    public async Task<List<ProductListItemDto>> GetListAsync(string? search, int? groupId, int? warehouseId)
    {
        IQueryable<Product> query = db.Products.AsNoTracking()
            .Include(p => p.Group)
            .Include(p => p.MainUnit)
            .Include(p => p.WarehouseItems)
            .Include(p => p.AttributeValues).ThenInclude(v => v.Definition);

        if (!string.IsNullOrWhiteSpace(search))
        {
            var s = search.Trim();
            query = query.Where(p => p.Name.Contains(s) || p.Code.Contains(s) || (p.Barcode != null && p.Barcode.Contains(s)));
        }

        if (groupId is > 0)
            query = query.Where(p => p.GroupId == groupId);

        var items = await query
            .OrderBy(p => p.Code)
            .ToListAsync();

        return items.Select(p =>
        {
            var stocks = p.WarehouseItems
                .Where(w => warehouseId == null || w.WarehouseId == warehouseId)
                .ToList();
            var qty = stocks.Sum(s => s.Quantity);
            var cost = stocks.Sum(s => s.TotalCost);

            return new ProductListItemDto(
                p.Id, p.Code, p.Name, p.Barcode, p.Type.Title(), p.Group.Title,
                p.MainUnit.Title,
                p.ReorderPoint,
                qty, cost,
                qty > 0 ? Math.Round(cost / qty, 4) : 0,
                p.PurchasePrice, p.SalePrice, p.IsActive,
                p.TrackSerial, p.TrackExpiry, p.TrackLot,
                p.AttributeValues
                    .Select(v => $"{v.Definition.Name}: {v.Value}")
                    .ToList(),
                p.ValuationMethod);
        }).ToList();
    }

    public async Task<ProductDto?> GetAsync(int id)
    {
        var p = await db.Products.AsNoTracking()
            .Include(p => p.Group)
            .Include(p => p.MainUnit)
            .Include(p => p.AttributeValues).ThenInclude(v => v.Definition)
            .FirstOrDefaultAsync(p => p.Id == id);
        if (p is null) return null;

        return new ProductDto(
            p.Id, p.Code, p.Name, p.LatinName, p.Barcode, p.Type, p.Type.Title(),
            p.GroupId, p.Group.Title, p.MainUnitId, p.MainUnit.Title,
            p.ReorderPoint, p.MinStock, p.MaxStock,
            p.PurchasePrice, p.SalePrice, p.IsActive, p.Description,
            p.TrackSerial, p.TrackExpiry, p.TrackLot)
        {
            ValuationMethod = p.ValuationMethod,
            Attributes = p.AttributeValues
                .Select(v => new ProductAttributeDto
                {
                    DefinitionId = v.DefinitionId,
                    Name = v.Definition.Name,
                    Value = v.Value
                })
                .OrderBy(a => a.Name)
                .ToList()
        };
    }

    public async Task<ProductListItemDto?> GetByBarcodeAsync(string barcode)
    {
        var p = await db.Products.AsNoTracking()
            .Include(p => p.Group)
            .Include(p => p.MainUnit)
            .Include(p => p.WarehouseItems)
            .FirstOrDefaultAsync(p => p.Barcode != null && p.Barcode == barcode);
        if (p is null) return null;

        var totalQty = p.WarehouseItems.Sum(w => w.Quantity);
        return new ProductListItemDto(
            p.Id, p.Code, p.Name, p.Barcode, p.Type.Title(), p.Group.Title, p.MainUnit.Title,
            p.ReorderPoint, totalQty, p.WarehouseItems.Sum(w => w.TotalCost),
            totalQty > 0 ? p.WarehouseItems.Sum(w => w.TotalCost) / totalQty : 0,
            p.PurchasePrice, p.SalePrice, p.IsActive,
            p.TrackSerial, p.TrackExpiry, p.TrackLot, null, p.ValuationMethod);
    }

    /// <summary>لایه‌های باز FIFO (بسته‌های ورودی تأییدشده با مانده‌ی مثبت)</summary>
    public async Task<List<FifoLayerDto>> GetFifoLayersAsync(int? productId, int? warehouseId)
    {
        var query = db.StockBatches.AsNoTracking()
            .Include(b => b.Product).ThenInclude(p => p.MainUnit)
            .Include(b => b.Warehouse)
            .Where(b => b.Quantity > 0)
            .AsQueryable();
        if (productId is > 0) query = query.Where(b => b.ProductId == productId);
        if (warehouseId is > 0) query = query.Where(b => b.WarehouseId == warehouseId);

        return await query.OrderBy(b => b.Product.Code).ThenBy(b => b.ReceivedAt)
            .Select(b => new FifoLayerDto(
                b.ProductId, b.Product.Code, b.Product.Name, b.Warehouse.Title,
                b.LotNumber, b.ExpiryDate != null ? b.ExpiryDate.Value.ToFa() : null,
                b.Quantity, b.UnitCost))
            .ToListAsync();
    }

    public async Task<List<ProductAttributeDefinitionDto>> GetAttributeDefinitionsAsync() =>
        await db.ProductAttributeDefinitions.AsNoTracking()
            .Where(d => d.IsActive)
            .OrderBy(d => d.Name)
            .Select(d => new ProductAttributeDefinitionDto(d.Id, d.Name))
            .ToListAsync();

    /// <summary>ذخیره‌ی ویژگی‌های کالا — جایگزینی کامل (حذف قبلی‌ها + درج جدید)</summary>
    public async Task<CheckResult> SaveAttributeValuesAsync(int productId, List<ProductAttributeDto> attributes)
    {
        if (await db.Products.AnyAsync(p => p.Id == productId) is false)
            return new CheckResult(false, "کالا یافت نشد.");

        var valid = attributes
            .Where(a => a.DefinitionId > 0 && !string.IsNullOrWhiteSpace(a.Value))
            .ToList();

        // یکتا بودن تعریف‌ها
        if (valid.Select(a => a.DefinitionId).Distinct().Count() != valid.Count)
            return new CheckResult(false, "هر ویژگی فقط یک بار قابل ثبت است.");

        var existing = await db.ProductAttributeValues
            .Where(v => v.ProductId == productId)
            .ToListAsync();
        db.ProductAttributeValues.RemoveRange(existing);

        foreach (var a in valid)
        {
            db.ProductAttributeValues.Add(new ProductAttributeValue
            {
                ProductId = productId,
                DefinitionId = a.DefinitionId,
                Value = a.Value.Trim()
            });
        }

        await db.SaveChangesAsync();
        return new CheckResult(true, $"ویژگی‌ها ذخیره شد ({valid.Count} مورد).");
    }

    public async Task<CheckResult> CreateAsync(Product product)
    {
        if (string.IsNullOrWhiteSpace(product.Code) || string.IsNullOrWhiteSpace(product.Name))
            return new CheckResult(false, "کد و نام کالا الزامی است.");
        if (product.MainUnitId <= 0)
            return new CheckResult(false, "واحد اصلی کالا را انتخاب کنید.");
        if (await db.Products.AnyAsync(p => p.Code == product.Code))
            return new CheckResult(false, "این کد کالا قبلاً ثبت شده است.");

        db.Products.Add(product);
        await db.SaveChangesAsync();
        return new CheckResult(true, "کالا با موفقیت ثبت شد.");
    }

    public async Task<CheckResult> UpdateAsync(Product product)
    {
        var existing = await db.Products.FindAsync(product.Id);
        if (existing is null) return new CheckResult(false, "کالا یافت نشد.");
        if (await db.Products.AnyAsync(p => p.Code == product.Code && p.Id != product.Id))
            return new CheckResult(false, "این کد کالا قبلاً ثبت شده است.");

        existing.Code = product.Code;
        existing.Name = product.Name;
        existing.LatinName = product.LatinName;
        existing.Barcode = product.Barcode;
        existing.Type = product.Type;
        existing.GroupId = product.GroupId;
        existing.MainUnitId = product.MainUnitId;
        existing.ReorderPoint = product.ReorderPoint;
        existing.MinStock = product.MinStock;
        existing.MaxStock = product.MaxStock;
        existing.PurchasePrice = product.PurchasePrice;
        existing.SalePrice = product.SalePrice;
        existing.IsActive = product.IsActive;
        existing.Description = product.Description;

        await db.SaveChangesAsync();
        return new CheckResult(true, "کالا با موفقیت ویرایش شد.");
    }

    public async Task<CheckResult> DeleteAsync(int id)
    {
        if (await db.InventoryDocumentLines.AnyAsync(l => l.ProductId == id))
            return new CheckResult(false, "برای این کالا سند صادر شده است و قابل حذف نیست.");

        var product = await db.Products.FindAsync(id);
        if (product is null) return new CheckResult(false, "کالا یافت نشد.");

        db.Products.Remove(product);
        await db.SaveChangesAsync();
        return new CheckResult(true, "کالا حذف شد.");
    }
}
