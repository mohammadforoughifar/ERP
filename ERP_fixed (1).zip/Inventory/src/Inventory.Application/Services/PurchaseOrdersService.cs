using Inventory.Application.Common;
using Inventory.Application.DTOs;
using Inventory.Domain.Entities;
using Inventory.Domain.Enums;
using Microsoft.EntityFrameworkCore;

namespace Inventory.Application.Services;

public interface IPurchaseOrdersService
{
    Task<List<PurchaseOrderDto>> GetListAsync();
    Task<PurchaseOrderDto?> GetAsync(int id);
    Task<CheckResult> CreateAsync(PurchaseOrder order, string? user);
    Task<CheckResult> ConfirmAsync(int id, string? user);
    Task<CheckResult> ReceiveAsync(int id, decimal discount, string? user);
    Task<CheckResult> CancelAsync(int id, string? user);
    Task<CheckResult> DeleteAsync(int id, string? user);
}

/// <summary>سفارش خرید — از پیش‌نویس تا تأیید و صدور رسید</summary>
public class PurchaseOrdersService(IAppDbContext db, IDocumentsService documents, IAuditService audit) : IPurchaseOrdersService
{
    public async Task<List<PurchaseOrderDto>> GetListAsync()
    {
        var orders = await db.PurchaseOrders.AsNoTracking()
            .Include(o => o.Vendor).Include(o => o.Lines).ThenInclude(l => l.Product)
            .OrderByDescending(o => o.Date).ThenByDescending(o => o.Id)
            .ToListAsync();

        return orders.Select(o => new PurchaseOrderDto
        {
            Id = o.Id,
            Number = o.Number,
            Date = o.Date,
            DateFa = o.Date.ToFa(),
            VendorId = o.VendorId,
            VendorName = o.Vendor.Name,
            Status = o.Status,
            StatusTitle = o.Status switch
            {
                PurchaseOrderStatus.Draft => "پیش‌نویس",
                PurchaseOrderStatus.Confirmed => "تأییدشده",
                PurchaseOrderStatus.Received => "رسیدشده",
                _ => "لغو شده"
            },
            Description = o.Description,
            CreatedBy = o.CreatedBy,
            CreatedAt = o.CreatedAt,
            TotalQuantity = o.Lines.Sum(l => l.Quantity),
            TotalAmount = o.Lines.Sum(l => l.Total),
            ReceiptDocumentId = o.ReceiptDocumentId,
            Lines = o.Lines.Select(l => new PurchaseOrderLineDto(l.Id, l.ProductId,
                l.Product.Code, l.Product.Name, l.Product.MainUnit.Title,
                l.Quantity, l.UnitPrice, l.ReceivedQuantity, l.Total)).ToList()
        }).ToList();
    }

    public async Task<PurchaseOrderDto?> GetAsync(int id)
    {
        var all = await GetListAsync();
        return all.FirstOrDefault(o => o.Id == id);
    }

    public async Task<CheckResult> CreateAsync(PurchaseOrder order, string? user)
    {
        if (order.VendorId <= 0) return new CheckResult(false, "انتخاب تأمین‌کننده الزامی است.");
        if (order.Lines.Count == 0 || order.Lines.All(l => l.Quantity <= 0))
            return new CheckResult(false, "حداقل یک ردیف با مقدار معتبر وارد کنید.");

        var next = await db.PurchaseOrders.CountAsync();
        order.Number = $"PO-{DateTime.Now:yyyyMMdd}-{next + 1:000}";
        order.Status = PurchaseOrderStatus.Draft;
        order.CreatedBy = user ?? "سیستم";
        order.CreatedAt = DateTime.Now;
        order.Lines = order.Lines.Where(l => l.Quantity > 0).ToList();

        db.PurchaseOrders.Add(order);
        await db.SaveChangesAsync();
        await audit.LogAsync(user, "ایجاد", "سفارش خرید", order.Id.ToString(),
            $"شماره {order.Number} — تأمین‌کننده {order.VendorId} — {order.Lines.Count} ردیف");
        return new CheckResult(true, $"سفارش {order.Number} ثبت شد.");
    }

    public async Task<CheckResult> ConfirmAsync(int id, string? user)
    {
        var order = await db.PurchaseOrders.Include(o => o.Lines).FirstOrDefaultAsync(o => o.Id == id);
        if (order is null) return new CheckResult(false, "سفارش یافت نشد.");
        if (order.Status is PurchaseOrderStatus.Cancelled or PurchaseOrderStatus.Received)
            return new CheckResult(false, "این سفارش قابل تأیید نیست.");

        order.Status = PurchaseOrderStatus.Confirmed;
        order.ConfirmedAt = DateTime.Now;
        await db.SaveChangesAsync();
        await audit.LogAsync(user, "تأیید", "سفارش خرید", id.ToString(), $"شماره {order.Number}");
        return new CheckResult(true, "سفارش تأیید شد.");
    }

    public async Task<CheckResult> ReceiveAsync(int id, decimal discount, string? user)
    {
        var order = await db.PurchaseOrders.Include(o => o.Vendor).Include(o => o.Lines).ThenInclude(l => l.Product)
            .FirstOrDefaultAsync(o => o.Id == id);
        if (order is null) return new CheckResult(false, "سفارش یافت نشد.");
        if (order.Status != PurchaseOrderStatus.Confirmed)
            return new CheckResult(false, "فقط سفارش‌های تأییدشده قابل رسید هستند.");
        if (order.ReceiptDocumentId is not null)
            return new CheckResult(false, "برای این سفارش قبلاً رسید صادر شده است.");

        // ۱) ساخت سند ورود (رسید خرید) از روی سفارش
        var doc = new InventoryDocument
        {
            Number = await documents.GenerateNumberAsync(DocumentType.PurchaseReceipt),
            Date = DateTime.Now,
            Type = DocumentType.PurchaseReceipt,
            PartyName = order.Vendor.Name,
            Description = $"رسید سفارش خرید {order.Number}",
            CreatedBy = user ?? "سیستم",
            CreatedAt = DateTime.Now
        };
        doc.WarehouseId = order.WarehouseId ?? await db.Warehouses.AsNoTracking()
            .OrderBy(w => w.Id).Select(w => (int?)w.Id).FirstOrDefaultAsync();
        var lines = new List<DocumentLineDto>();
        foreach (var line in order.Lines)
            lines.Add(new DocumentLineDto(0, line.ProductId, "", "", "", line.Quantity, line.UnitPrice, 0, 0,
                LotNumber: line.Product.TrackLot ? line.Quantity.ToString("0.###") : null,
                ExpiryDateFa: line.Product.TrackExpiry ? DateTime.Now.AddMonths(6).ToFa() : null));

        // ۲) ثبت سند + تأیید خودکار (اثر روی موجودی و FIFO)
        var result = await documents.CreateAsync(doc, lines);
        if (!result.Ok) return result;
        var confirm = await documents.ConfirmAsync(doc.Id, new UserInfo(user ?? "سیستم", UserRole.Admin));
        if (!confirm.Ok) return confirm;
        order.ReceiptDocumentId = doc.Id;
        order.ReceivedAt = DateTime.Now;
        order.Status = PurchaseOrderStatus.Received;

        // ۳) ردیف‌ها رسیدشده + ارزشیابی FIFO از روی سند نهایی (بعد از تخفیف)
        foreach (var line in order.Lines)
            line.ReceivedQuantity = line.Quantity;

        if (discount > 0 && discount < 100)
        {
            var factor = 1m - discount / 100m;
            var stocks = await db.StockBatches.Where(s => s.DocumentId == doc.Id).ToListAsync();
            foreach (var s in stocks)
                s.UnitCost = Math.Round(s.UnitCost * factor, 6);
        }

        // ۴) به‌روزرسانی قیمت خرید کالا (آخرین قیمت خرید)
        foreach (var line in order.Lines)
        {
            var product = await db.Products.FindAsync(line.ProductId);
            if (product is not null && line.UnitPrice > 0) product.PurchasePrice = line.UnitPrice;
        }

        await db.SaveChangesAsync();
        await audit.LogAsync(user, "رسید", "سفارش خرید", id.ToString(),
            $"شماره {order.Number} — سند {doc.Number} — مبلغ {order.Lines.Sum(l => l.Total):N0} ریال");
        return new CheckResult(true, $"رسید سند {doc.Number} صادر شد و موجودی به‌روزرسانی شد.");
    }

    public async Task<CheckResult> CancelAsync(int id, string? user)
    {
        var order = await db.PurchaseOrders.FindAsync(id);
        if (order is null) return new CheckResult(false, "سفارش یافت نشد.");
        if (order.Status == PurchaseOrderStatus.Received)
            return new CheckResult(false, "سفارش رسیدشده قابل لغو نیست.");
        if (order.Status == PurchaseOrderStatus.Cancelled)
            return new CheckResult(false, "سفارش قبلاً لغو شده است.");

        order.Status = PurchaseOrderStatus.Cancelled;
        await db.SaveChangesAsync();
        await audit.LogAsync(user, "لغو", "سفارش خرید", id.ToString(), $"شماره {order.Number}");
        return new CheckResult(true, "سفارش لغو شد.");
    }

    public async Task<CheckResult> DeleteAsync(int id, string? user)
    {
        var order = await db.PurchaseOrders.FindAsync(id);
        if (order is null) return new CheckResult(false, "سفارش یافت نشد.");
        if (order.Status != PurchaseOrderStatus.Draft)
            return new CheckResult(false, "فقط سفارش‌های پیش‌نویس قابل حذف هستند.");

        db.PurchaseOrders.Remove(order);
        await db.SaveChangesAsync();
        await audit.LogAsync(user, "حذف", "سفارش خرید", id.ToString(), $"شماره {order.Number}");
        return new CheckResult(true, "سفارش حذف شد.");
    }
}
