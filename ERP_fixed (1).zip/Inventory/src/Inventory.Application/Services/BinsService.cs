using Inventory.Application.Common;
using Inventory.Application.DTOs;
using Inventory.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace Inventory.Application.Services;

public interface IBinsService
{
    Task<List<StorageBinDto>> GetListAsync();
    Task<List<BinStockDto>> GetStockAsync();
    Task<CheckResult> CreateAsync(StorageBin bin, string? user);
    Task<CheckResult> UpdateAsync(StorageBin bin, string? user);
    Task<CheckResult> DeleteAsync(int id, string? user);
}

/// <summary>محل‌های نگهداری (قفسه/رف) و موجودی به تفکیک محل</summary>
public class BinsService(IAppDbContext db, IAuditService audit) : IBinsService
{
    public async Task<List<StorageBinDto>> GetListAsync()
    {
        var bins = await db.StorageBins.AsNoTracking()
            .Include(b => b.Warehouse)
            .Include(b => b.Stocks)
            .OrderBy(b => b.Warehouse.Code).ThenBy(b => b.Code)
            .ToListAsync();

        return bins.Select(b => new StorageBinDto
        {
            Id = b.Id,
            WarehouseId = b.WarehouseId,
            WarehouseTitle = b.Warehouse.Title,
            Code = b.Code,
            Title = b.Title,
            IsActive = b.IsActive,
            StockQuantity = b.Stocks.Sum(s => s.Quantity),
            ItemCount = b.Stocks.Count(s => s.Quantity > 0)
        }).ToList();
    }

    public async Task<List<BinStockDto>> GetStockAsync()
    {
        var stocks = await db.BinStocks.AsNoTracking()
            .Include(s => s.Bin).ThenInclude(b => b.Warehouse)
            .Include(s => s.Product).ThenInclude(p => p.MainUnit)
            .Where(s => s.Quantity > 0)
            .OrderBy(s => s.Bin.Warehouse.Code).ThenBy(s => s.Bin.Code).ThenBy(s => s.Product.Code)
            .ToListAsync();

        return stocks.Select(s => new BinStockDto(
            s.BinId, s.Bin.Code, s.Bin.Warehouse.Title,
            s.Product.Code, s.Product.Name, s.Product.MainUnit.Title,
            s.Quantity, s.TotalCost)).ToList();
    }

    public async Task<CheckResult> CreateAsync(StorageBin bin, string? user)
    {
        if (string.IsNullOrWhiteSpace(bin.Code)) return new CheckResult(false, "کد محل الزامی است.");
        if (await db.StorageBins.AnyAsync(b => b.Code == bin.Code.Trim()))
            return new CheckResult(false, "این کد محل قبلاً ثبت شده است.");

        bin.Code = bin.Code.Trim();
        db.StorageBins.Add(bin);
        await db.SaveChangesAsync();
        await audit.LogAsync(user, "ایجاد", "محل نگهداری", bin.Id.ToString(), $"کد {bin.Code} در انبار {bin.WarehouseId}");
        return new CheckResult(true, "محل نگهداری ثبت شد.");
    }

    public async Task<CheckResult> UpdateAsync(StorageBin bin, string? user)
    {
        var existing = await db.StorageBins.FindAsync(bin.Id);
        if (existing is null) return new CheckResult(false, "محل یافت نشد.");
        if (await db.StorageBins.AnyAsync(b => b.Code == bin.Code.Trim() && b.Id != bin.Id))
            return new CheckResult(false, "این کد محل قبلاً ثبت شده است.");

        existing.Code = bin.Code.Trim();
        existing.Title = bin.Title;
        existing.WarehouseId = bin.WarehouseId;
        existing.IsActive = bin.IsActive;
        await db.SaveChangesAsync();
        await audit.LogAsync(user, "ویرایش", "محل نگهداری", bin.Id.ToString(), $"کد {existing.Code}");
        return new CheckResult(true, "محل نگهداری ویرایش شد.");
    }

    public async Task<CheckResult> DeleteAsync(int id, string? user)
    {
        var bin = await db.StorageBins.FindAsync(id);
        if (bin is null) return new CheckResult(false, "محل یافت نشد.");
        db.StorageBins.Remove(bin);
        await db.SaveChangesAsync();
        await audit.LogAsync(user, "حذف", "محل نگهداری", id.ToString(), $"کد {bin.Code}");
        return new CheckResult(true, "محل نگهداری حذف شد.");
    }
}
