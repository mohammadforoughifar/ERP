using Inventory.Application.Common;
using Inventory.Application.DTOs;
using Microsoft.EntityFrameworkCore;

namespace Inventory.Application.Services;

public interface IMrpService
{
    Task<List<MrpItemDto>> CalculateAsync(int targetProductId, decimal targetQuantity, string? user);
}

/// <summary>MRP ساده — محاسبه نیاز خالص اجزای یک کالای مرکب بر اساس سفارش/فروش</summary>
public class MrpService(IAppDbContext db, IAuditService audit) : IMrpService
{
    public async Task<List<MrpItemDto>> CalculateAsync(int targetProductId, decimal targetQuantity, string? user)
    {
        var result = new List<MrpItemDto>();
        if (targetProductId <= 0 || targetQuantity <= 0) return result;

        var bom = await db.Boms.AsNoTracking().Include(b => b.Lines).ThenInclude(l => l.ComponentProduct).ThenInclude(p => p.MainUnit)
            .FirstOrDefaultAsync(b => b.ProductId == targetProductId && b.IsActive);
        if (bom is null || bom.Lines.Count == 0) return result;

        var onOrder = (await db.PurchaseOrderLines.AsNoTracking()
            .Where(l => l.Order.Status == Domain.Enums.PurchaseOrderStatus.Confirmed)
            .Select(l => new { l.ProductId, l.Quantity, l.ReceivedQuantity })
            .ToListAsync())
            .GroupBy(l => l.ProductId)
            .ToDictionary(g => g.Key, g => g.Sum(l => l.Quantity - l.ReceivedQuantity));

        foreach (var line in bom.Lines)
        {
            var demand = line.Quantity * targetQuantity;
            var stock = (await db.WarehouseItems.AsNoTracking()
                .Where(w => w.ProductId == line.ComponentProductId)
                .Select(w => w.Quantity).ToListAsync()).Sum();
            var order = onOrder.TryGetValue(line.ComponentProductId, out var oq) ? oq : 0;
            var suggested = Math.Max(0, demand - stock - order);

            result.Add(new MrpItemDto(line.ComponentProductId, line.ComponentProduct.Code,
                line.ComponentProduct.Name, line.ComponentProduct.MainUnit.Title,
                Math.Round(demand, 3), Math.Round(stock, 3), Math.Round(order, 3), Math.Round(suggested, 3)));
        }

        var need = result.Sum(r => r.Suggested);
        await audit.LogAsync(user, "محاسبه MRP", "MRP", targetProductId.ToString(),
            $"برای {targetQuantity:N0} واحد — نیاز خرید {need:N0}");
        return result;
    }
}
