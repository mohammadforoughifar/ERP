using Inventory.Domain.Enums;

namespace Inventory.Application.Common;

public static class EnumTitles
{
    public static string Title(this DocumentType t) => t switch
    {
        DocumentType.PurchaseReceipt => "رسید خرید",
        DocumentType.SalesReturnReceipt => "رسید برگشت از فروش",
        DocumentType.ProductionReceipt => "رسید تولید",
        DocumentType.OpeningReceipt => "رسید موجودی اولیه",
        DocumentType.TransferReceipt => "رسید انتقال",
        DocumentType.SalesIssue => "حواله فروش",
        DocumentType.ProductionIssue => "حواله مصرف تولید",
        DocumentType.PurchaseReturnIssue => "حواله برگشت به تأمین‌کننده",
        DocumentType.ScrapIssue => "حواله ضایعات",
        DocumentType.InternalUseIssue => "حواله مصارف داخلی",
        DocumentType.TransferIssue => "حواله انتقال",
        DocumentType.Adjustment => "سند تعدیل",
        DocumentType.AdjustmentReceipt => "سند تعدیل (مازاد)",
        DocumentType.AdjustmentIssue => "سند تعدیل (کسری)",
        DocumentType.ConsignmentReceipt => "ورود کالای امانی",
        DocumentType.ConsignmentReturn => "خروج کالای امانی",
        _ => t.ToString()
    };

    /// <summary>آیا این نوع سند، ورود (رسید) است؟</summary>
    public static bool IsReceiptType(this DocumentType t) => t switch
    {
        DocumentType.PurchaseReceipt or DocumentType.SalesReturnReceipt or DocumentType.ProductionReceipt
            or DocumentType.OpeningReceipt or DocumentType.TransferReceipt
            or DocumentType.AdjustmentReceipt or DocumentType.ConsignmentReceipt => true,
        _ => false
    };

    /// <summary>آیا این نوع سند، انتقال بین انبار است؟</summary>
    public static bool IsTransferType(this DocumentType t) =>
        t is DocumentType.TransferReceipt or DocumentType.TransferIssue;

    /// <summary>آیا این نوع سند، کالای امانی است؟</summary>
    public static bool IsConsignmentType(this DocumentType t) =>
        t is DocumentType.ConsignmentReceipt or DocumentType.ConsignmentReturn;

    public static string Title(this DocumentStatus s) => s switch
    {
        DocumentStatus.Draft => "پیش‌نویس",
        DocumentStatus.Confirmed => "تأییدشده",
        DocumentStatus.Rejected => "ردشده",
        _ => s.ToString()
    };

    public static string Title(this StocktakeStatus s) => s switch
    {
        StocktakeStatus.Draft => "شمارش نشده",
        StocktakeStatus.Counted => "شمارش اول ثبت شد",
        StocktakeStatus.Verified => "تأیید شد — آماده‌ی تعدیل",
        StocktakeStatus.Posted => "تعدیل‌ها صادر شد",
        _ => s.ToString()
    };

    public static string Title(this SerialStatus s) => s switch
    {
        SerialStatus.InStock => "در انبار",
        SerialStatus.Issued => "صادر شده",
        _ => s.ToString()
    };

    public static string Title(this ProductType t) => t switch
    {
        ProductType.RawMaterial => "مواد اولیه",
        ProductType.SemiFinished => "کالای واسطه",
        ProductType.Finished => "محصول نهایی",
        ProductType.Consignment => "کالای امانی",
        ProductType.Scrap => "ضایعات",
        ProductType.Service => "خدمت",
        _ => t.ToString()
    };

    public static string Title(this UnitCategory c) => c switch
    {
        UnitCategory.Count => "عددی",
        UnitCategory.Weight => "وزنی",
        UnitCategory.Length => "طولی",
        UnitCategory.Volume => "حجمی",
        UnitCategory.Other => "سایر",
        _ => c.ToString()
    };
}
