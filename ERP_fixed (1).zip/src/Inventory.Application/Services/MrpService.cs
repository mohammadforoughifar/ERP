using System.Text.Json;
using Inventory.Application.Common;
using Inventory.Application.DTOs;
using Inventory.Domain.Entities;
using Inventory.Domain.Enums;
using Microsoft.EntityFrameworkCore;

namespace Inventory.Application.Services;

public interface IMrpService
{
    /// <summary>اجرای موتور MRP — نیاز از سفارش‌های فروش باز + نیازهای دستی</summary>
    Task<MrpRunSummaryDto> RunAsync(MrpRunInput input, string? user);

    Task<List<MrpRunSummaryDto>> GetRunsAsync();
    Task<MrpRunDto?> GetRunAsync(int id);

    /// <summary>تبدیل سفارش‌های پیشنهادی خرید یک اجرا به سفارش‌های خرید واقعی (گروه‌بندی بر اساس تأمین‌کننده)</summary>
    Task<CheckResult> ConvertToPurchaseOrdersAsync(int runId, string? user);

    /// <summary>محاسبه‌ی سریع تک‌محصولی (سطح یک — برای کاربرد سریع)</summary>
    Task<List<MrpItemDto>> CalculateAsync(int targetProductId, decimal targetQuantity, string? user);
}

/// <summary>
/// موتور MRP حرفه‌ای:
/// انفجار چندسطحی BOM با کد سطح پایین (Low-Level Code)،
/// جدول زمان‌بندی هفتگی (Time Buckets)،
/// خالص‌سازی با موجودی + سفارش‌های خرید باز،
/// سیاست‌های اندازه‌ی سفارش (Lot-for-Lot / FOQ + حداقل سفارش)،
/// زمان تحویل (Lead Time)، موجودی اطمینان (Safety Stock)، ضایعات (Scrap)،
/// پیام‌های اقدام (عجیل / موکول / لغو) و سفارش‌های پیشنهادی قابل تبدیل به خرید.
/// </summary>
public class MrpService(IAppDbContext db, IAuditService audit, IPurchaseOrdersService poService) : IMrpService
{
    private static readonly JsonSerializerOptions JsonOpts = new() { WriteIndented = false };

    // ==================== اجرای موتور ====================
    public async Task<MrpRunSummaryDto> RunAsync(MrpRunInput input, string? user)
    {
        var weeks = input.Weeks is >= 2 and <= 26 ? input.Weeks : 8;
        var start = DateTime.Today;

        // ---------- بارگذاری داده‌ها ----------
        var products = await db.Products.AsNoTracking()
            .Include(p => p.MainUnit).ToListAsync();
        var prodMap = products.ToDictionary(p => p.Id);

        var boms = await db.Boms.AsNoTracking()
            .Include(b => b.Lines)
            .Where(b => b.IsActive)
            .ToListAsync();

        // جمع موجودی سمت کلاینت — SQLite روی decimal جمع سمت سرور ندارد
        var onHandRows = await db.WarehouseItems.AsNoTracking()
            .Select(w => new { w.ProductId, w.Quantity })
            .ToListAsync();
        var onHand = onHandRows.GroupBy(w => w.ProductId)
            .ToDictionary(g => g.Key, g => g.Sum(x => x.Quantity));

        // سفارش‌های خرید باز = تأییدشده و کاملاً نرسیده — رسید تخمینی: تاریخ سفارش + Lead Time کالا
        var poLines = await db.PurchaseOrderLines.AsNoTracking()
            .Where(l => l.Order.Status == PurchaseOrderStatus.Confirmed)
            .Select(l => new { PoId = l.OrderId, PoNumber = l.Order.Number, PoDate = l.Order.Date,
                l.ProductId, l.Quantity, l.ReceivedQuantity })
            .ToListAsync();

        // سفارش‌های فروش باز (تأیید/فاکتورشده) — نیاز مستقل
        var soLines = input.IncludeOpenSalesOrders
            ? await db.SalesOrderLines.AsNoTracking()
                .Where(l => l.Order.Status == SalesOrderStatus.Confirmed || l.Order.Status == SalesOrderStatus.Invoiced)
                .Select(l => new { l.ProductId, l.Quantity, SoNumber = l.Order.Number, SoDate = l.Order.Date })
                .ToListAsync()
            : new();

        // ---------- نیازهای مستقل (سفارش فروش + دستی) ----------
        var indepGross = new Dictionary<int, decimal[]>();
        var indepPegs = new Dictionary<int, List<string>>();
        void AddDemand(int pid, decimal qty, DateTime date, string peg)
        {
            if (qty <= 0 || !prodMap.ContainsKey(pid)) return;
            if (!indepGross.TryGetValue(pid, out var arr)) indepGross[pid] = arr = new decimal[weeks];
            arr[BucketOf(date, start, weeks)] += qty;
            if (!indepPegs.TryGetValue(pid, out var list)) indepPegs[pid] = list = new();
            if (!list.Contains(peg)) list.Add(peg);
        }

        foreach (var l in soLines)
            AddDemand(l.ProductId, l.Quantity, l.SoDate, $"سفارش فروش {l.SoNumber}");
        foreach (var m in input.ManualDemands)
            AddDemand(m.ProductId, m.Quantity, m.NeedDate, m.Note ?? "نیاز دستی");

        // نیازهای وابسته — والدین (سطح بالاتر) حین پردازش اینجا تزریق می‌کنند
        var depGross = new Dictionary<int, decimal[]>();
        var depPegs = new Dictionary<int, List<string>>();

        // ---------- کد سطح پایین (LLC) — ترتیب انفجار بدون تکرار ----------
        var childrenMap = boms.ToDictionary(
            b => b.ProductId,
            b => b.Lines.Select(l => (l.ComponentProductId, l.Quantity)).ToList());
        var llc = products.ToDictionary(p => p.Id, _ => 0);
        for (var pass = 0; pass < 50; pass++)
        {
            var changed = false;
            foreach (var (parent, children) in childrenMap)
                foreach (var (child, _) in children)
                {
                    if (!llc.TryGetValue(child, out var cur)) continue;
                    var want = llc[parent] + 1;
                    if (want > cur) { llc[child] = want; changed = true; }
                }
            if (!changed) break;
        }

        // ---------- رسیدهای زمان‌بندی‌شده (سفارش‌های خرید باز) ----------
        var scheduled = new Dictionary<int, List<(int PoId, string PoNumber, DateTime Arrival, decimal Qty)>>();
        foreach (var l in poLines)
        {
            var remaining = l.Quantity - l.ReceivedQuantity;
            if (remaining <= 0) continue;
            var lt = prodMap.TryGetValue(l.ProductId, out var pp) ? Math.Max(pp.LeadTimeDays, 1) : 7;
            var arrival = l.PoDate.AddDays(lt);
            if (!scheduled.TryGetValue(l.ProductId, out var list)) scheduled[l.ProductId] = list = new();
            list.Add((l.PoId, l.PoNumber, arrival, remaining));
        }

        decimal GetOnHand(int pid) => onHand.TryGetValue(pid, out var q) ? q : 0;

        // ---------- پردازش به ترتیب سطح (قلب MRP) ----------
        var plans = new List<MrpProductPlanDto>();
        var plannedOrders = new List<(int ProductId, decimal Qty, DateTime OrderDate, DateTime NeedDate,
            ProcurementType Type, int? VendorId, string Peg)>();

        foreach (var pid in llc.Keys.OrderBy(id => llc[id]).ThenBy(id => id))
        {
            var p = prodMap[pid];
            childrenMap.TryGetValue(pid, out var children);

            // ناخالص = مستقل + وابسته (از انفجار والدین در همین جدول زمانی)
            var gross = new decimal[weeks];
            for (var w = 0; w < weeks; w++)
                gross[w] = (indepGross.GetValueOrDefault(pid)?[w] ?? 0)
                         + (depGross.GetValueOrDefault(pid)?[w] ?? 0);
            var pegs = new List<string>();
            if (indepPegs.TryGetValue(pid, out var ip)) pegs.AddRange(ip);
            if (depPegs.TryGetValue(pid, out var dp)) pegs.AddRange(dp);
            pegs = pegs.Distinct().Take(3).ToList();

            var sched = new decimal[weeks];
            if (scheduled.TryGetValue(pid, out var slist))
                foreach (var s in slist)
                    sched[BucketOf(s.Arrival, start, weeks)] += s.Qty;

            // پیشروی موجودی + نیاز خالص + سیاست سفارش
            var safety = p.SafetyStock;
            var projected = GetOnHand(pid);
            var buckets = new List<MrpBucketDto>(weeks);
            var totalNet = 0m;
            var anyOrder = false;

            for (var w = 0; w < weeks; w++)
            {
                var net = 0m;
                var plannedReceipt = 0m;
                var plannedRelease = 0m;

                var avail = projected + sched[w] - gross[w];
                if (avail < safety)
                {
                    var deficit = safety - avail;
                    net = deficit;
                    var qty = p.LotSizing == LotSizingPolicy.FixedQty && p.FixedOrderQty > 0
                        ? Math.Ceiling(deficit / p.FixedOrderQty) * p.FixedOrderQty
                        : deficit;
                    if (p.MinOrderQty > 0 && qty < p.MinOrderQty) qty = p.MinOrderQty;
                    plannedReceipt = qty;
                    avail += qty;

                    var leadWeeks = (int)Math.Ceiling(p.LeadTimeDays / 7d);
                    var releaseW = Math.Max(0, w - leadWeeks);
                    plannedRelease = qty;
                    var needDate = start.AddDays(w * 7);
                    var orderDate = start.AddDays(releaseW * 7);

                    plannedOrders.Add((pid, qty, orderDate, needDate, p.Procurement, p.DefaultVendorId,
                        pegs.Count > 0 ? string.Join("، ", pegs) : ""));
                    anyOrder = true;

                    // ساخت داخلی → اجزای BOM در هفته‌ی «شروع تولید» لازمند — با درصد ضایعات
                    if (p.Procurement == ProcurementType.Make && children is { Count: > 0 })
                        foreach (var (child, perUnit) in children)
                        {
                            if (!prodMap.ContainsKey(child)) continue;
                            var scrap = p.ScrapPercent; // بازده فرآیند ساخت والد
                            var cq = qty * perUnit * (1 + scrap / 100m);
                            if (!depGross.TryGetValue(child, out var carr))
                                depGross[child] = carr = new decimal[weeks];
                            carr[releaseW] += cq;
                            var peg = $"{p.Name} ×{qty:N0}";
                            if (!depPegs.TryGetValue(child, out var pl)) depPegs[child] = pl = new();
                            if (!pl.Contains(peg)) pl.Add(peg);
                        }
                }

                buckets.Add(new MrpBucketDto
                {
                    Start = start.AddDays(w * 7),
                    Gross = gross[w], Scheduled = sched[w],
                    Projected = avail, Net = net, PlannedReceipt = plannedReceipt,
                    PlannedRelease = plannedRelease,
                });
                projected = avail;
                if (net > 0) totalNet += net;
            }

            plans.Add(new MrpProductPlanDto
            {
                ProductId = pid, Code = p.Code, Name = p.Name, UnitTitle = p.MainUnit.Title,
                Level = llc[pid], Procurement = p.Procurement, LeadTimeDays = p.LeadTimeDays,
                SafetyStock = safety, OnHand = GetOnHand(pid), TotalNet = totalNet,
                Pegging = anyOrder ? string.Join("، ", pegs) : null,
                Buckets = buckets,
            });
        }

        // ---------- پیام‌های اقدام (عجیل / موکول / لغو) ----------
        var messages = BuildActionMessages(scheduled, plans, prodMap, start, weeks, GetOnHand);

        // ---------- ذخیره‌ی اجرا ----------
        var run = new MrpRun
        {
            Title = string.IsNullOrWhiteSpace(input.Title)
                ? $"اجرای {Persianish(DateTime.Now)}"
                : input.Title.Trim(),
            CreatedBy = user ?? "سیستم",
            CreatedAt = DateTime.Now,
            Weeks = weeks, StartDate = start,
            Source = (input.IncludeOpenSalesOrders ? "سفارش‌های فروش باز" : "")
                     + (input.ManualDemands.Count > 0
                         ? (input.IncludeOpenSalesOrders ? " + " : "") + $"{input.ManualDemands.Count} نیاز دستی" : ""),
            ResultJson = JsonSerializer.Serialize(plans, JsonOpts),
        };
        foreach (var o in plannedOrders)
            run.PlannedOrders.Add(new MrpPlannedOrder
            {
                ProductId = o.ProductId, Quantity = o.Qty, OrderDate = o.OrderDate, NeedDate = o.NeedDate,
                Type = o.Type, VendorId = o.VendorId, Pegging = o.Peg,
            });
        foreach (var m in messages)
            run.Messages.Add(new MrpRunMessage
            {
                Type = m.Type, PurchaseOrderId = m.PurchaseOrderId, PoNumber = m.PoNumber,
                ProductId = 0, ProductName = m.ProductName, Text = m.Text,
            });
        db.MrpRuns.Add(run);
        await db.SaveChangesAsync();
        await audit.LogAsync(user, "اجرای MRP", "MRP", run.Id.ToString(),
            $"افق {weeks} هفته — {plannedOrders.Count} سفارش پیشنهادی، {messages.Count} پیام اقدام");

        return await SummarizeAsync(run);
    }


    private async Task<MrpRunSummaryDto> SummarizeAsync(MrpRun run)
    {
        var orders = await db.MrpPlannedOrders.AsNoTracking().Where(o => o.MrpRunId == run.Id).ToListAsync();
        var msgs = await db.MrpRunMessages.AsNoTracking().CountAsync(m => m.MrpRunId == run.Id);
        return new MrpRunSummaryDto
        {
            Id = run.Id, Title = run.Title, CreatedBy = run.CreatedBy, CreatedAt = run.CreatedAt,
            Weeks = run.Weeks, StartDate = run.StartDate, Source = run.Source,
            PlannedCount = orders.Count, MessageCount = msgs,
            ConvertedCount = orders.Count(o => o.IsConverted),
        };
    }

    // ==================== پیام‌های اقدام ====================
    private List<MrpMessageDto> BuildActionMessages(
        Dictionary<int, List<(int PoId, string PoNumber, DateTime Arrival, decimal Qty)>> scheduled,
        List<MrpProductPlanDto> plans,
        Dictionary<int, Product> prodMap,
        DateTime start, int weeks, Func<int, decimal> getOnHand)
    {
        var result = new List<MrpMessageDto>();
        var planMap = plans.ToDictionary(p => p.ProductId);

        foreach (var (pid, list) in scheduled)
        {
            if (!prodMap.TryGetValue(pid, out var p)) continue;
            var plan = planMap.GetValueOrDefault(pid);
            var safety = p.SafetyStock;

            foreach (var (poId, poNumber, arrival, qty) in list)
            {
                var arrivalW = BucketOf(arrival, start, weeks);

                // اولین هفته‌ی کسری از جدول این کالا (اگر برنامه‌ای وجود دارد)
                int? shortW = null;
                if (plan is not null)
                    shortW = plan.Buckets.FindIndex(b => b.Projected < safety || b.Net > 0) is var idx && idx >= 0 ? idx : null;

                if (shortW is null)
                {
                    // هیچ کسری در افق نیست → اگر این رسید اضافه باشد: لغو، اگر خیلی زود می‌رسد: موکول
                    var endProj = plan?.Buckets.LastOrDefault()?.Projected ?? getOnHand(pid);
                    if (endProj - qty >= safety)
                        result.Add(new MrpMessageDto
                        {
                            Type = "Cancel", PurchaseOrderId = poId, PoNumber = poNumber, ProductName = p.Name,
                            Text = $"سفارش باز {poNumber} ({qty:N0} {p.MainUnit.Title}) دیگر لازم نیست — موجودی افق کافی است. لغو کنید.",
                        });
                    else if (plan is not null && FirstGrossWeek(plan) is int gw && arrivalW + 1 < gw)
                        result.Add(new MrpMessageDto
                        {
                            Type = "Postpone", PurchaseOrderId = poId, PoNumber = poNumber, ProductName = p.Name,
                            Text = $"رسید {poNumber} خیلی زودتر از نیاز است (هفته‌ی {gw + 1}) — موکول کنید.",
                        });
                    continue;
                }

                if (arrivalW > shortW)
                    result.Add(new MrpMessageDto
                    {
                        Type = "Expedite", PurchaseOrderId = poId, PoNumber = poNumber, ProductName = p.Name,
                        Text = $"«{p.Name}» هفته‌ی {shortW + 1} کسری دارد ولی سفارش {poNumber} هفته‌ی {arrivalW + 1} می‌رسد — عجیل کنید.",
                    });
                else if (plan is not null && FirstGrossWeek(plan) is int gw2 && arrivalW + 2 < gw2)
                    result.Add(new MrpMessageDto
                    {
                        Type = "Postpone", PurchaseOrderId = poId, PoNumber = poNumber, ProductName = p.Name,
                        Text = $"رسید {poNumber} ({p.Name}) چند هفته قبل از نیاز می‌رسد — در صورت امکان موکول کنید.",
                    });
            }
        }
        return result;
    }

    private static int? FirstGrossWeek(MrpProductPlanDto plan)
    {
        for (var i = 0; i < plan.Buckets.Count; i++)
            if (plan.Buckets[i].Gross > 0) return i;
        return null;
    }

    private static int BucketOf(DateTime date, DateTime start, int weeks)
    {
        var idx = (date.Date - start).Days / 7;
        return idx < 0 ? 0 : idx >= weeks ? weeks - 1 : idx;
    }

    private static string Persianish(DateTime dt) => $"{dt.Year}/{dt.Month:00}/{dt.Day:00}";

    // ==================== خواندن اجراها ====================
    public async Task<List<MrpRunSummaryDto>> GetRunsAsync()
    {
        var runs = await db.MrpRuns.AsNoTracking().OrderByDescending(r => r.Id).Take(50).ToListAsync();
        var ids = runs.Select(r => r.Id).ToList();
        var poCounts = await db.MrpPlannedOrders.AsNoTracking()
            .Where(o => ids.Contains(o.MrpRunId))
            .GroupBy(o => o.MrpRunId)
            .Select(g => new { RunId = g.Key, Total = g.Count(), Converted = g.Count(x => x.IsConverted) })
            .ToDictionaryAsync(x => x.RunId);
        var msgCounts = await db.MrpRunMessages.AsNoTracking()
            .Where(m => ids.Contains(m.MrpRunId))
            .GroupBy(m => m.MrpRunId)
            .Select(g => new { RunId = g.Key, Total = g.Count() })
            .ToDictionaryAsync(x => x.RunId);

        return runs.Select(r => new MrpRunSummaryDto
        {
            Id = r.Id, Title = r.Title, CreatedBy = r.CreatedBy, CreatedAt = r.CreatedAt,
            Weeks = r.Weeks, StartDate = r.StartDate, Source = r.Source,
            PlannedCount = poCounts.GetValueOrDefault(r.Id)?.Total ?? 0,
            MessageCount = msgCounts.GetValueOrDefault(r.Id)?.Total ?? 0,
            ConvertedCount = poCounts.GetValueOrDefault(r.Id)?.Converted ?? 0,
        }).ToList();
    }

    public async Task<MrpRunDto?> GetRunAsync(int id)
    {
        var run = await db.MrpRuns.AsNoTracking()
            .Include(r => r.PlannedOrders).ThenInclude(o => o.Product).ThenInclude(p => p.MainUnit)
            .Include(r => r.PlannedOrders).ThenInclude(o => o.Vendor)
            .Include(r => r.Messages)
            .FirstOrDefaultAsync(r => r.Id == id);
        if (run is null) return null;

        var dto = new MrpRunDto
        {
            Summary = new MrpRunSummaryDto
            {
                Id = run.Id, Title = run.Title, CreatedBy = run.CreatedBy, CreatedAt = run.CreatedAt,
                Weeks = run.Weeks, StartDate = run.StartDate, Source = run.Source,
                PlannedCount = run.PlannedOrders.Count,
                MessageCount = run.Messages.Count,
                ConvertedCount = run.PlannedOrders.Count(o => o.IsConverted),
            },
            Orders = run.PlannedOrders.OrderBy(o => o.OrderDate).Select(ToDto).ToList(),
            Messages = run.Messages.Select(m => new MrpMessageDto
            {
                Type = m.Type, PurchaseOrderId = m.PurchaseOrderId, PoNumber = m.PoNumber,
                ProductName = m.ProductName, Text = m.Text,
            }).ToList(),
        };

        if (!string.IsNullOrWhiteSpace(run.ResultJson))
        {
            try { dto.Plans = JsonSerializer.Deserialize<List<MrpProductPlanDto>>(run.ResultJson, JsonOpts) ?? new(); }
            catch { dto.Plans = new(); }
        }
        return dto;
    }

    private static MrpPlannedOrderDto ToDto(MrpPlannedOrder o) => new()
    {
        Id = o.Id, ProductId = o.ProductId, Code = o.Product?.Code ?? "", Name = o.Product?.Name ?? "",
        UnitTitle = o.Product?.MainUnit?.Title ?? "", Quantity = o.Quantity,
        OrderDate = o.OrderDate, NeedDate = o.NeedDate, Type = o.Type,
        VendorId = o.VendorId, VendorName = o.Vendor?.Name,
        Pegging = o.Pegging, IsConverted = o.IsConverted, PurchaseOrderId = o.PurchaseOrderId,
    };

    // ==================== تبدیل به سفارش خرید ====================
    public async Task<CheckResult> ConvertToPurchaseOrdersAsync(int runId, string? user)
    {
        var run = await db.MrpRuns.Include(r => r.PlannedOrders).ThenInclude(o => o.Product)
            .FirstOrDefaultAsync(r => r.Id == runId);
        if (run is null) return new CheckResult(false, "اجرای MRP یافت نشد.");

        var pending = run.PlannedOrders
            .Where(o => !o.IsConverted && o.Type == ProcurementType.Buy && o.Quantity > 0)
            .ToList();
        if (pending.Count == 0)
            return new CheckResult(true, "سفارش جدیدی برای تبدیل وجود ندارد (همه تبدیل شده‌اند یا کالای ساخت هستند).");

        var noVendor = pending.Where(o => o.VendorId is null or <= 0).ToList();
        var byVendor = pending.Where(o => o.VendorId is > 0).GroupBy(o => o.VendorId!.Value).ToList();

        var created = 0;
        foreach (var group in byVendor)
        {
            var order = new PurchaseOrder
            {
                VendorId = group.Key,
                Description = $"از MRP: {run.Title}",
                CreatedBy = user ?? "سیستم",
            };
            foreach (var o in group)
            {
                order.Lines.Add(new PurchaseOrderLine
                {
                    ProductId = o.ProductId,
                    Quantity = o.Quantity,
                    UnitPrice = o.Product.PurchasePrice,
                });
            }
            var r = await poService.CreateAsync(order, user);
            if (!r.Ok) return r;
            created++;
            foreach (var o in group)
            {
                o.IsConverted = true;
                o.PurchaseOrderId = order.Id;
            }
        }

        await db.SaveChangesAsync();
        await audit.LogAsync(user, "تبدیل MRP به خرید", "MRP", runId.ToString(),
            $"{created} سفارش خرید ساخته شد");

        return noVendor.Count > 0
            ? new CheckResult(true,
                $"{created} سفارش خرید ساخته شد؛ اما {noVendor.Count} قلم بدون تأمین‌کننده‌ی پیش‌فرض بود و تبدیل نشد: " +
                string.Join("، ", noVendor.Select(o => o.Product.Name).Distinct().Take(4)))
            : new CheckResult(true, $"{created} سفارش خرید با موفقیت ساخته شد.");
    }

    // ==================== محاسبه‌ی سریع سطح‌یک (قبلی) ====================
    public async Task<List<MrpItemDto>> CalculateAsync(int targetProductId, decimal targetQuantity, string? user)
    {
        var result = new List<MrpItemDto>();
        if (targetProductId <= 0 || targetQuantity <= 0) return result;

        var bom = await db.Boms.AsNoTracking().Include(b => b.Lines).ThenInclude(l => l.ComponentProduct).ThenInclude(p => p.MainUnit)
            .FirstOrDefaultAsync(b => b.ProductId == targetProductId && b.IsActive);
        if (bom is null || bom.Lines.Count == 0) return result;

        var onOrder = (await db.PurchaseOrderLines.AsNoTracking()
            .Where(l => l.Order.Status == PurchaseOrderStatus.Confirmed)
            .Select(l => new { l.ProductId, l.Quantity, l.ReceivedQuantity })
            .ToListAsync())
            .GroupBy(l => l.ProductId)
            .ToDictionary(g => g.Key, g => g.Sum(l => l.Quantity - l.ReceivedQuantity));

        foreach (var line in bom.Lines)
        {
            var demand = line.Quantity * targetQuantity;
            var stock = (await db.WarehouseItems.AsNoTracking()
                .Where(w => w.ProductId == line.ComponentProductId)
                .Select(w => w.Quantity).ToListAsync()).Sum();
            var order = onOrder.TryGetValue(line.ComponentProductId, out var oq) ? oq : 0;
            var suggested = Math.Max(0, demand - stock - order);

            result.Add(new MrpItemDto(line.ComponentProductId, line.ComponentProduct.Code,
                line.ComponentProduct.Name, line.ComponentProduct.MainUnit.Title,
                Math.Round(demand, 3), Math.Round(stock, 3), Math.Round(order, 3), Math.Round(suggested, 3)));
        }

        var need = result.Sum(r => r.Suggested);
        await audit.LogAsync(user, "محاسبه MRP", "MRP", targetProductId.ToString(),
            $"برای {targetQuantity:N0} واحد — نیاز خرید {need:N0}");
        return result;
    }
}
