using System.Security.Claims;
using Inventory.Application.Services;
using Inventory.Infrastructure;
using Inventory.Infrastructure.Persistence;
using Inventory.Web.Components;
using Inventory.Web.Services;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();

// احراز هویت با کوکی
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/login";
        options.Cookie.Name = "inventory.auth";
        options.ExpireTimeSpan = TimeSpan.FromHours(8);
        options.SlidingExpiration = true;
    });
builder.Services.AddAuthorization();
builder.Services.AddCascadingAuthenticationState();
builder.Services.AddHttpContextAccessor();

// لایه‌های برنامه
builder.Services.AddInfrastructure(builder.Configuration);
builder.Services.AddScoped<IGroupsService, GroupsService>();
builder.Services.AddScoped<IUnitsService, UnitsService>();
builder.Services.AddScoped<IWarehousesService, WarehousesService>();
builder.Services.AddScoped<IProductsService, ProductsService>();
builder.Services.AddScoped<IDocumentsService, DocumentsService>();
builder.Services.AddScoped<IDashboardService, DashboardService>();
builder.Services.AddScoped<IAuthService, AuthService>();
builder.Services.AddScoped<IAccountingService, AccountingService>();
builder.Services.AddScoped<IStocktakeService, StocktakeService>();
builder.Services.AddScoped<IReportsService, ReportsService>();
builder.Services.AddScoped<CurrentUserService>();
builder.Services.AddScoped<IAuditService, AuditService>();
builder.Services.AddScoped<IBinsService, BinsService>();
builder.Services.AddScoped<IVendorsService, VendorsService>();
builder.Services.AddScoped<IPurchaseOrdersService, PurchaseOrdersService>();
builder.Services.AddScoped<IPriceChangeService, PriceChangeService>();
builder.Services.AddScoped<IBomService, BomService>();
builder.Services.AddScoped<IQualityService, QualityService>();
builder.Services.AddScoped<IMrpService, MrpService>();
builder.Services.AddScoped<IExcelExportService, ExcelExportService>();
builder.Services.AddScoped<IExcelImportService, ExcelImportService>();
builder.Services.AddScoped<ICustomersService, CustomersService>();
builder.Services.AddScoped<ISettingsService, SettingsService>();
builder.Services.AddScoped<ISalesOrdersService, SalesOrdersService>();
builder.Services.AddScoped<ISalesInvoicesService, SalesInvoicesService>();

var app = builder.Build();

// ایجاد / ارتقای دیتابیس
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    var provider = builder.Configuration["Database:Provider"] ?? "Sqlite";

    if (provider.Equals("SqlServer", StringComparison.OrdinalIgnoreCase))
    {
        // اگر پروژه مایگریشن داشت اعمال کن؛ وگرنه ساخت کامل اسکیما (بدون از دست رفتن داده‌ی موجود)
        var pending = db.Database.GetPendingMigrations().ToList();
        if (pending.Count > 0)
            db.Database.Migrate();
        else
            db.Database.EnsureCreated();

        // خودتعمیر: جدول تنظیمات + پارامترهای MRP + جداول MRP برای دیتابیس‌های قدیمی
        try
        {
            db.Database.ExecuteSqlRaw(@"IF OBJECT_ID(N'[dbo].[AppSettings]', N'U') IS NULL
                CREATE TABLE [dbo].[AppSettings] ([Key] nvarchar(450) NOT NULL PRIMARY KEY, [Value] nvarchar(max) NULL)");
            foreach (var col in new[] {
                "Procurement int NOT NULL DEFAULT(1)", "LeadTimeDays int NOT NULL DEFAULT(0)",
                "SafetyStock decimal(18,3) NOT NULL DEFAULT(0)", "LotSizing int NOT NULL DEFAULT(1)",
                "FixedOrderQty decimal(18,3) NOT NULL DEFAULT(0)", "MinOrderQty decimal(18,3) NOT NULL DEFAULT(0)",
                "ScrapPercent decimal(9,4) NOT NULL DEFAULT(0)", "DefaultVendorId int NULL" })
            {
                var name = col.Split(' ')[0];
                db.Database.ExecuteSqlRaw($@"IF COL_LENGTH(N'[dbo].[Products]', N'{name}') IS NULL
                    ALTER TABLE [dbo].[Products] ADD {col}");
            }
            db.Database.ExecuteSqlRaw(@"IF OBJECT_ID(N'[dbo].[MrpRuns]', N'U') IS NULL
                CREATE TABLE [dbo].[MrpRuns] ([Id] int IDENTITY(1,1) NOT NULL PRIMARY KEY,
                    [Title] nvarchar(max) NOT NULL, [CreatedBy] nvarchar(max) NOT NULL, [CreatedAt] datetime2 NOT NULL,
                    [Weeks] int NOT NULL, [StartDate] datetime2 NOT NULL, [Source] nvarchar(max) NULL,
                    [ResultJson] nvarchar(max) NULL)");
            db.Database.ExecuteSqlRaw(@"IF OBJECT_ID(N'[dbo].[MrpPlannedOrders]', N'U') IS NULL
                CREATE TABLE [dbo].[MrpPlannedOrders] ([Id] int IDENTITY(1,1) NOT NULL PRIMARY KEY,
                    [MrpRunId] int NOT NULL, [ProductId] int NOT NULL, [Quantity] decimal(18,3) NOT NULL,
                    [OrderDate] datetime2 NOT NULL, [NeedDate] datetime2 NOT NULL, [Type] int NOT NULL,
                    [VendorId] int NULL, [Pegging] nvarchar(max) NULL, [IsConverted] bit NOT NULL DEFAULT 0,
                    [PurchaseOrderId] int NULL)");
            db.Database.ExecuteSqlRaw(@"IF OBJECT_ID(N'[dbo].[MrpRunMessages]', N'U') IS NULL
                CREATE TABLE [dbo].[MrpRunMessages] ([Id] int IDENTITY(1,1) NOT NULL PRIMARY KEY,
                    [MrpRunId] int NOT NULL, [Type] nvarchar(max) NOT NULL, [PurchaseOrderId] int NOT NULL,
                    [PoNumber] nvarchar(max) NOT NULL, [ProductId] int NOT NULL,
                    [ProductName] nvarchar(max) NOT NULL, [Text] nvarchar(max) NOT NULL)");
        }
        catch { }
    }
    else
    {
        db.Database.EnsureCreated();

        // خودتعمیر: جدول تنظیمات + پارامترهای MRP + جداول MRP برای دیتابیس‌های قدیمی
        try
        {
            db.Database.ExecuteSqlRaw(@"CREATE TABLE IF NOT EXISTS AppSettings (
                Key TEXT NOT NULL PRIMARY KEY, Value TEXT NULL)");
            var cols = new List<string>();
            using (var c = db.Database.GetDbConnection().CreateCommand())
            {
                c.CommandText = "SELECT name FROM pragma_table_info('Products')";
                db.Database.OpenConnection();
                using var rd = c.ExecuteReader();
                while (rd.Read()) cols.Add(rd.GetString(0));
                db.Database.CloseConnection();
            }
            foreach (var (name, type) in new[] {
                ("Procurement", "INTEGER NOT NULL DEFAULT 1"), ("LeadTimeDays", "INTEGER NOT NULL DEFAULT 0"),
                ("SafetyStock", "NUMERIC NOT NULL DEFAULT 0"), ("LotSizing", "INTEGER NOT NULL DEFAULT 1"),
                ("FixedOrderQty", "NUMERIC NOT NULL DEFAULT 0"), ("MinOrderQty", "NUMERIC NOT NULL DEFAULT 0"),
                ("ScrapPercent", "NUMERIC NOT NULL DEFAULT 0"), ("DefaultVendorId", "INTEGER NULL") })
                if (!cols.Contains(name))
                    db.Database.ExecuteSqlRaw($"ALTER TABLE Products ADD COLUMN {name} {type}");
            db.Database.ExecuteSqlRaw(@"CREATE TABLE IF NOT EXISTS MrpRuns (
                Id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, Title TEXT NOT NULL, CreatedBy TEXT NOT NULL,
                CreatedAt TEXT NOT NULL, Weeks INTEGER NOT NULL, StartDate TEXT NOT NULL,
                Source TEXT NULL, ResultJson TEXT NULL)");
            db.Database.ExecuteSqlRaw(@"CREATE TABLE IF NOT EXISTS MrpPlannedOrders (
                Id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, MrpRunId INTEGER NOT NULL,
                ProductId INTEGER NOT NULL, Quantity NUMERIC NOT NULL, OrderDate TEXT NOT NULL,
                NeedDate TEXT NOT NULL, Type INTEGER NOT NULL, VendorId INTEGER NULL,
                Pegging TEXT NULL, IsConverted INTEGER NOT NULL DEFAULT 0, PurchaseOrderId INTEGER NULL)");
            db.Database.ExecuteSqlRaw(@"CREATE TABLE IF NOT EXISTS MrpRunMessages (
                Id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, MrpRunId INTEGER NOT NULL,
                Type TEXT NOT NULL, PurchaseOrderId INTEGER NOT NULL, PoNumber TEXT NOT NULL,
                ProductId INTEGER NOT NULL, ProductName TEXT NOT NULL, Text TEXT NOT NULL)");
        }
        catch { }
    }
}

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
    app.UseHsts();
}

app.UseHttpsRedirection();

app.UseStaticFiles();
app.UseAuthentication();
app.UseAuthorization();
app.UseAntiforgery();

// ورود و خروج (برای فرم ساده‌ی HTML — مسیر مجزا تا با صفحه‌ی Blazor تداخل نکند)
app.MapPost("/login-post", async (HttpContext ctx, IAuthService auth,
    [Microsoft.AspNetCore.Mvc.FromForm] string username,
    [Microsoft.AspNetCore.Mvc.FromForm] string password) =>
{
    var user = await auth.ValidateAsync(username, password);
    if (user is null)
    {
        ctx.Response.Redirect("/login?error=1");
        return;
    }

    var claims = new List<Claim>
    {
        new(ClaimTypes.Name, user.DisplayName),
        new(ClaimTypes.NameIdentifier, user.Username),
        new(ClaimTypes.Role, user.Role.ToString())
    };
    var principal = new ClaimsPrincipal(new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme));
    await ctx.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal);
    ctx.Response.Redirect("/");
}).DisableAntiforgery();

app.MapPost("/logout", async (HttpContext ctx) =>
{
    await ctx.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
    ctx.Response.Redirect("/login");
}).DisableAntiforgery();

app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode();

app.Run();
