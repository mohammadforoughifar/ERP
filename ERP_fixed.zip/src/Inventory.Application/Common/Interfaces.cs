using Microsoft.EntityFrameworkCore;
using Inventory.Domain.Entities;

namespace Inventory.Application.Common;

/// <summary>رابط DbContext — پیاده‌سازی در لایه‌ی زیرساخت</summary>
public interface IAppDbContext
{
    DbSet<ProductGroup> ProductGroups { get; }
    DbSet<Unit> Units { get; }
    DbSet<Warehouse> Warehouses { get; }
    DbSet<Product> Products { get; }
    DbSet<WarehouseItem> WarehouseItems { get; }
    DbSet<InventoryDocument> InventoryDocuments { get; }
    DbSet<InventoryDocumentLine> InventoryDocumentLines { get; }
    DbSet<AppUser> Users { get; }
    DbSet<AccountingVoucher> AccountingVouchers { get; }
    DbSet<AccountingVoucherLine> AccountingVoucherLines { get; }
    DbSet<StockBatch> StockBatches { get; }
    DbSet<SerialItem> SerialItems { get; }
    DbSet<Stocktake> Stocktakes { get; }
    DbSet<StocktakeLine> StocktakeLines { get; }
    DbSet<ProductAttributeDefinition> ProductAttributeDefinitions { get; }
    DbSet<ProductAttributeValue> ProductAttributeValues { get; }
    DbSet<StorageBin> StorageBins { get; }
    DbSet<BinStock> BinStocks { get; }
    DbSet<Vendor> Vendors { get; }
    DbSet<PurchaseOrder> PurchaseOrders { get; }
    DbSet<PurchaseOrderLine> PurchaseOrderLines { get; }
    DbSet<PriceChangeDocument> PriceChangeDocuments { get; }
    DbSet<Bom> Boms { get; }
    DbSet<BomLine> BomLines { get; }
    DbSet<QualityInspection> QualityInspections { get; }
    DbSet<AuditLog> AuditLogs { get; }
    DbSet<Customer> Customers { get; }
    DbSet<SalesOrder> SalesOrders { get; }
    DbSet<SalesOrderLine> SalesOrderLines { get; }
    DbSet<SalesInvoice> SalesInvoices { get; }
    DbSet<SalesInvoiceLine> SalesInvoiceLines { get; }
    DbSet<AppSetting> AppSettings { get; }
    DbSet<MrpRun> MrpRuns { get; }
    DbSet<MrpPlannedOrder> MrpPlannedOrders { get; }
    DbSet<MrpRunMessage> MrpRunMessages { get; }

    Task<int> SaveChangesAsync(CancellationToken ct = default);

    /// <summary>حذف تمام تغییرات رهگیری‌شده — برای برگرداندن وضعیت پس از خطای میانی</summary>
    void ClearTracker();
}

/// <summary>دسترسی به زمان جاری</summary>
public interface IDateTime
{
    DateTime Now { get; }
}
