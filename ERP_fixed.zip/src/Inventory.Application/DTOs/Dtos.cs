using Inventory.Domain.Enums;

namespace Inventory.Application.DTOs;

/// <summary>DTOها برای فرم‌ها به‌صورت کلاس قابل تغییر (برای @bind) تعریف شده‌اند</summary>

public class ProductGroupDto
{
    public int Id { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Title { get; set; } = string.Empty;
    public int? ParentId { get; set; }
    public bool IsActive { get; set; } = true;
    public string? Description { get; set; }

    public ProductGroupDto() { }
    public ProductGroupDto(int id, string code, string title, int? parentId, bool isActive, string? description)
    {
        Id = id; Code = code; Title = title; ParentId = parentId; IsActive = isActive; Description = description;
    }
}

public class UnitDto
{
    public int Id { get; set; }
    public string Title { get; set; } = string.Empty;
    public UnitCategory Category { get; set; } = UnitCategory.Count;
    public string CategoryTitle { get; set; } = string.Empty;
    public int? BaseUnitId { get; set; }
    public string? BaseUnitTitle { get; set; }
    public decimal Factor { get; set; } = 1;
    public string? Description { get; set; }

    public UnitDto() { }
    public UnitDto(int id, string title, UnitCategory category, string categoryTitle,
        int? baseUnitId, string? baseUnitTitle, decimal factor, string? description = null)
    {
        Id = id; Title = title; Category = category; CategoryTitle = categoryTitle;
        BaseUnitId = baseUnitId; BaseUnitTitle = baseUnitTitle; Factor = factor; Description = description;
    }
}

public class WarehouseDto
{
    public int Id { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Title { get; set; } = string.Empty;
    public string? ManagerName { get; set; }
    public string? Address { get; set; }
    public string? Phone { get; set; }
    public bool IsActive { get; set; } = true;

    public WarehouseDto() { }
    public WarehouseDto(int id, string code, string title, string? managerName, string? address, string? phone, bool isActive)
    {
        Id = id; Code = code; Title = title; ManagerName = managerName; Address = address; Phone = phone; IsActive = isActive;
    }
}

public class ProductDto
{
    public int Id { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? LatinName { get; set; }
    public string? Barcode { get; set; }
    public ProductType Type { get; set; } = ProductType.Finished;
    public string TypeTitle { get; set; } = string.Empty;
    public int GroupId { get; set; }
    public string GroupTitle { get; set; } = string.Empty;
    public int MainUnitId { get; set; }
    public string MainUnitTitle { get; set; } = string.Empty;
    public decimal ReorderPoint { get; set; }
    public decimal MinStock { get; set; }
    public decimal MaxStock { get; set; }
    public decimal PurchasePrice { get; set; }
    public decimal SalePrice { get; set; }
    public bool IsActive { get; set; } = true;
    public string? Description { get; set; }

    // ============ رهگیری پیشرفته (فاز ۳) ============
    public bool TrackSerial { get; set; }
    public bool TrackExpiry { get; set; }
    public bool TrackLot { get; set; }

    /// <summary>روش ارزشیابی (میانگین موزون / FIFO)</summary>
    public ValuationMethod ValuationMethod { get; set; } = ValuationMethod.Average;

    // ============ پارامترهای MRP ============
    public ProcurementType Procurement { get; set; } = ProcurementType.Buy;
    public int LeadTimeDays { get; set; }
    public decimal SafetyStock { get; set; }
    public LotSizingPolicy LotSizing { get; set; } = LotSizingPolicy.LotForLot;
    public decimal FixedOrderQty { get; set; }
    public decimal MinOrderQty { get; set; }
    public decimal ScrapPercent { get; set; }
    public int? DefaultVendorId { get; set; }
    public string? DefaultVendorName { get; set; }

    // ============ ویژگی‌های تکمیلی ============
    public List<ProductAttributeDto> Attributes { get; set; } = new();

    public ProductDto() { }
    public ProductDto(int id, string code, string name, string? latinName, string? barcode, ProductType type,
        string typeTitle, int groupId, string groupTitle, int mainUnitId, string mainUnitTitle,
        decimal reorderPoint, decimal minStock, decimal maxStock,
        decimal purchasePrice, decimal salePrice, bool isActive, string? description,
        bool trackSerial = false, bool trackExpiry = false, bool trackLot = false,
        ProcurementType procurement = ProcurementType.Buy, int leadTimeDays = 0, decimal safetyStock = 0,
        LotSizingPolicy lotSizing = LotSizingPolicy.LotForLot, decimal fixedOrderQty = 0,
        decimal minOrderQty = 0, decimal scrapPercent = 0, int? defaultVendorId = null, string? defaultVendorName = null)
    {
        Id = id; Code = code; Name = name; LatinName = latinName; Barcode = barcode; Type = type;
        TypeTitle = typeTitle; GroupId = groupId; GroupTitle = groupTitle; MainUnitId = mainUnitId;
        MainUnitTitle = mainUnitTitle; ReorderPoint = reorderPoint; MinStock = minStock; MaxStock = maxStock;
        PurchasePrice = purchasePrice; SalePrice = salePrice; IsActive = isActive; Description = description;
        TrackSerial = trackSerial; TrackExpiry = trackExpiry; TrackLot = trackLot;
        Procurement = procurement; LeadTimeDays = leadTimeDays; SafetyStock = safetyStock;
        LotSizing = lotSizing; FixedOrderQty = fixedOrderQty; MinOrderQty = minOrderQty;
        ScrapPercent = scrapPercent; DefaultVendorId = defaultVendorId; DefaultVendorName = defaultVendorName;
    }
}

/// <summary>یک ردیف ویژگی کالا (تعریف + مقدار)</summary>
public class ProductAttributeDto
{
    public int DefinitionId { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Value { get; set; } = string.Empty;
}

public record ProductAttributeDefinitionDto(int Id, string Name);

public record ProductListItemDto(
    int Id, string Code, string Name, string? Barcode, string TypeTitle, string GroupTitle, string MainUnitTitle,
    decimal ReorderPoint, decimal Stock, decimal TotalCost, decimal AverageCost,
    decimal PurchasePrice, decimal SalePrice, bool IsActive,
    bool TrackSerial = false, bool TrackExpiry = false, bool TrackLot = false,
    List<string>? AttributeTexts = null, ValuationMethod ValuationMethod = ValuationMethod.Average);

public record DocumentLineDto(
    int Id, int ProductId, string ProductCode, string ProductName, string UnitTitle,
    decimal Quantity, decimal UnitPrice, decimal UnitCost, decimal Total,
    string? LotNumber = null, string? ExpiryDateFa = null, string? SerialNumbers = null,
    bool TrackLot = false, bool TrackExpiry = false, bool TrackSerial = false,
    int? BinId = null, string? BinCode = null);

public record InventoryDocumentDto(
    int Id, string Number, DocumentType Type, string TypeTitle, bool IsReceipt, bool IsTransfer,
    DocumentStatus Status, string StatusTitle, DateTime Date, string DateFa,
    int? WarehouseId, string? WarehouseTitle, int? DestinationWarehouseId, string? DestinationWarehouseTitle,
    bool IsPostedToAccounting, int? AccountingVoucherId,
    string? PartyName, string? Description, string CreatedBy, DateTime CreatedAt,
    string? ConfirmedBy, DateTime? ConfirmedAt, decimal TotalQuantity, decimal TotalAmount,
    List<DocumentLineDto> Lines);

public record VoucherDto(
    int Id, string Number, string DateFa, int? SourceId, string? SourceNumber, string SourceTypeTitle,
    string? Description, string CreatedBy, decimal TotalDebit, decimal TotalCredit,
    List<VoucherLineDto> Lines);

public record VoucherLineDto(string AccountCode, string AccountTitle, decimal Debit, decimal Credit);

public record UserInfo(string DisplayName, UserRole Role);

public record DashboardDto(
    int ProductCount, int WarehouseCount, int GroupCount, int UnitCount,
    decimal TotalStock, decimal TotalStockValue,
    int DocumentsToday, int DraftDocuments, int LowStockCount, List<LowStockItemDto> LowStockItems,
    List<RecentDocumentDto> RecentDocuments);

public record LowStockItemDto(int ProductId, string Code, string Name, decimal Stock, decimal ReorderPoint);

public record RecentDocumentDto(string Number, string TypeTitle, string StatusTitle, string DateFa, string? WarehouseTitle, decimal TotalAmount);

public record CheckResult(bool Ok, string Message);

// ================= فاز ۳ — انبارگردانی =================

public class StocktakeDto
{
    public int Id { get; set; }
    public string Number { get; set; } = string.Empty;
    public int WarehouseId { get; set; }
    public string WarehouseTitle { get; set; } = string.Empty;
    public DateTime Date { get; set; }
    public string DateFa { get; set; } = string.Empty;
    public StocktakeStatus Status { get; set; }
    public string StatusTitle { get; set; } = string.Empty;
    public string? Description { get; set; }
    public string CreatedBy { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; }
    public string? VerifiedBy { get; set; }
    public int LineCount { get; set; }
    public int DifferenceCount { get; set; }
}

public class StocktakeLineDto
{
    public int Id { get; set; }
    public int ProductId { get; set; }
    public string ProductCode { get; set; } = string.Empty;
    public string ProductName { get; set; } = string.Empty;
    public string UnitTitle { get; set; } = string.Empty;
    public decimal BookQuantity { get; set; }
    public decimal? CountedQuantity { get; set; }
    public decimal? CountedQuantity2 { get; set; }
    public decimal Difference { get; set; }
    public string? Reason { get; set; }
    public int? AdjustmentDocumentId { get; set; }
}

// ================= فاز ۳ — گزارش‌های تحلیلی =================

public record ReorderItemDto(
    int ProductId, string Code, string Name, string GroupTitle, string UnitTitle,
    decimal Stock, decimal ReorderPoint);

public record StaleItemDto(
    int ProductId, string Code, string Name, string UnitTitle,
    decimal Stock, string? LastMovementFa, int MonthsWithoutMovement);

public record StockAgeDto(
    int ProductId, string Code, string Name, string WarehouseTitle, string UnitTitle,
    decimal Quantity, string? OldestReceiptFa, int? AgeDays);

public record TopSellerDto(
    string Code, string Name, string UnitTitle, decimal Quantity, decimal Value, int DocumentCount);

public record MovementDto(
    int ProductId, string Code, string Name, string UnitTitle,
    decimal InQuantity, decimal OutQuantity, decimal NetQuantity,
    decimal InValue, decimal OutValue);

public record ExpiryItemDto(
    string LotNumber, string ProductCode, string ProductName, string WarehouseTitle,
    string ExpiryDateFa, int DaysLeft, decimal Quantity, string UnitTitle);

public record StaffPerformanceDto(
    string CreatedBy, int Total, int Draft, int Confirmed, int Rejected);

public record ConsignmentItemDto(
    string ProductCode, string ProductName, string UnitTitle, string? PartyName,
    string WarehouseTitle, decimal Quantity, decimal Value);


// ================= فاز ۴ — تکمیلی =================

public class StorageBinDto
{
    public int Id { get; set; }
    public int WarehouseId { get; set; }
    public string WarehouseTitle { get; set; } = string.Empty;
    public string Code { get; set; } = string.Empty;
    public string Title { get; set; } = string.Empty;
    public bool IsActive { get; set; } = true;
    public decimal StockQuantity { get; set; }
    public int ItemCount { get; set; }
}

public record BinStockDto(
    int BinId, string BinCode, string WarehouseTitle,
    string ProductCode, string ProductName, string UnitTitle,
    decimal Quantity, decimal TotalCost);

public class VendorDto
{
    public int Id { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Phone { get; set; }
    public string? Address { get; set; }
    public string? TaxId { get; set; }
    public bool IsActive { get; set; } = true;
}

public class PurchaseOrderDto
{
    public int Id { get; set; }
    public string Number { get; set; } = string.Empty;
    public DateTime Date { get; set; }
    public string DateFa { get; set; } = string.Empty;
    public int VendorId { get; set; }
    public string VendorName { get; set; } = string.Empty;
    public PurchaseOrderStatus Status { get; set; }
    public string StatusTitle { get; set; } = string.Empty;
    public string? Description { get; set; }
    public string CreatedBy { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; }
    public decimal TotalQuantity { get; set; }
    public decimal TotalAmount { get; set; }
    public int? ReceiptDocumentId { get; set; }
    public List<PurchaseOrderLineDto> Lines { get; set; } = new();
}

public record PurchaseOrderLineDto(
    int Id, int ProductId, string ProductCode, string ProductName, string UnitTitle,
    decimal Quantity, decimal UnitPrice, decimal ReceivedQuantity, decimal Total);

public record PriceChangeDto(
    int Id, string Number, string DateFa, string ProductCode, string ProductName,
    decimal OldPurchasePrice, decimal NewPurchasePrice, decimal? OldSalePrice, decimal? NewSalePrice,
    string? Reason, string CreatedBy);

public class BomDto
{
    public int ProductId { get; set; }
    public string ProductCode { get; set; } = string.Empty;
    public string ProductName { get; set; } = string.Empty;
    public string UnitTitle { get; set; } = string.Empty;
    public string? Title { get; set; }
    public bool IsActive { get; set; } = true;
    public int LineCount { get; set; }
    public List<BomLineDto> Lines { get; set; } = new();
}

public record BomLineDto(int ProductId, string ProductCode, string ProductName, string UnitTitle, decimal Quantity);

public record QualityInspectionDto(
    int Id, string Number, string DateFa, int DocumentId, string DocumentNumber,
    string DocumentTypeTitle, string VendorName, QualityStatus Status, string StatusTitle,
    string? Notes, string CreatedBy);

public record AuditLogDto(
    int Id, string DateFa, string TimeFa, string UserName, string Action,
    string EntityType, string? EntityId, string? Details);

public record MrpItemDto(
    int ProductId, string Code, string Name, string UnitTitle,
    decimal Demand, decimal Stock, decimal OnOrder, decimal Suggested);


/// <summary>لایه باز FIFO — موجودی ورودی‌های تأییدشده به‌همراه قیمت هر لایه</summary>
public record FifoLayerDto(
    int ProductId, string ProductCode, string ProductName, string WarehouseTitle,
    string LotNumber, string? ExpiryDateFa, decimal Quantity, decimal UnitCost);


// ================= فاز ۵ — چرخه فروش =================

public class CustomerDto
{
    public int Id { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Phone { get; set; }
    public string? Address { get; set; }
    public string? NationalId { get; set; }
    public bool IsActive { get; set; } = true;
}

public class SalesOrderDto
{
    public int Id { get; set; }
    public string Number { get; set; } = string.Empty;
    public DateTime Date { get; set; }
    public string DateFa { get; set; } = string.Empty;
    public int CustomerId { get; set; }
    public string CustomerName { get; set; } = string.Empty;
    public SalesOrderStatus Status { get; set; }
    public string StatusTitle { get; set; } = string.Empty;
    public string? Description { get; set; }
    public string CreatedBy { get; set; } = string.Empty;
    public decimal TotalQuantity { get; set; }
    public decimal TotalAmount { get; set; }
    public int? InvoiceId { get; set; }
    public List<SalesOrderLineDto> Lines { get; set; } = new();
}

public record SalesOrderLineDto(
    int Id, int ProductId, string ProductCode, string ProductName, string UnitTitle,
    decimal Quantity, decimal UnitPrice, decimal Total);

public class SalesInvoiceDto
{
    public int Id { get; set; }
    public string Number { get; set; } = string.Empty;
    public DateTime Date { get; set; }
    public string DateFa { get; set; } = string.Empty;
    public int CustomerId { get; set; }
    public string CustomerName { get; set; } = string.Empty;
    public string? CustomerPhone { get; set; }
    public string? CustomerAddress { get; set; }
    public int? OrderId { get; set; }
    public string? OrderNumber { get; set; }
    public int? IssueDocumentId { get; set; }
    public string? Description { get; set; }
    public string CreatedBy { get; set; } = string.Empty;
    public decimal DiscountPercent { get; set; }
    public decimal Subtotal { get; set; }
    public decimal DiscountAmount { get; set; }
    public decimal Total { get; set; }
    public bool IsReturned { get; set; }
    public int? ReturnDocumentId { get; set; }
    public DateTime? ReturnedAt { get; set; }
    public string? ReturnedBy { get; set; }
    public List<SalesInvoiceLineDto> Lines { get; set; } = new();
}

public record SalesInvoiceLineDto(
    int ProductId, string ProductCode, string ProductName, string UnitTitle,
    decimal Quantity, decimal UnitPrice, decimal UnitCost, decimal Total);

// ==================== MRP ====================

/// <summary>یک ستون هفته در جدول زمان‌بندی MRP</summary>
public class MrpBucketDto
{
    public DateTime Start { get; set; }
    public decimal Gross { get; set; }
    public decimal Scheduled { get; set; }
    public decimal Projected { get; set; }
    public decimal Net { get; set; }
    public decimal PlannedReceipt { get; set; }
    public decimal PlannedRelease { get; set; }
}

/// <summary>برنامه‌ی زمان‌بندی‌شده‌ی یک کالا در اجرای MRP</summary>
public class MrpProductPlanDto
{
    public int ProductId { get; set; }
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
    public string UnitTitle { get; set; } = "";
    public int Level { get; set; }
    public ProcurementType Procurement { get; set; }
    public int LeadTimeDays { get; set; }
    public decimal SafetyStock { get; set; }
    public decimal OnHand { get; set; }
    public decimal TotalNet { get; set; }
    public string? Pegging { get; set; }
    public List<MrpBucketDto> Buckets { get; set; } = new();
}

public class MrpPlannedOrderDto
{
    public int Id { get; set; }
    public int ProductId { get; set; }
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
    public string UnitTitle { get; set; } = "";
    public decimal Quantity { get; set; }
    public DateTime OrderDate { get; set; }
    public DateTime NeedDate { get; set; }
    public ProcurementType Type { get; set; }
    public int? VendorId { get; set; }
    public string? VendorName { get; set; }
    public string? Pegging { get; set; }
    public bool IsConverted { get; set; }
    public int? PurchaseOrderId { get; set; }
}

public class MrpMessageDto
{
    public string Type { get; set; } = "Expedite";
    public int PurchaseOrderId { get; set; }
    public string PoNumber { get; set; } = "";
    public string ProductName { get; set; } = "";
    public string Text { get; set; } = "";
}

public class MrpRunSummaryDto
{
    public int Id { get; set; }
    public string Title { get; set; } = "";
    public string CreatedBy { get; set; } = "";
    public DateTime CreatedAt { get; set; }
    public int Weeks { get; set; }
    public DateTime StartDate { get; set; }
    public string? Source { get; set; }
    public int PlannedCount { get; set; }
    public int MessageCount { get; set; }
    public int ConvertedCount { get; set; }
}

public class MrpRunDto
{
    public MrpRunSummaryDto Summary { get; set; } = new();
    public List<MrpProductPlanDto> Plans { get; set; } = new();
    public List<MrpPlannedOrderDto> Orders { get; set; } = new();
    public List<MrpMessageDto> Messages { get; set; } = new();
}

/// <summary>نیاز دستی ورودی MRP</summary>
public record MrpDemandInput(int ProductId, decimal Quantity, DateTime NeedDate, string? Note = null);

/// <summary>ورودی اجرای MRP</summary>
public class MrpRunInput
{
    public int Weeks { get; set; } = 8;
    public bool IncludeOpenSalesOrders { get; set; } = true;
    public string? Title { get; set; }
    public List<MrpDemandInput> ManualDemands { get; set; } = new();
}

/// <summary>نتیجه‌ی ورود اکسل (گروه/کالا/BOM) — ردیف‌های سالم وارد و خطاها گزارش می‌شوند</summary>
public class ExcelImportResultDto
{
    public bool Ok { get; set; }
    public string Message { get; set; } = string.Empty;
    public int Created { get; set; }
    public int Updated { get; set; }
    public List<string> Warnings { get; set; } = new();
    public List<string> Errors { get; set; } = new();
}
