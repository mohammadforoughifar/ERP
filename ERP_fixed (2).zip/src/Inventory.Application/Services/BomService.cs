using Inventory.Application.Common;
using Inventory.Application.DTOs;
using Inventory.Domain.Entities;
using Inventory.Domain.Enums;
using Microsoft.EntityFrameworkCore;

namespace Inventory.Application.Services;

public interface IBomService
{
    Task<List<BomDto>> GetListAsync();
    Task<BomDto?> GetAsync(int productId);
    Task<CheckResult> SaveAsync(int productId, string? title, List<BomLine> lines, string? user);
    Task<CheckResult> DeleteAsync(int productId, string? user);
    Task<CheckResult> AssembleAsync(int productId, decimal quantity, string? user);
}

/// <summary>کالای مرکب (کیت) — تعریف BOM و جمع‌آوری اجزا</summary>
public class BomService(IAppDbContext db, IDocumentsService documents, IAuditService audit) : IBomService
{
    public async Task<List<BomDto>> GetListAsync()
    {
        var boms = await db.Boms.AsNoTracking()
            .Include(b => b.Product).ThenInclude(p => p.MainUnit)
            .Include(b => b.Lines).ThenInclude(l => l.ComponentProduct).ThenInclude(p => p.MainUnit)
            .Where(b => b.IsActive)
            .ToListAsync();

        return boms.Select(b => new BomDto
        {
            ProductId = b.ProductId,
            ProductCode = b.Product.Code,
            ProductName = b.Product.Name,
            UnitTitle = b.Product.MainUnit?.Title ?? "",
            Title = b.Title,
            IsActive = b.IsActive,
            LineCount = b.Lines.Count,
            Lines = b.Lines.Select(l => new BomLineDto(l.ComponentProductId,
                l.ComponentProduct.Code, l.ComponentProduct.Name, l.ComponentProduct.MainUnit?.Title ?? "", l.Quantity)).ToList()
        }).ToList();
    }

    public async Task<BomDto?> GetAsync(int productId)
    {
        var all = await GetListAsync();
        return all.FirstOrDefault(b => b.ProductId == productId);
    }

    public async Task<CheckResult> SaveAsync(int productId, string? title, List<BomLine> lines, string? user)
    {
        if (productId <= 0) return new CheckResult(false, "انتخاب کالای نهایی الزامی است.");
        var valid = lines.Where(l => l.ComponentProductId > 0 && l.Quantity > 0)
            .GroupBy(l => l.ComponentProductId).Select(g => g.First()).ToList();
        if (valid.Count == 0) return new CheckResult(false, "حداقل یک جزء با مقدار معتبر وارد کنید.");
        if (valid.Any(l => l.ComponentProductId == productId))
            return new CheckResult(false, "کالا نمی‌تواند جزء خودش باشد.");

        var existing = await db.Boms.Include(b => b.Lines)
            .FirstOrDefaultAsync(b => b.ProductId == productId);
        if (existing is null)
        {
            existing = new Bom { ProductId = productId, Title = title };
            db.Boms.Add(existing);
        }
        else
        {
            existing.Title = title;
            existing.IsActive = true;
            db.BomLines.RemoveRange(existing.Lines);
        }
        await db.SaveChangesAsync();

        foreach (var l in valid)
            db.BomLines.Add(new BomLine { BomId = existing.Id, ComponentProductId = l.ComponentProductId, Quantity = l.Quantity });
        await db.SaveChangesAsync();

        await audit.LogAsync(user, "تعریف/ویرایش BOM", "کالای مرکب", productId.ToString(), $"{valid.Count} جزء");
        return new CheckResult(true, "بیل‌آف‌متریال ذخیره شد.");
    }

    public async Task<CheckResult> DeleteAsync(int productId, string? user)
    {
        var bom = await db.Boms.Include(b => b.Lines).FirstOrDefaultAsync(b => b.ProductId == productId);
        if (bom is null) return new CheckResult(false, "BOM یافت نشد.");
        db.BomLines.RemoveRange(bom.Lines);
        db.Boms.Remove(bom);
        await db.SaveChangesAsync();
        await audit.LogAsync(user, "حذف", "کالای مرکب", productId.ToString(), "");
        return new CheckResult(true, "BOM حذف شد.");
    }

    /// <summary>صدور سند خروج (حواله) برای اجزای کیت — تولید مقدار مشخصی از کالای مرکب</summary>
    public async Task<CheckResult> AssembleAsync(int productId, decimal quantity, string? user)
    {
        var bom = await db.Boms.Include(b => b.Lines).FirstOrDefaultAsync(b => b.ProductId == productId && b.IsActive);
        if (bom is null || bom.Lines.Count == 0) return new CheckResult(false, "برای این کالا BOM تعریف نشده است.");
        if (quantity <= 0) return new CheckResult(false, "تعداد معتبر وارد کنید.");

        // بررسی موجودی اجزا
        foreach (var line in bom.Lines)
        {
            var stock = (await db.WarehouseItems.AsNoTracking()
                .Where(w => w.ProductId == line.ComponentProductId)
                .Select(w => w.Quantity).ToListAsync()).Sum();
            var need = line.Quantity * quantity;
            if (stock < need)
                return new CheckResult(false,
                    $"موجودی «{line.ComponentProduct.Name}» کافی نیست: نیاز {need:N0}، موجودی {stock:N0}.");
        }

        var targetWarehouseId = await db.Warehouses.AsNoTracking()
            .OrderBy(w => w.Id).Select(w => (int?)w.Id).FirstOrDefaultAsync();
        var doc = new InventoryDocument
        {
            Number = await documents.GenerateNumberAsync(DocumentType.ProductionIssue),
            Date = DateTime.Now,
            Type = DocumentType.ProductionIssue,
            WarehouseId = targetWarehouseId,
            Description = $"جمع‌آوری کالای مرکب {bom.Product.Code} — تعداد {quantity:N0}",
            CreatedBy = user ?? "سیستم",
            CreatedAt = DateTime.Now
        };
        var issueLines = new List<DocumentLineDto>();
        foreach (var line in bom.Lines)
            issueLines.Add(new DocumentLineDto(0, line.ComponentProductId, "", "", "", line.Quantity * quantity, 0, 0, 0));

        var result = await documents.CreateAsync(doc, issueLines);
        if (!result.Ok) return result;
        var confirmIssue = await documents.ConfirmAsync(doc.Id, new UserInfo(user ?? "سیستم", UserRole.Admin));
        if (!confirmIssue.Ok) return confirmIssue;

        // ورود کالای نهایی با قیمت تمام‌شده = مجموع قیمت اجزا
        var componentValue = bom.Lines.Sum(l => l.Quantity * quantity *
            ((decimal?)db.StockBatches.Where(s => s.ProductId == l.ComponentProductId && s.Quantity > 0)
                .OrderBy(s => s.Id).Select(s => (decimal?)s.UnitCost).FirstOrDefault() ?? 0));
        var unitCost = componentValue / quantity;

        var inDoc = new InventoryDocument
        {
            Number = await documents.GenerateNumberAsync(DocumentType.ProductionReceipt),
            Date = DateTime.Now,
            Type = DocumentType.ProductionReceipt,
            WarehouseId = targetWarehouseId,
            Description = $"ورود کالای مرکب {bom.Product.Code} — تعداد {quantity:N0}",
            CreatedBy = user ?? "سیستم",
            CreatedAt = DateTime.Now
        };
        var inLines = new List<DocumentLineDto>
        {
            new(0, productId, "", "", "", quantity, unitCost, 0, 0)
        };
        var result2 = await documents.CreateAsync(inDoc, inLines);
        if (!result2.Ok) return result2;
        var confirmIn = await documents.ConfirmAsync(inDoc.Id, new UserInfo(user ?? "سیستم", UserRole.Admin));
        if (!confirmIn.Ok) return confirmIn;

        await audit.LogAsync(user, "جمع‌آوری", "کالای مرکب", productId.ToString(),
            $"{quantity:N0} واحد از {bom.Product.Name} — سند {doc.Number} / {inDoc.Number}");
        return new CheckResult(true,
            $"جمع‌آوری انجام شد: خروج اجزا (سند {doc.Number}) و ورود {quantity:N0} واحد (سند {inDoc.Number}).");
    }
}
