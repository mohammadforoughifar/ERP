using Inventory.Application.Common;
using Inventory.Application.DTOs;
using Inventory.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace Inventory.Application.Services;

public interface IVendorsService
{
    Task<List<VendorDto>> GetAllAsync();
    Task<CheckResult> CreateAsync(Vendor vendor, string? user);
    Task<CheckResult> UpdateAsync(Vendor vendor, string? user);
    Task<CheckResult> DeleteAsync(int id, string? user);
}

/// <summary>تأمین‌کنندگان</summary>
public class VendorsService(IAppDbContext db, IAuditService audit) : IVendorsService
{
    public async Task<List<VendorDto>> GetAllAsync() =>
        await db.Vendors.AsNoTracking().OrderBy(v => v.Code)
            .Select(v => new VendorDto
            {
                Id = v.Id, Code = v.Code, Name = v.Name, Phone = v.Phone,
                Address = v.Address, TaxId = v.TaxId, PersonType = v.PersonType, IsActive = v.IsActive
            }).ToListAsync();

    public async Task<CheckResult> CreateAsync(Vendor vendor, string? user)
    {
        if (string.IsNullOrWhiteSpace(vendor.Code) || string.IsNullOrWhiteSpace(vendor.Name))
            return new CheckResult(false, "کد و نام تأمین‌کننده الزامی است.");
        if (await db.Vendors.AnyAsync(v => v.Code == vendor.Code.Trim()))
            return new CheckResult(false, "این کد قبلاً ثبت شده است.");

        vendor.Code = vendor.Code.Trim();
        db.Vendors.Add(vendor);
        await db.SaveChangesAsync();
        await audit.LogAsync(user, "ایجاد", "تأمین‌کننده", vendor.Id.ToString(), vendor.Name);
        return new CheckResult(true, "تأمین‌کننده ثبت شد.");
    }

    public async Task<CheckResult> UpdateAsync(Vendor vendor, string? user)
    {
        var existing = await db.Vendors.FindAsync(vendor.Id);
        if (existing is null) return new CheckResult(false, "تأمین‌کننده یافت نشد.");
        if (await db.Vendors.AnyAsync(v => v.Code == vendor.Code.Trim() && v.Id != vendor.Id))
            return new CheckResult(false, "این کد قبلاً ثبت شده است.");

        existing.Code = vendor.Code.Trim();
        existing.Name = vendor.Name;
        existing.Phone = vendor.Phone;
        existing.Address = vendor.Address;
        existing.TaxId = vendor.TaxId;
        existing.PersonType = vendor.PersonType;
        existing.IsActive = vendor.IsActive;
        await db.SaveChangesAsync();
        await audit.LogAsync(user, "ویرایش", "تأمین‌کننده", vendor.Id.ToString(), vendor.Name);
        return new CheckResult(true, "تأمین‌کننده ویرایش شد.");
    }

    public async Task<CheckResult> DeleteAsync(int id, string? user)
    {
        var vendor = await db.Vendors.FindAsync(id);
        if (vendor is null) return new CheckResult(false, "تأمین‌کننده یافت نشد.");
        if (await db.PurchaseOrders.AnyAsync(o => o.VendorId == id))
            return new CheckResult(false, "این تأمین‌کننده دارای سفارش خرید است و قابل حذف نیست.");

        db.Vendors.Remove(vendor);
        await db.SaveChangesAsync();
        await audit.LogAsync(user, "حذف", "تأمین‌کننده", id.ToString(), vendor.Name);
        return new CheckResult(true, "تأمین‌کننده حذف شد.");
    }
}
