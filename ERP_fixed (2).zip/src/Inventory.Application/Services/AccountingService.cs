using Inventory.Application.Common;
using Inventory.Application.DTOs;
using Inventory.Domain.Entities;
using Inventory.Domain.Enums;
using Microsoft.EntityFrameworkCore;

namespace Inventory.Application.Services;

public interface IAccountingService
{
    Task<List<VoucherDto>> GetVouchersAsync();
    Task<VoucherDto?> GetVoucherAsync(int id);
    Task<CheckResult> PostFromInventoryAsync(int inventoryDocumentId, UserInfo user);
}

/// <summary>
/// اتصال انبار به حسابداری — تولید خودکار سند حسابداری از سند انبار
/// با استفاده از حساب‌های پیش‌فرض ساده (قابل توسعه در ماژول حسابداری کامل)
/// </summary>
public class AccountingService(IAppDbContext db) : IAccountingService
{
    public async Task<List<VoucherDto>> GetVouchersAsync() =>
        (await db.AccountingVouchers.AsNoTracking()
            .Include(v => v.Lines)
            .OrderByDescending(v => v.Date).ThenByDescending(v => v.Id)
            .ToListAsync())
        .Select(ToDto).ToList();

    public async Task<VoucherDto?> GetVoucherAsync(int id) =>
        ToDto(await db.AccountingVouchers.AsNoTracking()
            .Include(v => v.Lines)
            .FirstOrDefaultAsync(v => v.Id == id) ?? throw new InvalidOperationException("سند حسابداری یافت نشد."));

    public async Task<CheckResult> PostFromInventoryAsync(int inventoryDocumentId, UserInfo user)
    {
        if (user.Role == UserRole.Storekeeper)
            return new CheckResult(false, "انباردار مجاز به صدور سند حسابداری نیست.");

        var document = await db.InventoryDocuments
            .Include(d => d.Lines).ThenInclude(l => l.Product)
            .Include(d => d.Warehouse)
            .FirstOrDefaultAsync(d => d.Id == inventoryDocumentId);
        if (document is null) return new CheckResult(false, "سند انبار یافت نشد.");
        if (document.Status != DocumentStatus.Confirmed)
            return new CheckResult(false, "فقط سند تأییدشده قابل ثبت در حسابداری است.");
        if (document.IsPostedToAccounting)
            return new CheckResult(false, "این سند قبلاً در حسابداری ثبت شده است.");
        if (!document.Lines.Any())
            return new CheckResult(false, "سند بدون ردیف قابل ثبت نیست.");

        var lines = BuildVoucherLines(document);
        if (lines.Count < 2)
            return new CheckResult(false, "امکان ساخت ردیف‌های حسابداری وجود ندارد.");

        var totalDebit = lines.Sum(l => l.Debit);
        var totalCredit = lines.Sum(l => l.Credit);
        if (Math.Abs(totalDebit - totalCredit) > 0.01m)
            return new CheckResult(false, "سند حسابداری تراز نیست — با پشتیبان تماس بگیرید.");

        var voucher = new AccountingVoucher
        {
            Number = NextVoucherNumber(),
            Date = document.Date,
            SourceType = "InventoryDocument",
            SourceId = document.Id,
            Description = $"سند حسابداری ناشی از {document.Type.Title()} {document.Number}",
            CreatedBy = user.DisplayName,
            CreatedAt = DateTime.Now
        };

        foreach (var line in lines)
        {
            voucher.Lines.Add(new AccountingVoucherLine
            {
                AccountCode = line.AccountCode,
                AccountTitle = line.AccountTitle,
                Debit = line.Debit,
                Credit = line.Credit
            });
        }

        db.AccountingVouchers.Add(voucher);
        await db.SaveChangesAsync();

        document.IsPostedToAccounting = true;
        document.AccountingVoucherId = voucher.Id;
        await db.SaveChangesAsync();

        return new CheckResult(true, $"سند حسابداری {voucher.Number} با موفقیت صادر شد.");
    }

    // ============ ساخت ردیف‌های سند بر اساس نوع سند انبار ============

    private record VLine(string AccountCode, string AccountTitle, decimal Debit, decimal Credit);

    private List<VLine> BuildVoucherLines(InventoryDocument document)
    {
        var totalCost = document.Lines.Sum(l => l.Quantity * l.UnitCost);
        var totalPrice = document.Lines.Sum(l => l.Quantity * l.UnitPrice);
        var lines = new List<VLine>();

        switch (document.Type)
        {
            // --- ورودها: بدهکار کالا / بستانکار طرف حساب ---
            case DocumentType.PurchaseReceipt:
            case DocumentType.SalesReturnReceipt:
            case DocumentType.ProductionReceipt:
            case DocumentType.OpeningReceipt:
                lines.Add(new VLine("1500", "حساب کالا", totalCost, 0));
                lines.Add(new VLine("2100", "حساب تأمین‌کنندگان و طرف حساب", 0, totalPrice));
                AddDiffLine(lines, totalCost - totalPrice);
                break;

            // --- انتقال بین انبار: بدهکار کالای در جریان انتقال / بستانکار کالا ---
            case DocumentType.TransferIssue:
            case DocumentType.TransferReceipt:
                lines.Add(new VLine("1505", "کالای در جریان انتقال", totalCost, 0));
                lines.Add(new VLine("1500", "حساب کالا", 0, totalCost));
                break;

            // --- فروش: بدهکار مشتری / بستانکار فروش + بدهکار بهای تمام‌شده / بستانکار کالا ---
            case DocumentType.SalesIssue:
                lines.Add(new VLine("1100", "حساب مشتریان", totalPrice, 0));
                lines.Add(new VLine("4100", "حساب فروش", 0, totalPrice));
                lines.Add(new VLine("6100", "بهای تمام‌شده‌ی کالای فروش‌رفته", totalCost, 0));
                lines.Add(new VLine("1500", "حساب کالا", 0, totalCost));
                break;

            case DocumentType.ProductionIssue:
                lines.Add(new VLine("1501", "کالای در جریان ساخت", totalCost, 0));
                lines.Add(new VLine("1500", "حساب کالا", 0, totalCost));
                break;

            case DocumentType.PurchaseReturnIssue:
                lines.Add(new VLine("2100", "حساب تأمین‌کنندگان و طرف حساب", totalPrice, 0));
                lines.Add(new VLine("1500", "حساب کالا", 0, totalCost));
                AddDiffLine(lines, totalPrice - totalCost);
                break;

            case DocumentType.ScrapIssue:
                lines.Add(new VLine("5290", "حساب ضایعات و اسقاط", totalCost, 0));
                lines.Add(new VLine("1500", "حساب کالا", 0, totalCost));
                break;

            case DocumentType.InternalUseIssue:
                lines.Add(new VLine("6200", "حساب مصارف داخلی", totalCost, 0));
                lines.Add(new VLine("1500", "حساب کالا", 0, totalCost));
                break;

            // --- تعدیل انبارگردانی: مازاد / کسری ---
            case DocumentType.AdjustmentReceipt:
                lines.Add(new VLine("1500", "حساب کالا", totalCost, 0));
                lines.Add(new VLine("5292", "مازاد انبارگردانی", 0, totalCost));
                break;

            case DocumentType.AdjustmentIssue:
                lines.Add(new VLine("5291", "کسری انبارگردانی", totalCost, 0));
                lines.Add(new VLine("1500", "حساب کالا", 0, totalCost));
                break;

            // --- کالای امانی: ورود / بازپس‌گیری ---
            case DocumentType.ConsignmentReceipt:
                lines.Add(new VLine("1500", "حساب کالا (امانی)", totalCost, 0));
                lines.Add(new VLine("2100", "حساب تأمین‌کنندگان و طرف حساب", 0, totalPrice));
                AddDiffLine(lines, totalCost - totalPrice);
                break;

            case DocumentType.ConsignmentReturn:
                lines.Add(new VLine("2100", "حساب تأمین‌کنندگان و طرف حساب", totalPrice, 0));
                lines.Add(new VLine("1500", "حساب کالا (امانی)", 0, totalCost));
                AddDiffLine(lines, totalPrice - totalCost);
                break;
        }

        return lines;
    }

    /// <summary>ردیف مابه‌التفاوت قیمت خرید و بهای تمام‌شده (برای تراز شدن سند)</summary>
    private static void AddDiffLine(List<VLine> lines, decimal diff)
    {
        if (Math.Abs(diff) < 0.01m) return;
        if (diff > 0)
            lines.Add(new VLine("5300", "حساب تفاوت خرید", diff, 0));
        else
            lines.Add(new VLine("5299", "حساب تخفیف و تشویقات", 0, -diff));
    }

    private string NextVoucherNumber()
    {
        var year = DateTime.Now.Year;
        // شماره‌ها را به حافظه می‌آوریم (SQLite نمی‌تواند این تبدیل را در سمت سرور انجام دهد)
        var numbers = db.AccountingVouchers.AsNoTracking()
            .Where(v => v.Date.Year == year)
            .Select(v => v.Number)
            .ToList();

        var max = 0;
        foreach (var number in numbers)
        {
            var i = number.LastIndexOf('-');
            var tail = i >= 0 ? number[(i + 1)..] : number;
            if (int.TryParse(tail, out var n) && n > max) max = n;
        }

        return $"ACC-{year:0000}-{max + 1:0000}";
    }

    private static VoucherDto ToDto(AccountingVoucher v) => new(
        v.Id, v.Number, v.Date.ToFa(), v.SourceId, v.Source?.Number,
        v.Source != null ? v.Source.Type.Title() : "",
        v.Description, v.CreatedBy, v.TotalDebit, v.TotalCredit,
        v.Lines.Select(l => new VoucherLineDto(l.AccountCode, l.AccountTitle, l.Debit, l.Credit)).ToList());
}
