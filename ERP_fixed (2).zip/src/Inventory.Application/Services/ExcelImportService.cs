using Inventory.Application.DTOs;
using System.Text;
using Inventory.Application.Common;
using Inventory.Domain.Entities;
using Inventory.Domain.Enums;
using Microsoft.EntityFrameworkCore;

namespace Inventory.Application.Services;

public interface IExcelImportService
{
    /// <summary>ورود گروه‌های کالا از اکسل (Upsert بر اساس کد گروه)</summary>
    Task<ExcelImportResultDto> ImportGroupsAsync(Stream stream, string? user = null);

    /// <summary>ورود کالاها از اکسل (Upsert بر اساس کد کالا)</summary>
    Task<ExcelImportResultDto> ImportProductsAsync(Stream stream, string? user = null);

    /// <summary>ورود BOM از اکسل (هر کد محصول = یک BOM با ردیف‌هایش)</summary>
    Task<ExcelImportResultDto> ImportBomsAsync(Stream stream, string? user = null);
}

/// <summary>ورود اکسل گروه کالا / کالا / BOM — خواننده‌ی xlsx خالص + Upsert با اعتبارسنجی سطری</summary>
public class ExcelImportService(IAppDbContext db, IAuditService audit) : IExcelImportService
{
    // ==================== ۱) گروه‌های کالا ====================
    public async Task<ExcelImportResultDto> ImportGroupsAsync(Stream stream, string? user = null)
    {
        ExcelSheet sheet;
        try { sheet = ExcelReader.ReadFirstSheet(stream); }
        catch (Exception ex) { return Fail("فایل خوانده نشد: " + ex.Message); }

        if (sheet.Rows.Count == 0) return Fail("فایل هیچ ردیف داده‌ای ندارد.");
        var missing = new[] { "کد گروه", "نام گروه" }.Where(h => !sheet.HasHeader(h)).ToList();
        if (missing.Count > 0)
            return Fail("ستون‌های الزامی یافت نشد: " + string.Join("، ", missing) + " — از فایل نمونه استفاده کنید.");

        var result = new ExcelImportResultDto();
        var groups = await db.ProductGroups.ToListAsync();
        var byCode = groups.Where(g => g.Code != "")
            .GroupBy(g => ExcelReader.Norm(g.Code)).ToDictionary(g => g.Key, g => g.First());
        var seen = new HashSet<string>();
        var parentLinks = new List<(ProductGroup Group, string ParentCode)>();

        foreach (var row in sheet.Rows)
        {
            var n = row.RowNumber;
            var code = row.Get("کد گروه").Trim();
            var title = row.Get("نام گروه").Trim();
            if (code == "" || title == "")
            {
                result.Errors.Add($"ردیف {n}: «کد گروه» و «نام گروه» الزامی است.");
                continue;
            }
            var key = ExcelReader.Norm(code);
            if (!seen.Add(key))
            {
                result.Errors.Add($"ردیف {n}: کد گروه «{code}» در فایل تکراری است.");
                continue;
            }

            if (!byCode.TryGetValue(key, out var g))
            {
                g = new ProductGroup { Code = code };
                db.ProductGroups.Add(g);
                byCode[key] = g;
                result.Created++;
            }
            else result.Updated++;

            g.Title = title;
            var active = ExcelReader.ParseBool(row.Get("فعال"));
            if (active.HasValue) g.IsActive = active.Value;
            var desc = row.Get("توضیح").Trim();
            if (desc != "") g.Description = desc;

            var parent = row.Get("گروه والد").Trim();
            if (parent != "") parentLinks.Add((g, parent));
        }

        // تشخیص چرخه‌ی درختی در فایل (A→B→A) قبل از اتصال
        var parentByKey = parentLinks.ToDictionary(x => ExcelReader.Norm(x.Group.Code), x => ExcelReader.Norm(x.ParentCode));
        var cyclic = new HashSet<string>();
        foreach (var start in parentByKey.Keys)
        {
            var visited = new HashSet<string> { start };
            var cur = parentByKey.GetValueOrDefault(start);
            while (cur != null && visited.Add(cur))
                cur = parentByKey.GetValueOrDefault(cur);
            if (cur != null) cyclic.Add(start);
        }

        foreach (var (g, parentCode) in parentLinks)
        {
            var childKey = ExcelReader.Norm(g.Code);
            var parentKey = ExcelReader.Norm(parentCode);
            if (parentKey == childKey || cyclic.Contains(childKey))
            {
                result.Warnings.Add($"«{g.Title}»: حلقه‌ی والد-فرزندی در فایل؛ والد نادیده گرفته شد.");
                continue;
            }
            if (byCode.TryGetValue(parentKey, out var parent))
            {
                g.Parent = parent; // ناوبری → درجِ والد قبل از فرزند
                if (parent.Id > 0) g.ParentId = parent.Id;
            }
            else
                result.Warnings.Add($"«{g.Title}»: گروه والد «{parentCode}» یافت نشد؛ بدون والد ذخیره شد.");
        }

        await db.SaveChangesAsync();
        await audit.LogAsync(user, "ورود گروه کالا از اکسل", "ProductGroup", null,
            $"ایجاد {result.Created}، ویرایش {result.Updated}، خطا {result.Errors.Count}");

        result.Ok = true;
        result.Message = $"ورود گروه‌ها کامل شد — {result.Created} گروه جدید، {result.Updated} به‌روزرسانی"
            + (result.Errors.Count > 0 ? $" — {result.Errors.Count} ردیف خطا" : "")
            + (result.Warnings.Count > 0 ? $" — {result.Warnings.Count} هشدار" : "");
        return result;
    }

    // ==================== ۲) کالاها ====================
    public async Task<ExcelImportResultDto> ImportProductsAsync(Stream stream, string? user = null)
    {
        ExcelSheet sheet;
        try { sheet = ExcelReader.ReadFirstSheet(stream); }
        catch (Exception ex) { return Fail("فایل خوانده نشد: " + ex.Message); }

        if (sheet.Rows.Count == 0) return Fail("فایل هیچ ردیف داده‌ای ندارد.");
        var missing = new[] { "کد", "نام", "گروه", "واحد اصلی" }.Where(h => !sheet.HasHeader(h)).ToList();
        if (missing.Count > 0)
            return Fail("ستون‌های الزامی یافت نشد: " + string.Join("، ", missing) + " — از فایل نمونه استفاده کنید.");

        var result = new ExcelImportResultDto();

        var groups = await db.ProductGroups.ToListAsync();
        var groupByCode = groups.Where(g => g.Code != "")
            .GroupBy(g => ExcelReader.Norm(g.Code)).ToDictionary(g => g.Key, g => g.First().Id);
        var groupByTitle = groups.GroupBy(g => ExcelReader.Norm(g.Title)).ToDictionary(g => g.Key, g => g.First().Id);

        var unitTitles = await db.Units.Select(u => new { u.Id, u.Title }).ToListAsync();
        var unitByTitle = unitTitles.GroupBy(u => ExcelReader.Norm(u.Title)).ToDictionary(g => g.Key, g => g.First().Id);

        var vendors = await db.Vendors.ToListAsync();
        var vendorByCode = vendors.Where(v => v.Code != "")
            .GroupBy(v => ExcelReader.Norm(v.Code)).ToDictionary(g => g.Key, g => g.First().Id);
        var vendorByName = vendors.GroupBy(v => ExcelReader.Norm(v.Name)).ToDictionary(g => g.Key, g => g.First().Id);

        var products = await db.Products.ToListAsync(); // tracked برای Upsert
        var byCode = products.Where(p => p.Code != "")
            .GroupBy(p => ExcelReader.Norm(p.Code)).ToDictionary(g => g.Key, g => g.First());
        var seen = new HashSet<string>();
        var unitHint = string.Join("، ", unitTitles.Select(u => u.Title).Take(8));

        foreach (var row in sheet.Rows)
        {
            var n = row.RowNumber;
            var code = row.Get("کد").Trim();
            var name = row.Get("نام").Trim();
            if (code == "" || name == "")
            {
                result.Errors.Add($"ردیف {n}: «کد» و «نام» کالا الزامی است.");
                continue;
            }
            var key = ExcelReader.Norm(code);
            if (!seen.Add(key))
            {
                result.Errors.Add($"ردیف {n}: کد کالا «{code}» در فایل تکراری است.");
                continue;
            }

            // --- گروه (کد یا نام) ---
            var groupText = row.Get("گروه").Trim();
            int groupId;
            if (groupText == "")
            {
                result.Errors.Add($"ردیف {n} ({code}): «گروه» الزامی است.");
                continue;
            }
            else if (!groupText.Contains(' ') && groupByCode.TryGetValue(ExcelReader.Norm(groupText), out var gid)) groupId = gid;
            else if (groupByCode.TryGetValue(ExcelReader.Norm(groupText), out gid)) groupId = gid;
            else if (groupByTitle.TryGetValue(ExcelReader.Norm(groupText), out gid)) groupId = gid;
            else
            {
                result.Errors.Add($"ردیف {n} ({code}): گروه «{groupText}» یافت نشد — اول گروه‌ها را وارد کنید.");
                continue;
            }

            // --- واحد اصلی ---
            var unitText = row.Get("واحد اصلی").Trim();
            if (unitText == "" || !unitByTitle.TryGetValue(ExcelReader.Norm(unitText), out var unitId))
            {
                result.Errors.Add($"ردیف {n} ({code}): واحد «{unitText}» یافت نشد (واحدهای موجود: {unitHint}).");
                continue;
            }

            // --- Upsert ---
            var isNew = !byCode.TryGetValue(key, out var p);
            if (isNew)
            {
                p = new Product
                {
                    Code = code,
                    Procurement = ProcurementType.Buy,
                    LotSizing = LotSizingPolicy.LotForLot,
                    ValuationMethod = ValuationMethod.Average,
                    IsActive = true,
                };
                db.Products.Add(p);
                byCode[key] = p;
                result.Created++;
            }
            else result.Updated++;

            p.Name = name;
            p.GroupId = groupId;
            p.MainUnitId = unitId;

            var latin = row.Get("نام لاتین").Trim();
            if (latin != "") p.LatinName = latin;
            var barcode = ExcelReader.FixDigits(row.Get("بارکد"));
            if (barcode != "") p.Barcode = barcode;
            var desc = row.Get("توضیح").Trim();
            if (desc != "") p.Description = desc;

            // نوع کالا
            var typeText = row.Get("نوع کالا").Trim();
            if (typeText != "")
            {
                var type = ParseType(typeText);
                if (type is null)
                    result.Warnings.Add($"ردیف {n} ({code}): نوع کالا «{typeText}» شناخته نشد؛ نوع قبلی حفظ شد.");
                else p.Type = type.Value;
            }

            // روش ارزشیابی
            var valText = row.Get("روش ارزشیابی").Trim();
            if (valText != "")
            {
                var v = ExcelReader.Norm(valText);
                if (v.Contains("میانگین")) p.ValuationMethod = ValuationMethod.Average;
                else if (v.Contains("فیف") || v.Contains("fifo") || v.Contains("فایف")) p.ValuationMethod = ValuationMethod.Fifo;
                else result.Warnings.Add($"ردیف {n} ({code}): روش ارزشیابی «{valText}» شناخته نشد؛ روش قبلی حفظ شد.");
            }

            // اعداد
            void SetDec(string header, Action<decimal> set)
            {
                var v = ExcelReader.ParseDec(row.Get(header));
                if (v.HasValue) set(v.Value);
                else if (row.Get(header).Trim() != "")
                    result.Errors.Add($"ردیف {n} ({code}): مقدار «{row.Get(header)}» در ستون «{header}» عدد معتبر نیست.");
            }
            SetDec("قیمت خرید", v => p.PurchasePrice = v);
            SetDec("قیمت فروش", v => p.SalePrice = v);
            SetDec("نقطه سفارش", v => p.ReorderPoint = v);
            SetDec("حداقل موجودی", v => p.MinStock = v);
            SetDec("حداکثر موجودی", v => p.MaxStock = v);
            SetDec("موجودی اطمینان", v => p.SafetyStock = v);
            SetDec("تعداد ثابت سفارش", v => p.FixedOrderQty = v);
            SetDec("حداقل مقدار سفارش", v => p.MinOrderQty = v);
            SetDec("درصد ضایعات", v => p.ScrapPercent = v);
            var lt = ExcelReader.ParseInt(row.Get("زمان تحویل (روز)"));
            if (lt.HasValue) p.LeadTimeDays = lt.Value;

            // بولی‌ها
            bool? bv;
            if ((bv = ExcelReader.ParseBool(row.Get("رهگیری سریال"))).HasValue) p.TrackSerial = bv.Value;
            if ((bv = ExcelReader.ParseBool(row.Get("رهگیری انقضا"))).HasValue) p.TrackExpiry = bv.Value;
            if ((bv = ExcelReader.ParseBool(row.Get("رهگیری لوت"))).HasValue) p.TrackLot = bv.Value;
            if ((bv = ExcelReader.ParseBool(row.Get("فعال"))).HasValue) p.IsActive = bv.Value;

            // پارامترهای MRP
            var procText = row.Get("روش تأمین").Trim();
            if (procText != "")
            {
                var v = ExcelReader.Norm(procText);
                if (v.Contains("ساخت") || v.Contains("make") || v.Contains("تولید")) p.Procurement = ProcurementType.Make;
                else if (v.Contains("خرید") || v.Contains("buy")) p.Procurement = ProcurementType.Buy;
                else result.Warnings.Add($"ردیف {n} ({code}): روش تأمین «{procText}» شناخته نشد (خرید/ساخت).");
            }
            var lotText = row.Get("سیاست اندازه سفارش").Trim();
            if (lotText != "")
            {
                var v = ExcelReader.Norm(lotText);
                if (v.Contains("ثابت") || v.Contains("foq")) p.LotSizing = LotSizingPolicy.FixedQty;
                else if (v.Contains("مقدار") || v.Contains("l4l") || v.Contains("lot")) p.LotSizing = LotSizingPolicy.LotForLot;
                else result.Warnings.Add($"ردیف {n} ({code}): سیاست «{lotText}» شناخته نشد (مقدار به مقدار/تعداد ثابت).");
            }

            // تأمین‌کننده‌ی پیش‌فرض (کد یا نام) — اگر نبود فقط هشدار
            var vendorText = row.Get("تأمین‌کننده").Trim();
            if (vendorText != "")
            {
                var vk = ExcelReader.Norm(vendorText);
                if (vendorByCode.TryGetValue(vk, out var vid) || vendorByName.TryGetValue(vk, out vid))
                    p.DefaultVendorId = vid;
                else
                    result.Warnings.Add($"ردیف {n} ({code}): تأمین‌کننده «{vendorText}» یافت نشد؛ خالی ماند.");
            }
        }

        await db.SaveChangesAsync();
        await audit.LogAsync(user, "ورود کالا از اکسل", "Product", null,
            $"ایجاد {result.Created}، ویرایش {result.Updated}، خطا {result.Errors.Count}");

        result.Ok = true;
        result.Message = $"ورود کالاها کامل شد — {result.Created} کالای جدید، {result.Updated} به‌روزرسانی"
            + (result.Errors.Count > 0 ? $" — {result.Errors.Count} ردیف خطا" : "")
            + (result.Warnings.Count > 0 ? $" — {result.Warnings.Count} هشدار" : "");
        return result;
    }

    // ==================== ۳) BOM ====================
    public async Task<ExcelImportResultDto> ImportBomsAsync(Stream stream, string? user = null)
    {
        ExcelSheet sheet;
        try { sheet = ExcelReader.ReadFirstSheet(stream); }
        catch (Exception ex) { return Fail("فایل خوانده نشد: " + ex.Message); }

        if (sheet.Rows.Count == 0) return Fail("فایل هیچ ردیف داده‌ای ندارد.");
        var missing = new[] { "کد محصول", "کد قطعه", "مقدار" }.Where(h => !sheet.HasHeader(h)).ToList();
        if (missing.Count > 0)
            return Fail("ستون‌های الزامی یافت نشد: " + string.Join("، ", missing) + " — از فایل نمونه استفاده کنید.");

        var result = new ExcelImportResultDto();
        var products = await db.Products.AsNoTracking()
            .ToDictionaryAsync(p => ExcelReader.Norm(p.Code), p => p);

        // تجمیع ردیف‌ها بر اساس کد محصول (به ترتیب فایل)
        var ordered = new List<string>();
        var byProduct = new Dictionary<string, List<(int RowNumber, string ComponentCode, decimal Qty)>>();
        foreach (var row in sheet.Rows)
        {
            var n = row.RowNumber;
            var prodCode = row.Get("کد محصول").Trim();
            var compCode = row.Get("کد قطعه").Trim();
            var qty = ExcelReader.ParseDec(row.Get("مقدار"));

            if (prodCode == "" || compCode == "")
            {
                result.Errors.Add($"ردیف {n}: «کد محصول» و «کد قطعه» الزامی است.");
                continue;
            }
            if (qty is null || qty <= 0)
            {
                result.Errors.Add($"ردیف {n}: «مقدار» باید عددی بزرگ‌تر از صفر باشد.");
                continue;
            }
            if (!products.ContainsKey(ExcelReader.Norm(prodCode)))
            {
                result.Errors.Add($"ردیف {n}: کالای محصول «{prodCode}» یافت نشد — اول کالاها را وارد کنید.");
                continue;
            }
            if (!products.TryGetValue(ExcelReader.Norm(compCode), out var comp))
            {
                result.Errors.Add($"ردیف {n}: کالای قطعه «{compCode}» یافت نشد.");
                continue;
            }
            if (ExcelReader.Norm(compCode) == ExcelReader.Norm(prodCode))
            {
                result.Errors.Add($"ردیف {n}: کالا نمی‌تواند جزء خودش باشد.");
                continue;
            }

            var pk = ExcelReader.Norm(prodCode);
            if (!byProduct.TryGetValue(pk, out var list))
            {
                byProduct[pk] = list = new();
                ordered.Add(pk);
            }
            list.Add((n, ExcelReader.Norm(compCode), qty.Value));
        }

        // درون هر محصول، قطعه‌ی تکراری جمع می‌شود
        var bomMap = await db.Boms.Include(b => b.Lines).ToListAsync();
        var activeBoms = bomMap.Where(b => b.IsActive)
            .GroupBy(b => b.ProductId).ToDictionary(g => g.Key, g => g.ToList());

        foreach (var pk in ordered)
        {
            var product = products[pk];
            var lines = new List<BomLine>();
            var perComp = new Dictionary<string, decimal>();
            foreach (var (n, ck, qty) in byProduct[pk])
            {
                if (!perComp.TryAdd(ck, qty))
                {
                    perComp[ck] += qty;
                    result.Warnings.Add($"«{product.Name}»: قطعه‌ی «{products[ck].Name}» چندبار آمده؛ مقدارها جمع شد (ردیف {n}).");
                }
            }
            foreach (var (ck, qty) in perComp)
                lines.Add(new BomLine { ComponentProductId = products[ck].Id, Quantity = qty });

            if (activeBoms.TryGetValue(product.Id, out var existing))
            {
                var main = existing[0];
                db.BomLines.RemoveRange(main.Lines);
                foreach (var l in lines) main.Lines.Add(l);
                result.Updated++;
                foreach (var extra in existing.Skip(1))
                {
                    extra.IsActive = false;
                    result.Warnings.Add($"«{product.Name}»: چند BOM فعال داشت؛ بقیه غیرفعال شدند.");
                }
            }
            else
            {
                db.Boms.Add(new Bom
                {
                    ProductId = product.Id,
                    Title = $"BOM «{product.Name}»",
                    IsActive = true,
                    Lines = lines,
                });
                result.Created++;
            }
        }

        await db.SaveChangesAsync();
        await audit.LogAsync(user, "ورود BOM از اکسل", "Bom", null,
            $"ایجاد {result.Created}، به‌روزرسانی {result.Updated}، خطا {result.Errors.Count}");

        result.Ok = true;
        result.Message = $"ورود BOM کامل شد — {result.Created} BOM جدید، {result.Updated} به‌روزرسانی"
            + (result.Errors.Count > 0 ? $" — {result.Errors.Count} ردیف خطا" : "")
            + (result.Warnings.Count > 0 ? $" — {result.Warnings.Count} هشدار" : "");
        return result;
    }

    // ---------- ابزارک‌ها ----------
    private static ProductType? ParseType(string text)
    {
        var s = ExcelReader.Norm(text);
        if (s == "") return null;
        if (s.Contains("مواد اولیه") || s.Contains("raw")) return ProductType.RawMaterial;
        if (s.Contains("واسطه") || s.Contains("نیمساخته") || s.Contains("semi")) return ProductType.SemiFinished;
        if (s.Contains("نهایی") || s.Contains("finished") || s.Contains("تولیدی")) return ProductType.Finished;
        if (s.Contains("امانی")) return ProductType.Consignment;
        if (s.Contains("ضایعات") || s.Contains("scrap")) return ProductType.Scrap;
        if (s.Contains("خدمت") || s.Contains("service")) return ProductType.Service;
        return null;
    }

    private static ExcelImportResultDto Fail(string message) =>
        new() { Ok = false, Message = message };
}
