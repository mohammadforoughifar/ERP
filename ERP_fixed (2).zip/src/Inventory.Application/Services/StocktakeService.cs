using Inventory.Application.Common;
using Inventory.Application.DTOs;
using Inventory.Domain.Entities;
using Inventory.Domain.Enums;
using Microsoft.EntityFrameworkCore;

namespace Inventory.Application.Services;

public interface IStocktakeService
{
    Task<List<StocktakeDto>> GetListAsync();
    Task<StocktakeDto> GetAsync(int id);
    Task<List<StocktakeLineDto>> GetLinesAsync(int id);
    Task<CheckResult> CreateAsync(int warehouseId, DateTime date, string? description, UserInfo user);
    Task<CheckResult> SaveCountsAsync(int id, List<CountInput> counts, UserInfo user);
    Task<CheckResult> VerifyAsync(int id, UserInfo user);
    Task<CheckResult> PostAdjustmentsAsync(int id, UserInfo user);
    Task<CheckResult> DeleteAsync(int id, UserInfo user);
}

/// <summary>ورودی شمارش ردیف (شمارش اول / دوم + علت مغایرت)</summary>
public record CountInput(int LineId, decimal? Counted, decimal? Counted2, string? Reason);

/// <summary>
/// انبارگردانی — صدور برگه‌ی شمارش، دو شمارش مستقل، محاسبه‌ی مغایرت و صدور سند تعدیل
/// </summary>
public class StocktakeService(IAppDbContext db) : IStocktakeService
{
    public async Task<List<StocktakeDto>> GetListAsync()
    {
        var list = await db.Stocktakes.AsNoTracking()
            .Include(s => s.Warehouse)
            .Include(s => s.Lines)
            .OrderByDescending(s => s.Date).ThenByDescending(s => s.Id)
            .ToListAsync();

        return list.Select(s => new StocktakeDto
        {
            Id = s.Id,
            Number = s.Number,
            WarehouseId = s.WarehouseId,
            WarehouseTitle = s.Warehouse.Title,
            Date = s.Date,
            DateFa = s.Date.ToFa(),
            Status = s.Status,
            StatusTitle = s.Status.Title(),
            Description = s.Description,
            CreatedBy = s.CreatedBy,
            CreatedAt = s.CreatedAt,
            VerifiedBy = s.VerifiedBy,
            LineCount = s.Lines.Count,
            DifferenceCount = s.Lines.Count(l => Math.Abs(l.Difference) > 0.001m)
        }).ToList();
    }

    public async Task<StocktakeDto> GetAsync(int id)
    {
        var s = await db.Stocktakes.AsNoTracking()
            .Include(s => s.Warehouse)
            .Include(s => s.Lines)
            .FirstOrDefaultAsync(s => s.Id == id) ?? throw new InvalidOperationException("برگه‌ی انبارگردانی یافت نشد.");
        return new StocktakeDto
        {
            Id = s.Id,
            Number = s.Number,
            WarehouseId = s.WarehouseId,
            WarehouseTitle = s.Warehouse.Title,
            Date = s.Date,
            DateFa = s.Date.ToFa(),
            Status = s.Status,
            StatusTitle = s.Status.Title(),
            Description = s.Description,
            CreatedBy = s.CreatedBy,
            CreatedAt = s.CreatedAt,
            VerifiedBy = s.VerifiedBy,
            LineCount = s.Lines.Count,
            DifferenceCount = s.Lines.Count(l => Math.Abs(l.Difference) > 0.001m)
        };
    }

    public async Task<List<StocktakeLineDto>> GetLinesAsync(int id)
    {
        var lines = await db.StocktakeLines.AsNoTracking()
            .Include(l => l.Product).ThenInclude(p => p.MainUnit)
            .Where(l => l.StocktakeId == id)
            .OrderBy(l => l.Product.Code)
            .ToListAsync();

        return lines.Select(l => new StocktakeLineDto
        {
            Id = l.Id,
            ProductId = l.ProductId,
            ProductCode = l.Product.Code,
            ProductName = l.Product.Name,
            UnitTitle = l.Product.MainUnit?.Title ?? "",
            BookQuantity = l.BookQuantity,
            CountedQuantity = l.CountedQuantity,
            CountedQuantity2 = l.CountedQuantity2,
            Difference = l.Difference,
            Reason = l.Reason,
            AdjustmentDocumentId = l.AdjustmentDocumentId
        }).ToList();
    }

    public async Task<CheckResult> CreateAsync(int warehouseId, DateTime date, string? description, UserInfo user)
    {
        if (warehouseId <= 0) return new CheckResult(false, "انبار را انتخاب کنید.");

        // موجودی فعلی انبار برای پیش‌پر کردن برگه
        var items = await db.WarehouseItems.AsNoTracking()
            .Include(w => w.Product)
            .Where(w => w.WarehouseId == warehouseId && w.Quantity > 0)
            .OrderBy(w => w.Product.Code)
            .ToListAsync();

        var stocktake = new Stocktake
        {
            Number = NextNumber(),
            WarehouseId = warehouseId,
            Date = date,
            Description = description,
            CreatedBy = user.DisplayName,
            CreatedAt = DateTime.Now,
            Status = StocktakeStatus.Draft
        };

        foreach (var item in items)
        {
            stocktake.Lines.Add(new StocktakeLine
            {
                ProductId = item.ProductId,
                BookQuantity = item.Quantity
            });
        }

        db.Stocktakes.Add(stocktake);
        await db.SaveChangesAsync();
        return new CheckResult(true, $"برگه‌ی شمارش {stocktake.Number} صادر شد ({stocktake.Lines.Count} قلم).");
    }

    public async Task<CheckResult> SaveCountsAsync(int id, List<CountInput> counts, UserInfo user)
    {
        var stocktake = await db.Stocktakes.Include(s => s.Lines).FirstOrDefaultAsync(s => s.Id == id);
        if (stocktake is null) return new CheckResult(false, "برگه یافت نشد.");
        if (stocktake.Status >= StocktakeStatus.Verified)
            return new CheckResult(false, "پس از تأیید، شمارش قابل ویرایش نیست.");

        foreach (var input in counts)
        {
            var line = stocktake.Lines.FirstOrDefault(l => l.Id == input.LineId);
            if (line is null) continue;
            if (input.Counted is not null)
            {
                if (input.Counted < 0) return new CheckResult(false, "تعداد شمارش نمی‌تواند منفی باشد.");
                line.CountedQuantity = input.Counted;
            }
            if (input.Counted2 is not null)
            {
                if (input.Counted2 < 0) return new CheckResult(false, "تعداد شمارش نمی‌تواند منفی باشد.");
                line.CountedQuantity2 = input.Counted2;
            }
            if (input.Reason is not null) line.Reason = input.Reason;
        }

        if (stocktake.Status == StocktakeStatus.Draft)
            stocktake.Status = StocktakeStatus.Counted;

        await db.SaveChangesAsync();
        return new CheckResult(true, "شمارش ذخیره شد.");
    }

    public async Task<CheckResult> VerifyAsync(int id, UserInfo user)
    {
        if (user.Role == UserRole.Storekeeper)
            return new CheckResult(false, "تأیید شمارش باید توسط نفر دوم (مدیر/حسابدار) انجام شود.");

        var stocktake = await db.Stocktakes.Include(s => s.Lines).FirstOrDefaultAsync(s => s.Id == id);
        if (stocktake is null) return new CheckResult(false, "برگه یافت نشد.");
        if (stocktake.Status >= StocktakeStatus.Verified)
            return new CheckResult(false, "شمارش قبلاً تأیید شده است.");
        if (stocktake.Status < StocktakeStatus.Counted)
            return new CheckResult(false, "ابتدا شمارش اول را ثبت کنید.");

        // شمارش دوم: اگر ثبت نشده، همان شمارش اول مبنا قرار می‌گیرد
        foreach (var line in stocktake.Lines.Where(l => l.CountedQuantity2 is null))
            line.CountedQuantity2 = line.CountedQuantity;

        stocktake.Status = StocktakeStatus.Verified;
        stocktake.VerifiedBy = user.DisplayName;
        stocktake.VerifiedAt = DateTime.Now;
        await db.SaveChangesAsync();

        var diffs = stocktake.Lines.Count(l => Math.Abs(l.Difference) > 0.001m);
        return new CheckResult(true, $"شمارش تأیید شد. تعداد مغایرت‌ها: {diffs} قلم");
    }

    public async Task<CheckResult> PostAdjustmentsAsync(int id, UserInfo user)
    {
        if (user.Role == UserRole.Storekeeper)
            return new CheckResult(false, "صدور سند تعدیل فقط توسط مدیر/حسابدار انجام می‌شود.");

        var stocktake = await db.Stocktakes
            .Include(s => s.Lines).ThenInclude(l => l.Product)
            .FirstOrDefaultAsync(s => s.Id == id);
        if (stocktake is null) return new CheckResult(false, "برگه یافت نشد.");
        if (stocktake.Status < StocktakeStatus.Verified)
            return new CheckResult(false, "ابتدا شمارش را تأیید کنید.");
        if (stocktake.Status == StocktakeStatus.Posted)
            return new CheckResult(false, "سندهای تعدیل قبلاً صادر شده‌اند.");

        var issued = 0;
        var docIds = new Dictionary<int, int>(); // lineId -> docId
        foreach (var line in stocktake.Lines)
        {
            var diff = line.Difference;
            if (Math.Abs(diff) < 0.001m) continue;

            // میانگین موزون انبار برای قیمت‌گذاری تعدیل
            var avg = await db.WarehouseItems
                .Where(w => w.WarehouseId == stocktake.WarehouseId && w.ProductId == line.ProductId)
                .Select(w => w.Quantity > 0 ? w.TotalCost / w.Quantity : 0)
                .FirstOrDefaultAsync();
            var price = avg > 0 ? avg : line.Product.PurchasePrice;

            var type = diff > 0 ? DocumentType.AdjustmentReceipt : DocumentType.AdjustmentIssue;
            var doc = new InventoryDocument
            {
                Number = DocumentNumberingService.NextNumber(db.InventoryDocuments.AsNoTracking(), DateTime.Now),
                Type = type,
                Status = DocumentStatus.Confirmed,
                Date = DateTime.Now,
                WarehouseId = stocktake.WarehouseId,
                Description = $"تعدیل ناشی از انبارگردانی {stocktake.Number}{(string.IsNullOrWhiteSpace(line.Reason) ? "" : $" — علت: {line.Reason}")}",
                CreatedBy = user.DisplayName,
                CreatedAt = DateTime.Now,
                ConfirmedBy = user.DisplayName,
                ConfirmedAt = DateTime.Now
            };
            doc.Lines.Add(new InventoryDocumentLine
            {
                ProductId = line.ProductId,
                Quantity = Math.Abs(diff),
                UnitPrice = price,
                UnitCost = price
            });

            // اعمال مستقیم روی موجودی
            var stock = await db.WarehouseItems
                .FirstOrDefaultAsync(w => w.WarehouseId == stocktake.WarehouseId && w.ProductId == line.ProductId);
            if (stock is null)
            {
                db.WarehouseItems.Add(new WarehouseItem
                {
                    WarehouseId = stocktake.WarehouseId,
                    ProductId = line.ProductId,
                    Quantity = diff,
                    TotalCost = price * Math.Abs(diff)
                });
            }
            else
            {
                stock.Quantity += diff;
                stock.TotalCost += price * diff; // مثبت برای مازاد، منفی برای کسری
                stock.UpdatedAt = DateTime.Now;
            }

            db.InventoryDocuments.Add(doc);
            docIds[line.Id] = doc.Id; // بعد از Save پر می‌شود
            issued++;
        }

        await db.SaveChangesAsync();

        // پیوند سند تعدیل به ردیف‌های شمارش
        foreach (var kv in docIds)
        {
            var line = stocktake.Lines.FirstOrDefault(l => l.Id == kv.Key);
            if (line is not null) line.AdjustmentDocumentId = kv.Value;
        }

        stocktake.Status = StocktakeStatus.Posted;
        stocktake.PostedAt = DateTime.Now;
        await db.SaveChangesAsync();

        return issued > 0
            ? new CheckResult(true, $"{issued} سند تعدیل صادر و روی موجودی اعمال شد.")
            : new CheckResult(true, "مغایرتی وجود نداشت؛ سندی صادر نشد.");
    }

    public async Task<CheckResult> DeleteAsync(int id, UserInfo user)
    {
        var stocktake = await db.Stocktakes.FirstOrDefaultAsync(s => s.Id == id);
        if (stocktake is null) return new CheckResult(false, "برگه یافت نشد.");
        if (stocktake.Status >= StocktakeStatus.Verified)
            return new CheckResult(false, "برگه‌ی تأییدشده قابل حذف نیست.");

        db.Stocktakes.Remove(stocktake);
        await db.SaveChangesAsync();
        return new CheckResult(true, "برگه حذف شد.");
    }

    private string NextNumber()
    {
        var year = FaDate.ToFaParts(DateTime.Now).Year;
        var numbers = db.Stocktakes.AsNoTracking()
            .Where(s => s.Number.StartsWith($"STK-{year}-"))
            .Select(s => s.Number).ToList();

        var max = 0;
        foreach (var n in numbers)
        {
            var i = n.LastIndexOf('-');
            if (i >= 0 && int.TryParse(n[(i + 1)..], out var seq) && seq > max) max = seq;
        }
        return $"STK-{year}-{max + 1:0000}";
    }
}
