using Inventory.Application.Common;
using Inventory.Application.DTOs;
using Inventory.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace Inventory.Application.Services;

public interface IWarehousesService
{
    Task<List<WarehouseDto>> GetAllAsync();
    Task<CheckResult> CreateAsync(Warehouse warehouse);
    Task<CheckResult> UpdateAsync(Warehouse warehouse);
    Task<CheckResult> DeleteAsync(int id);
}

public class WarehousesService(IAppDbContext db) : IWarehousesService
{
    public async Task<List<WarehouseDto>> GetAllAsync() =>
        await db.Warehouses.OrderBy(w => w.Code)
            .Select(w => new WarehouseDto(w.Id, w.Code, w.Title, w.ManagerName, w.Address, w.Phone, w.IsActive))
            .ToListAsync();

    public async Task<CheckResult> CreateAsync(Warehouse warehouse)
    {
        if (string.IsNullOrWhiteSpace(warehouse.Code) || string.IsNullOrWhiteSpace(warehouse.Title))
            return new CheckResult(false, "کد و عنوان انبار الزامی است.");
        if (await db.Warehouses.AnyAsync(w => w.Code == warehouse.Code))
            return new CheckResult(false, "این کد انبار قبلاً ثبت شده است.");

        db.Warehouses.Add(warehouse);
        await db.SaveChangesAsync();
        return new CheckResult(true, "انبار با موفقیت ثبت شد.");
    }

    public async Task<CheckResult> UpdateAsync(Warehouse warehouse)
    {
        var existing = await db.Warehouses.FindAsync(warehouse.Id);
        if (existing is null) return new CheckResult(false, "انبار یافت نشد.");
        if (await db.Warehouses.AnyAsync(w => w.Code == warehouse.Code && w.Id != warehouse.Id))
            return new CheckResult(false, "این کد انبار قبلاً ثبت شده است.");

        existing.Code = warehouse.Code;
        existing.Title = warehouse.Title;
        existing.ManagerName = warehouse.ManagerName;
        existing.Address = warehouse.Address;
        existing.Phone = warehouse.Phone;
        existing.IsActive = warehouse.IsActive;
        await db.SaveChangesAsync();
        return new CheckResult(true, "انبار با موفقیت ویرایش شد.");
    }

    public async Task<CheckResult> DeleteAsync(int id)
    {
        if (await db.WarehouseItems.AnyAsync(w => w.WarehouseId == id))
            return new CheckResult(false, "این انبار دارای موجودی کالا است.");

        var warehouse = await db.Warehouses.FindAsync(id);
        if (warehouse is null) return new CheckResult(false, "انبار یافت نشد.");

        db.Warehouses.Remove(warehouse);
        await db.SaveChangesAsync();
        return new CheckResult(true, "انبار حذف شد.");
    }
}
