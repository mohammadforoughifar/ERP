using Inventory.Application.Common;
using Inventory.Application.DTOs;
using Inventory.Domain.Entities;
using Inventory.Domain.Enums;
using Microsoft.EntityFrameworkCore;

namespace Inventory.Application.Services;

public interface IDocumentsService
{
    Task<List<InventoryDocumentDto>> GetListAsync(DocumentType? type, DocumentStatus? status,
        int? warehouseId, int? year, DateTime? from, DateTime? to);
    Task<InventoryDocumentDto?> GetAsync(int id);
    Task<CheckResult> CreateAsync(InventoryDocument document, List<DocumentLineDto> lines);
    Task<string> GenerateNumberAsync(DocumentType type);
    Task<CheckResult> ConfirmAsync(int id, UserInfo user);
    Task<CheckResult> RejectAsync(int id, UserInfo user);
    Task<CheckResult> DeleteAsync(int id, UserInfo user);
    Task<CheckResult> CreateReversalAsync(int id, UserInfo user);
    Task<List<InventoryDocumentLine>> GetCardexAsync(int productId, int? warehouseId);
}

public class DocumentsService(IAppDbContext db, IAuditService audit, ISettingsService? settings = null) : IDocumentsService
{
    private readonly ISettingsService _settings = settings ?? new SettingsService(db);

    // ============ جستجو و خواندن ============

    public async Task<List<InventoryDocumentDto>> GetListAsync(
        DocumentType? type, DocumentStatus? status, int? warehouseId, int? year, DateTime? from, DateTime? to)
    {
        var query = db.InventoryDocuments.AsNoTracking()
            .Include(d => d.Warehouse)
            .Include(d => d.Lines).ThenInclude(l => l.Product).ThenInclude(p => p.MainUnit)
            .AsQueryable();

        if (type is not null) query = query.Where(d => d.Type == type);
        if (status is not null) query = query.Where(d => d.Status == status);
        if (warehouseId is > 0) query = query.Where(d => d.WarehouseId == warehouseId || d.DestinationWarehouseId == warehouseId);
        if (year is > 0) query = query.Where(d => d.Date.Year == year);
        if (from is not null) query = query.Where(d => d.Date >= from.Value.Date);
        if (to is not null) query = query.Where(d => d.Date < to.Value.Date.AddDays(1));

        var list = await query.OrderByDescending(d => d.Date).ThenByDescending(d => d.Id).ToListAsync();

        return list.Select(ToDto).ToList();
    }

    public async Task<InventoryDocumentDto?> GetAsync(int id) =>
        ToDto(await db.InventoryDocuments.AsNoTracking()
            .Include(d => d.Warehouse)
            .Include(d => d.DestinationWarehouse)
            .Include(d => d.Lines).ThenInclude(l => l.Product).ThenInclude(p => p.MainUnit)
            .FirstOrDefaultAsync(d => d.Id == id) ?? throw new InvalidOperationException("سند یافت نشد."));

    // ============ ثبت ============

    public async Task<CheckResult> CreateAsync(InventoryDocument document, List<DocumentLineDto> lines)
    {
        var validation = Validate(document, lines);
        if (!validation.Ok) return validation;

        document.Number = DocumentNumberingService.NextNumber(db.InventoryDocuments.AsNoTracking(), document.Date);
        document.Status = DocumentStatus.Draft;

        foreach (var line in lines)
        {
            document.Lines.Add(new InventoryDocumentLine
            {
                ProductId = line.ProductId,
                Quantity = line.Quantity,
                UnitPrice = line.UnitPrice,
                UnitCost = line.UnitCost,
                LotNumber = line.LotNumber,
                ExpiryDate = FaDate.TryParseFaDate(line.ExpiryDateFa, out var exp) ? exp : null,
                SerialNumbers = line.SerialNumbers,
                BinId = line.BinId
            });
        }

        db.InventoryDocuments.Add(document);
        await db.SaveChangesAsync();
        await audit.LogAsync(null, "ایجاد", "سند انبار", document.Id.ToString(),
            $"شماره {document.Number} — نوع {document.Type} — {document.Lines.Count} ردیف");
        return new CheckResult(true, $"سند {document.Number} با موفقیت ثبت شد.");
    }

    // ============ تأیید / رد (اثر روی موجودی فقط اینجا) ============

    public async Task<CheckResult> ConfirmAsync(int id, UserInfo user)
    {
        if (user.Role == UserRole.Storekeeper)
            return new CheckResult(false, "انباردار مجاز به تأیید نهایی سند نیست.");

        var document = await db.InventoryDocuments
            .Include(d => d.Lines).ThenInclude(l => l.Product).ThenInclude(p => p.MainUnit)
            .FirstOrDefaultAsync(d => d.Id == id);
        if (document is null) return new CheckResult(false, "سند یافت نشد.");
        if (document.Status == DocumentStatus.Confirmed)
            return new CheckResult(false, "سند قبلاً تأیید شده است.");
        if (!document.Lines.Any())
            return new CheckResult(false, "سند بدون ردیف قابل تأیید نیست.");
        if (document.WarehouseId is null && !document.IsTransfer)
            return new CheckResult(false, "انبار سند را تعیین کنید.");
        if (document.IsTransfer)
        {
            if (document.WarehouseId is null || document.DestinationWarehouseId is null)
                return new CheckResult(false, "انبار مبدأ و مقصد انتقال را تعیین کنید.");
            if (document.WarehouseId == document.DestinationWarehouseId)
                return new CheckResult(false, "انبار مبدأ و مقصد نمی‌توانند یکسان باشند.");
        }

        // ماهیت سند: آیا این نوع سند روی موجودی اثر می‌گذارد؟ (از تنظیمات — مثلاً امانی خیر)
        var affectsStock = await _settings.AffectsStockAsync(document.Type);
        // مجوز موجودی منفی (از تنظیمات — پیش‌فرض: خیر)
        var allowNeg = await _settings.AllowNegativeStockAsync();

        if (!affectsStock)
        {
            // بدون تأثیر بر موجودی: فقط ثبت و تأیید سند
            document.Status = DocumentStatus.Confirmed;
            document.ConfirmedBy = user.DisplayName;
            document.ConfirmedAt = DateTime.Now;
            await db.SaveChangesAsync();
            await audit.LogAsync(user.DisplayName, "تأیید (بدون تأثیر بر موجودی)", "سند انبار", document.Id.ToString(),
                $"شماره {document.Number}");
            return new CheckResult(true, $"سند {document.Number} تأیید شد (بدون تأثیر بر موجودی).");
        }

        // ============ قیمت تمام‌شده: میانگین موزون / FIFO ============
        // در سند انتقال، بهای تمام‌شده از انبار مبدأ (سمت خروج) محاسبه می‌شود
        var costWarehouseId = document.IsTransfer
            ? (document.IsReceipt ? document.DestinationWarehouseId : document.WarehouseId)
            : document.WarehouseId;

        foreach (var line in document.Lines)
        {
            var product = line.Product;
            var isFifo = product.ValuationMethod == ValuationMethod.Fifo;
            var untracked = !product.TrackLot && !product.TrackExpiry;

            if (document.IsTransfer)
            {
                // انتقال: بهای تمام‌شده از سمت خروج (لایه‌های FIFO یا میانگین انبار مبدأ)
                if (isFifo)
                {
                    var batches = await db.StockBatches
                        .Where(b => b.ProductId == product.Id && b.WarehouseId == costWarehouseId && b.Quantity > 0)
                        .OrderBy(b => b.ReceivedAt).ThenBy(b => b.Id).ToListAsync();
                    var available = batches.Sum(b => b.Quantity);
                    if (line.Quantity > available)
                    {
                        var whStock = await db.WarehouseItems.AsNoTracking()
                            .FirstOrDefaultAsync(w => w.WarehouseId == costWarehouseId && w.ProductId == line.ProductId);
                        if (whStock is null || whStock.Quantity < line.Quantity)
                        {
                            db.ClearTracker();
                            return new CheckResult(false,
                                $"موجودی FIFO کافی نیست: «{product.Name}» — لایه‌ها {available:N0} {product.MainUnit?.Title ?? ""}");
                        }
                        // موجودی اولیه بدون لایه → مابه‌التفاوت با میانگین هزینه‌ی کل (لایه ضمنی)
                        var avg = whStock.Quantity > 0 ? whStock.TotalCost / whStock.Quantity : 0;
                        line.UnitCost = ConsumeFifo(batches, available, consume: untracked);
                        var missing = line.Quantity - available;
                        line.UnitCost = (line.UnitCost * available + avg * missing) / line.Quantity;
                    }
                    else
                    {
                        line.UnitCost = ConsumeFifo(batches, line.Quantity, consume: untracked);
                    }
                    if (document.IsReceipt && untracked)
                        db.StockBatches.Add(new StockBatch
                        {
                            ProductId = product.Id, WarehouseId = document.WarehouseId!.Value,
                            Quantity = line.Quantity, UnitCost = line.UnitCost,
                            ReceivedAt = DateTime.Now, DocumentId = document.Id
                        });
                }
                else
                {
                    var stock = await db.WarehouseItems
                        .FirstOrDefaultAsync(w => w.WarehouseId == costWarehouseId && w.ProductId == line.ProductId);
                    line.UnitCost = stock is { Quantity: > 0 } ? stock.TotalCost / stock.Quantity : line.UnitPrice;
                }
            }
            else if (document.IsReceipt)
            {
                // ورود: هر رسید با قیمت خودش یک لایه‌ی FIFO می‌سازد
                if (isFifo)
                {
                    line.UnitCost = line.UnitPrice;
                    if (untracked)
                        db.StockBatches.Add(new StockBatch
                        {
                            ProductId = product.Id, WarehouseId = document.WarehouseId!.Value,
                            Quantity = line.Quantity, UnitCost = line.UnitCost,
                            ReceivedAt = DateTime.Now, DocumentId = document.Id
                        });
                }
                else
                {
                    var stock = await db.WarehouseItems
                        .FirstOrDefaultAsync(w => w.WarehouseId == costWarehouseId && w.ProductId == line.ProductId);
                    line.UnitCost = stock is { Quantity: > 0 }
                        ? (stock.TotalCost + line.UnitPrice * line.Quantity) / (stock.Quantity + line.Quantity)
                        : line.UnitPrice;
                }
            }
            else
            {
                // خروج: مصرف به ترتیب ورود لایه‌ها (FIFO) یا میانگین موزون
                var stock = await db.WarehouseItems
                    .FirstOrDefaultAsync(w => w.WarehouseId == costWarehouseId && w.ProductId == line.ProductId);
                var available = stock?.Quantity ?? 0;
                if (line.Quantity > available && !allowNeg)
                {
                    db.ClearTracker();
                    return new CheckResult(false,
                        $"موجودی کافی نیست: «{product.Name}» — موجودی {available:N0} {product.MainUnit?.Title ?? ""}");
                }

                if (isFifo)
                {
                    var batches = await db.StockBatches
                        .Where(b => b.ProductId == product.Id && b.WarehouseId == costWarehouseId && b.Quantity > 0)
                        .OrderBy(b => b.ReceivedAt).ThenBy(b => b.Id).ToListAsync();
                    var availableB = batches.Sum(b => b.Quantity);
                    if (line.Quantity > availableB && !allowNeg)
                    {
                        if (stock is null || stock.Quantity < line.Quantity)
                        {
                            db.ClearTracker();
                            return new CheckResult(false,
                                $"لایه‌های FIFO کافی نیست: «{product.Name}» — لایه‌ها {availableB:N0} {product.MainUnit?.Title ?? ""}");
                        }
                        // موجودی اولیه بدون لایه → مابه‌التفاوت با میانگین هزینه (لایه ضمنی)
                        var avg = stock.Quantity > 0 ? stock.TotalCost / stock.Quantity : 0;
                        line.UnitCost = ConsumeFifo(batches, availableB, consume: untracked);
                        var missing = line.Quantity - availableB;
                        line.UnitCost = (line.UnitCost * availableB + avg * missing) / line.Quantity;
                    }
                    else
                    {
                        line.UnitCost = ConsumeFifo(batches, line.Quantity, consume: untracked);
                    }
                }
                else
                {
                    line.UnitCost = stock is { Quantity: > 0 } ? stock.TotalCost / stock.Quantity : line.UnitPrice;
                }
            }
        }

        // ============ رهگیری لوت / انقضا / سریال (فاز ۳) ============
        foreach (var line in document.Lines)
        {
            var product = line.Product;
            if (!product.TrackLot && !product.TrackExpiry && !product.TrackSerial) continue;

            var serials = SplitSerials(line.SerialNumbers);
            if (product.TrackSerial && serials.Count != (int)line.Quantity)
            {
                db.ClearTracker();
                return new CheckResult(false,
                    $"تعداد سریال‌های «{product.Name}» ({serials.Count} عدد) با تعداد ردیف ({line.Quantity:N0}) یکسان نیست.");
            }
            if (product.TrackExpiry && line.ExpiryDate is null)
            {
                db.ClearTracker();
                return new CheckResult(false, $"تاریخ انقضا برای «{product.Name}» الزامی است.");
            }

            if (document.IsTransfer)
            {
                var issueWhId = document.IsReceipt ? document.DestinationWarehouseId : document.WarehouseId;
                var receiptWhId = document.IsReceipt ? document.WarehouseId : document.DestinationWarehouseId;

                var issueSide = await ConsumeTrackedAsync(product, line, issueWhId!.Value, serials, document.Id, issue: true);
                if (!issueSide.Ok) { db.ClearTracker(); return issueSide; }

                var receiptSide = await ConsumeTrackedAsync(product, line, receiptWhId!.Value, serials, document.Id, issue: false, skipSerialDupCheck: true);
                if (!receiptSide.Ok) { db.ClearTracker(); return receiptSide; }
            }
            else
            {
                var result = await ConsumeTrackedAsync(product, line, document.WarehouseId!.Value, serials, document.Id,
                    issue: !document.IsReceipt);
                if (!result.Ok) { db.ClearTracker(); return result; }
            }
        }

        // اعمال روی موجودی
        foreach (var line in document.Lines)
        {
            var qty = line.Quantity * document.Direction;

            if (document.IsTransfer)
            {
                // سمت خروج (مبدأ)
                var issueWhId = document.IsReceipt ? document.DestinationWarehouseId : document.WarehouseId;
                var receiptWhId = document.IsReceipt ? document.WarehouseId : document.DestinationWarehouseId;

                var sourceStock = await db.WarehouseItems
                    .FirstOrDefaultAsync(w => w.WarehouseId == issueWhId && w.ProductId == line.ProductId);
                if (sourceStock is not null)
                {
                    sourceStock.Quantity -= line.Quantity;
                    sourceStock.TotalCost -= line.UnitCost * line.Quantity;
                    sourceStock.UpdatedAt = DateTime.Now;
                }

                // سمت ورود (مقصد)
                var destStock = await db.WarehouseItems
                    .FirstOrDefaultAsync(w => w.WarehouseId == receiptWhId && w.ProductId == line.ProductId);
                if (destStock is null)
                {
                    db.WarehouseItems.Add(new WarehouseItem
                    {
                        WarehouseId = receiptWhId!.Value,
                        ProductId = line.ProductId,
                        Quantity = line.Quantity,
                        TotalCost = line.UnitCost * line.Quantity
                    });
                }
                else
                {
                    destStock.Quantity += line.Quantity;
                    destStock.TotalCost += line.UnitCost * line.Quantity;
                    destStock.UpdatedAt = DateTime.Now;
                }

                continue;
            }

            var stock = await db.WarehouseItems
                .FirstOrDefaultAsync(w => w.WarehouseId == document.WarehouseId && w.ProductId == line.ProductId);

            if (stock is null)
            {
                db.WarehouseItems.Add(new WarehouseItem
                {
                    WarehouseId = document.WarehouseId!.Value,
                    ProductId = line.ProductId,
                    Quantity = qty,
                    TotalCost = line.UnitCost * line.Quantity
                });
            }
            else
            {
                stock.Quantity += qty;
                stock.TotalCost += line.UnitCost * line.Quantity * document.Direction;
                stock.UpdatedAt = DateTime.Now;
            }

            // ============ محل نگهداری (قفسه/رف) ============
            if (line.BinId is not null && !document.IsTransfer)
            {
                var binStock = await db.BinStocks
                    .FirstOrDefaultAsync(b => b.BinId == line.BinId && b.ProductId == line.ProductId);
                if (document.IsReceipt)
                {
                    if (binStock is null)
                        db.BinStocks.Add(new BinStock
                        {
                            BinId = line.BinId.Value, ProductId = line.ProductId,
                            Quantity = line.Quantity, TotalCost = line.UnitCost * line.Quantity
                        });
                    else
                    {
                        binStock.Quantity += line.Quantity;
                        binStock.TotalCost += line.UnitCost * line.Quantity;
                    }
                }
                else
                {
                    if (binStock is null || binStock.Quantity < line.Quantity)
                    {
                        var bin = await db.StorageBins.AsNoTracking().FirstOrDefaultAsync(b => b.Id == line.BinId);
                        db.ClearTracker();
                        return new CheckResult(false,
                            $"موجودی محل «{bin?.Code ?? line.BinId.ToString()}» برای «{line.Product.Name}» کافی نیست.");
                    }
                    binStock.Quantity -= line.Quantity;
                    binStock.TotalCost = Math.Max(0, binStock.TotalCost - line.UnitCost * line.Quantity);
                }
            }
        }

        document.Status = DocumentStatus.Confirmed;
        document.ConfirmedBy = user.DisplayName;
        document.ConfirmedAt = DateTime.Now;
        await db.SaveChangesAsync();
        await audit.LogAsync(user.DisplayName, "تأیید", "سند انبار", document.Id.ToString(),
            $"شماره {document.Number} — جمع {document.Lines.Sum(l => l.Quantity * document.Direction):N0}");
        return new CheckResult(true, $"سند {document.Number} تأیید و در موجودی اعمال شد.");
    }

    public async Task<CheckResult> RejectAsync(int id, UserInfo user)
    {
        if (user.Role == UserRole.Storekeeper)
            return new CheckResult(false, "انباردار مجاز به رد سند نیست.");

        var document = await db.InventoryDocuments.FindAsync(id);
        if (document is null) return new CheckResult(false, "سند یافت نشد.");
        if (document.Status == DocumentStatus.Confirmed)
            return new CheckResult(false, "سند تأییدشده قابل رد نیست — از سند وارون استفاده کنید.");

        document.Status = DocumentStatus.Rejected;
        document.ConfirmedBy = user.DisplayName;
        document.ConfirmedAt = DateTime.Now;
        await db.SaveChangesAsync();
        await audit.LogAsync(user.DisplayName, "رد", "سند انبار", document.Id.ToString(), $"شماره {document.Number}");
        return new CheckResult(true, "سند رد شد.");
    }

    public async Task<CheckResult> DeleteAsync(int id, UserInfo user)
    {
        var document = await db.InventoryDocuments
            .Include(d => d.Lines)
            .FirstOrDefaultAsync(d => d.Id == id);
        if (document is null) return new CheckResult(false, "سند یافت نشد.");
        if (document.Status == DocumentStatus.Confirmed)
            return new CheckResult(false, "سند تأییدشده قابل حذف نیست — از سند وارون استفاده کنید.");

        var number = document.Number;
        db.InventoryDocuments.Remove(document);
        await db.SaveChangesAsync();
        await audit.LogAsync(user.DisplayName, "حذف", "سند انبار", document.Id.ToString(), $"شماره {number}");
        return new CheckResult(true, "سند حذف شد.");
    }

    // ============ سند وارون (معکوس‌کننده) ============

    public async Task<CheckResult> CreateReversalAsync(int id, UserInfo user)
    {
        var source = await db.InventoryDocuments
            .Include(d => d.Lines)
            .FirstOrDefaultAsync(d => d.Id == id);
        if (source is null) return new CheckResult(false, "سند یافت نشد.");
        if (source.Status != DocumentStatus.Confirmed)
            return new CheckResult(false, "فقط سند تأییدشده را می‌توان وارون کرد.");

        var reversal = new InventoryDocument
        {
            Type = OppositeType(source.Type),
            WarehouseId = source.WarehouseId,
            DestinationWarehouseId = source.DestinationWarehouseId,
            Date = DateTime.Now,
            PartyName = source.PartyName,
            Description = $"وارون سند {source.Number}",
            CreatedBy = user.DisplayName,
            CreatedAt = DateTime.Now,
            Status = DocumentStatus.Draft
        };

        foreach (var line in source.Lines)
        {
            reversal.Lines.Add(new InventoryDocumentLine
            {
                ProductId = line.ProductId,
                Quantity = line.Quantity,
                UnitPrice = line.UnitPrice,
                UnitCost = line.UnitCost,
                LotNumber = line.LotNumber,
                ExpiryDate = line.ExpiryDate,
                SerialNumbers = line.SerialNumbers
            });
        }

        reversal.Number = DocumentNumberingService.NextNumber(db.InventoryDocuments.AsNoTracking(), reversal.Date);
        db.InventoryDocuments.Add(reversal);
        await db.SaveChangesAsync();
        await audit.LogAsync(user.DisplayName, "وارون", "سند انبار", source.Id.ToString(),
            $"شماره {source.Number} → سند {reversal.Number}");
        return new CheckResult(true, reversal.Id.ToString());
    }

    private static DocumentType OppositeType(DocumentType type) => type switch
    {
        DocumentType.PurchaseReceipt => DocumentType.PurchaseReturnIssue,
        DocumentType.SalesReturnReceipt => DocumentType.SalesIssue,
        DocumentType.ProductionReceipt => DocumentType.ProductionIssue,
        DocumentType.OpeningReceipt => DocumentType.InternalUseIssue,
        DocumentType.TransferReceipt => DocumentType.TransferIssue,
        DocumentType.SalesIssue => DocumentType.SalesReturnReceipt,
        DocumentType.ProductionIssue => DocumentType.ProductionReceipt,
        DocumentType.PurchaseReturnIssue => DocumentType.PurchaseReceipt,
        DocumentType.ScrapIssue => DocumentType.OpeningReceipt,
        DocumentType.InternalUseIssue => DocumentType.OpeningReceipt,
        DocumentType.TransferIssue => DocumentType.TransferReceipt,
        DocumentType.AdjustmentReceipt => DocumentType.AdjustmentIssue,
        DocumentType.AdjustmentIssue => DocumentType.AdjustmentReceipt,
        DocumentType.ConsignmentReceipt => DocumentType.ConsignmentReturn,
        DocumentType.ConsignmentReturn => DocumentType.ConsignmentReceipt,
        _ => type
    };

    // ============ کاردکس کالا ============

    public async Task<List<InventoryDocumentLine>> GetCardexAsync(int productId, int? warehouseId)
    {
        var query = db.InventoryDocumentLines.AsNoTracking()
            .Include(l => l.Document).ThenInclude(d => d.Warehouse)
            .Include(l => l.Product).ThenInclude(p => p.MainUnit)
            .Where(l => l.ProductId == productId);

        if (warehouseId is > 0)
            query = query.Where(l => l.Document.WarehouseId == warehouseId);

        var lines = await query
            .OrderBy(l => l.Document.Date).ThenBy(l => l.Document.Id)
            .ToListAsync();

        return lines.Where(l => l.Document.Status == DocumentStatus.Confirmed).ToList();
    }

    // ============ کمکی ============

    public async Task<string> GenerateNumberAsync(DocumentType type)
    {
        var now = DateTime.Now;
        return DocumentNumberingService.NextNumber(db.InventoryDocuments.AsNoTracking(), now);
    }

    /// <summary>مصرف لایه‌ها به ترتیب ورود و بازگشت میانگین هزینه‌ی مصرفی</summary>
    private static decimal ConsumeFifo(List<StockBatch> batches, decimal quantity, bool consume)
    {
        if (quantity <= 0) return 0;
        decimal cost = 0;
        var remaining = quantity;
        foreach (var batch in batches)
        {
            if (remaining <= 0) break;
            var take = Math.Min(batch.Quantity, remaining);
            cost += take * batch.UnitCost;
            if (consume) batch.Quantity -= take;
            remaining -= take;
        }
        return Math.Round(cost / quantity, 2);
    }

    private CheckResult Validate(InventoryDocument document, List<DocumentLineDto> lines)
    {
        if (!lines.Any())
            return new CheckResult(false, "حداقل یک ردیف کالا وارد کنید.");
        if (document.WarehouseId is null && !document.IsTransfer)
            return new CheckResult(false, "انبار را انتخاب کنید.");
        if (document.IsTransfer &&
            (document.WarehouseId is null || document.DestinationWarehouseId is null ||
             document.WarehouseId == document.DestinationWarehouseId))
            return new CheckResult(false, "انبار مبدأ و مقصد انتقال را درست انتخاب کنید.");
        if (lines.Any(l => l.ProductId <= 0))
            return new CheckResult(false, "کالای نامعتبر در ردیف‌ها وجود دارد.");
        if (lines.Any(l => l.Quantity <= 0))
            return new CheckResult(false, "تعداد همه‌ی ردیف‌ها باید بزرگ‌تر از صفر باشد.");
        if (lines.Any(l => l.UnitPrice < 0))
            return new CheckResult(false, "قیمت نمی‌تواند منفی باشد.");
        return new CheckResult(true, "");
    }

    // ============ رهگیری لوت / انقضا / سریال ============

    private static List<string> SplitSerials(string? raw)
    {
        if (string.IsNullOrWhiteSpace(raw)) return new List<string>();
        return raw.Split(',', '،', ';', '\n', '\r')
            .Select(x => x.Trim())
            .Where(x => x.Length > 0)
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();
    }

    /// <summary>اعمال رهگیری روی یک سمت از سند (ورود = ساخت لوت/سریال، خروج = مصرف FIFO/صادر شدن سریال)</summary>
    private async Task<CheckResult> ConsumeTrackedAsync(Product product, InventoryDocumentLine line,
        int warehouseId, List<string> serials, int documentId, bool issue, bool skipSerialDupCheck = false)
    {
        if (issue)
        {
            // خروج: مصرف لوت به روش FIFO (اول کوتاه‌ترین انقضا، سپس قدیمی‌ترین ورود)
            if (product.TrackLot || product.TrackExpiry)
            {
                var batches = await db.StockBatches
                    .Where(b => b.ProductId == product.Id && b.WarehouseId == warehouseId && b.Quantity > 0)
                    .OrderBy(b => b.ExpiryDate ?? DateTime.MaxValue)
                    .ThenBy(b => b.ReceivedAt)
                    .ToListAsync();

                var available = batches.Sum(b => b.Quantity);
                if (line.Quantity > available)
                    return new CheckResult(false,
                        $"موجودی لوت «{product.Name}» کافی نیست (موجودی لوت‌ها: {available:N0} {product.MainUnit?.Title ?? ""}).");

                var remaining = line.Quantity;
                foreach (var batch in batches)
                {
                    if (remaining <= 0) break;
                    var take = Math.Min(batch.Quantity, remaining);
                    batch.Quantity -= take;
                    remaining -= take;
                }
            }

            // خروج سریال: باید در همین انبار موجود باشد
            if (product.TrackSerial && serials.Count > 0)
            {
                foreach (var sn in serials)
                {
                    var item = await db.SerialItems.FirstOrDefaultAsync(s =>
                        s.SerialNumber == sn && s.ProductId == product.Id &&
                        s.WarehouseId == warehouseId && s.Status == SerialStatus.InStock);
                    if (item is null)
                        return new CheckResult(false, $"سریال «{sn}» در انبار موجود نیست (کالا: {product.Name}).");
                    item.Status = SerialStatus.Issued;
                    item.IssuedDocumentId = documentId;
                }
            }
        }
        else
        {
            // ورود: ساخت لوت
            var lotNumber = string.IsNullOrWhiteSpace(line.LotNumber)
                ? (product.TrackLot || product.TrackExpiry ? $"LOT-{line.DocumentId}-{line.Id}" : string.Empty)
                : line.LotNumber.Trim();

            if (product.TrackLot || product.TrackExpiry)
            {
                db.StockBatches.Add(new StockBatch
                {
                    ProductId = product.Id,
                    WarehouseId = warehouseId,
                    LotNumber = lotNumber,
                    ExpiryDate = line.ExpiryDate,
                    Quantity = line.Quantity,
                    UnitCost = line.UnitCost,
                    ReceivedAt = DateTime.Now,
                    DocumentId = documentId
                });
            }

            // ورود سریال: یکتایی سراسری (به‌جز سمت ورود انتقال که سریال‌ها از مبدأ منتقل می‌شوند)
            if (product.TrackSerial && serials.Count > 0)
            {
                if (!skipSerialDupCheck)
                {
                    var existing = await db.SerialItems
                        .Where(s => serials.Contains(s.SerialNumber))
                        .Select(s => s.SerialNumber).ToListAsync();
                    if (existing.Count > 0)
                        return new CheckResult(false,
                            $"سریال قبلاً در سیستم ثبت شده: {string.Join("، ", existing.Take(5))}");
                }

                foreach (var sn in serials)
                {
                    db.SerialItems.Add(new SerialItem
                    {
                        SerialNumber = sn,
                        ProductId = product.Id,
                        WarehouseId = warehouseId,
                        LotNumber = string.IsNullOrWhiteSpace(lotNumber) ? null : lotNumber,
                        ExpiryDate = line.ExpiryDate,
                        Status = SerialStatus.InStock,
                        ReceivedDocumentId = documentId,
                        ReceivedAt = DateTime.Now
                    });
                }
            }
        }

        return new CheckResult(true, "");
    }

    public static InventoryDocumentDto ToDto(InventoryDocument d) => new(
        d.Id, d.Number, d.Type, d.Type.Title(), d.IsReceipt, d.IsTransfer,
        d.Status, d.Status.Title(),
        d.Date, d.Date.ToFa(), d.WarehouseId, d.Warehouse?.Title,
        d.DestinationWarehouseId, d.DestinationWarehouse?.Title,
        d.IsPostedToAccounting, d.AccountingVoucherId,
        d.PartyName, d.Description, d.CreatedBy, d.CreatedAt,
        d.ConfirmedBy, d.ConfirmedAt,
        d.Lines.Sum(l => l.Quantity),
        d.Lines.Sum(l => l.Total),
        d.Lines.Select(l => new DocumentLineDto(l.Id, l.ProductId, l.Product.Code, l.Product.Name,
            l.Product.MainUnit?.Title ?? "", l.Quantity, l.UnitPrice, l.UnitCost, l.Total,
            l.LotNumber, l.ExpiryDate?.ToFa(), l.SerialNumbers,
            l.Product.TrackLot, l.Product.TrackExpiry, l.Product.TrackSerial)).ToList());
}
