using Inventory.Application.Common;
using Inventory.Application.DTOs;
using Microsoft.EntityFrameworkCore;

namespace Inventory.Application.Services;

public interface IAuditService
{
    Task LogAsync(string? userName, string action, string entityType, string? entityId, string? details);
    Task<List<AuditLogDto>> GetListAsync(string? search, string? entityType, DateTime? from, DateTime? to);
}

/// <summary>لاگ حسابرسی — ثبت عملیات مهم برای پاسخگویی و ممیزی</summary>
public class AuditService(IAppDbContext db) : IAuditService
{
    public async Task LogAsync(string? userName, string action, string entityType, string? entityId, string? details)
    {
        db.AuditLogs.Add(new Inventory.Domain.Entities.AuditLog
        {
            Date = DateTime.Now,
            UserName = string.IsNullOrWhiteSpace(userName) ? "سیستم" : userName!,
            Action = action,
            EntityType = entityType,
            EntityId = entityId,
            Details = details
        });
        await db.SaveChangesAsync();
    }

    public async Task<List<AuditLogDto>> GetListAsync(string? search, string? entityType, DateTime? from, DateTime? to)
    {
        var query = db.AuditLogs.AsNoTracking().AsQueryable();
        if (!string.IsNullOrWhiteSpace(entityType))
            query = query.Where(a => a.EntityType == entityType);
        if (!string.IsNullOrWhiteSpace(search))
        {
            var s = search.Trim();
            query = query.Where(a => a.UserName.Contains(s) || a.Action.Contains(s) ||
                (a.EntityId != null && a.EntityId.Contains(s)) ||
                (a.Details != null && a.Details.Contains(s)));
        }
        if (from is not null) query = query.Where(a => a.Date >= from);
        if (to is not null) query = query.Where(a => a.Date <= to!.Value.Date.AddDays(1));

        return await query.OrderByDescending(a => a.Date).ThenByDescending(a => a.Id)
            .Select(a => new AuditLogDto(a.Id, a.Date.ToFa(), a.Date.ToString("HH:mm"),
                a.UserName, a.Action, a.EntityType, a.EntityId, a.Details))
            .ToListAsync();
    }
}
