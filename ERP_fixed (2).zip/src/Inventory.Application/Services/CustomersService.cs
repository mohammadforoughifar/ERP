using Inventory.Application.Common;
using Inventory.Application.DTOs;
using Inventory.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace Inventory.Application.Services;

public interface ICustomersService
{
    Task<List<CustomerDto>> GetAllAsync();
    Task<CheckResult> CreateAsync(Customer customer, string? user);
    Task<CheckResult> UpdateAsync(Customer customer, string? user);
    Task<CheckResult> DeleteAsync(int id, string? user);
}

/// <summary>مشتریان</summary>
public class CustomersService(IAppDbContext db, IAuditService audit) : ICustomersService
{
    public async Task<List<CustomerDto>> GetAllAsync() =>
        await db.Customers.AsNoTracking().OrderBy(c => c.Code)
            .Select(c => new CustomerDto
            {
                Id = c.Id, Code = c.Code, Name = c.Name, Phone = c.Phone,
                Address = c.Address, NationalId = c.NationalId, PersonType = c.PersonType, IsActive = c.IsActive
            }).ToListAsync();

    public async Task<CheckResult> CreateAsync(Customer customer, string? user)
    {
        if (string.IsNullOrWhiteSpace(customer.Code) || string.IsNullOrWhiteSpace(customer.Name))
            return new CheckResult(false, "کد و نام مشتری الزامی است.");
        if (await db.Customers.AnyAsync(c => c.Code == customer.Code.Trim()))
            return new CheckResult(false, "این کد قبلاً ثبت شده است.");

        customer.Code = customer.Code.Trim();
        db.Customers.Add(customer);
        await db.SaveChangesAsync();
        await audit.LogAsync(user, "ایجاد", "مشتری", customer.Id.ToString(), customer.Name);
        return new CheckResult(true, "مشتری ثبت شد.");
    }

    public async Task<CheckResult> UpdateAsync(Customer customer, string? user)
    {
        var existing = await db.Customers.FindAsync(customer.Id);
        if (existing is null) return new CheckResult(false, "مشتری یافت نشد.");
        if (await db.Customers.AnyAsync(c => c.Code == customer.Code.Trim() && c.Id != customer.Id))
            return new CheckResult(false, "این کد قبلاً ثبت شده است.");

        existing.Code = customer.Code.Trim();
        existing.Name = customer.Name;
        existing.Phone = customer.Phone;
        existing.Address = customer.Address;
        existing.NationalId = customer.NationalId;
        existing.PersonType = customer.PersonType;
        existing.IsActive = customer.IsActive;
        await db.SaveChangesAsync();
        await audit.LogAsync(user, "ویرایش", "مشتری", customer.Id.ToString(), customer.Name);
        return new CheckResult(true, "مشتری ویرایش شد.");
    }

    public async Task<CheckResult> DeleteAsync(int id, string? user)
    {
        var customer = await db.Customers.FindAsync(id);
        if (customer is null) return new CheckResult(false, "مشتری یافت نشد.");
        if (await db.SalesOrders.AnyAsync(o => o.CustomerId == id))
            return new CheckResult(false, "این مشتری دارای سفارش فروش است و قابل حذف نیست.");

        db.Customers.Remove(customer);
        await db.SaveChangesAsync();
        await audit.LogAsync(user, "حذف", "مشتری", id.ToString(), customer.Name);
        return new CheckResult(true, "مشتری حذف شد.");
    }
}
