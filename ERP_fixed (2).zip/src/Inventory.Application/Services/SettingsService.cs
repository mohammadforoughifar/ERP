using Inventory.Application.Common;
using Microsoft.EntityFrameworkCore;
using Inventory.Domain.Entities;
using Inventory.Domain.Enums;

namespace Inventory.Application.Services;

/// <summary>تنظیمات برنامه — نگه‌داری در جدول AppSettings</summary>
public interface ISettingsService
{
    /// <summary>آیا ثبت کالا با موجودی منفی مجاز است؟ (پیش‌فرض: خیر)</summary>
    Task<bool> AllowNegativeStockAsync();

    Task SetAllowNegativeStockAsync(bool allow);

    /// <summary>آیا این نوع سند روی موجودی اثر می‌گذارد؟ (پیش‌فرض: همه بله، به‌جز اسناد امانی)</summary>
    Task<bool> AffectsStockAsync(DocumentType type);

    Task<Dictionary<DocumentType, bool>> GetStockEffectsAsync();

    Task SetStockEffectAsync(DocumentType type, bool affects);
}

public class SettingsService(IAppDbContext db) : ISettingsService
{
    public const string KeyAllowNegative = "Stock.AllowNegative";
    public const string KeyAffectsPrefix = "Stock.Affects.";

    /// <summary>انواع سندی که به‌صورت پیش‌فرض (بدون تنظیم کاربر) روی موجودی اثر نمی‌گذارند</summary>
    public static readonly DocumentType[] DefaultNoStockEffect =
        { DocumentType.ConsignmentReceipt, DocumentType.ConsignmentReturn };

    private async Task<string?> GetAsync(string key)
    {
        var row = await db.AppSettings.AsNoTracking().FirstOrDefaultAsync(s => s.Key == key);
        return row?.Value;
    }

    private async Task SetAsync(string key, string value)
    {
        var row = await db.AppSettings.FirstOrDefaultAsync(s => s.Key == key);
        if (row is null)
            db.AppSettings.Add(new AppSetting { Key = key, Value = value });
        else
            row.Value = value;
        await db.SaveChangesAsync();
    }

    public async Task<bool> AllowNegativeStockAsync()
    {
        var v = await GetAsync(KeyAllowNegative);
        return v == "1";
    }

    public async Task SetAllowNegativeStockAsync(bool allow) =>
        await SetAsync(KeyAllowNegative, allow ? "1" : "0");

    public async Task<bool> AffectsStockAsync(DocumentType type)
    {
        var v = await GetAsync(KeyAffectsPrefix + (int)type);
        if (!string.IsNullOrEmpty(v)) return v == "1";
        return !DefaultNoStockEffect.Contains(type);
    }

    public async Task<Dictionary<DocumentType, bool>> GetStockEffectsAsync()
    {
        var result = new Dictionary<DocumentType, bool>();
        foreach (DocumentType t in Enum.GetValues<DocumentType>())
            result[t] = !DefaultNoStockEffect.Contains(t);
        var rows = await db.AppSettings.AsNoTracking()
            .Where(s => s.Key.StartsWith(KeyAffectsPrefix)).ToListAsync();
        foreach (var row in rows)
        {
            if (int.TryParse(row.Key[KeyAffectsPrefix.Length..], out var t) &&
                Enum.IsDefined(typeof(DocumentType), t) && !string.IsNullOrEmpty(row.Value))
                result[(DocumentType)t] = row.Value == "1";
        }
        return result;
    }

    public async Task SetStockEffectAsync(DocumentType type, bool affects) =>
        await SetAsync(KeyAffectsPrefix + (int)type, affects ? "1" : "0");
}
