using Inventory.Application.Common;
using Inventory.Application.DTOs;
using Inventory.Domain.Entities;
using Inventory.Domain.Enums;
using Microsoft.EntityFrameworkCore;

namespace Inventory.Application.Services;

public interface IDemoDataService
{
    /// <summary>اگر دیتابیس دموی کارخانه را نداشته باشد، کامل می‌سازد (گروه/کالا/BOM/موجودی/SO/PO + یک اجرای MRP)</summary>
    Task<bool> SeedIfEmptyAsync();

    /// <summary>حذف کامل داده‌های دمو (کالاها/BOM/موجودی‌ها/سفارش‌ها) و اجرای مجدد</summary>
    Task<bool> ResetAsync();
}

/// <summary>
/// بارگذاری خودکار دیتاست «کارخانه مبلمان اداری آریا» (DemoCatalog) روی دیتابیس خالی/بدون دمو —
/// یک‌بار اجرا می‌شود (کلید Demo.Factory در تنظیمات) تا کاربر بلافاصله MRP واقعی ببیند.
/// </summary>
public class DemoDataService(
    IAppDbContext db,
    IDocumentsService docs,
    IPurchaseOrdersService poSvc,
    ISalesOrdersService soSvc,
    IMrpService mrpSvc,
    IAuditService audit) : IDemoDataService
{
    private static readonly UserInfo DemoUser = new("دمو", UserRole.Admin);

    public async Task<bool> SeedIfEmptyAsync()
    {
        if (await db.AppSettings.AsNoTracking().AnyAsync(s => s.Key == DemoCatalog.FlagKey))
            return false;
        await SeedCoreAsync();
        return true;
    }

    public async Task<bool> ResetAsync()
    {
        await WipeCoreAsync();
        await SeedCoreAsync();
        return true;
    }

    // ==================== هسته‌ی ساخت ====================
    private async Task SeedCoreAsync()
    {
        var products = await UpsertCatalogAsync();

        // --- موجودی افتتاحیه (اسناد رسید اولیه) ---
        var raws = products.Where(kv => kv.Key.StartsWith("R-")).ToDictionary(kv => kv.Key, kv => kv.Value);
        var mains = products.Where(kv => !kv.Key.StartsWith("R-")).ToDictionary(kv => kv.Key, kv => kv.Value);

        var rawLines = DemoCatalog.OpeningStock.Where(s => s.Warehouse == 2 && raws.ContainsKey(s.Code))
            .Select(s => Dto(raws[s.Code].Id, s.Qty, raws[s.Code].PurchasePrice)).ToList();
        var mainLines = DemoCatalog.OpeningStock.Where(s => s.Warehouse == 1 && mains.ContainsKey(s.Code))
            .Select(s => Dto(mains[s.Code].Id, s.Qty, mains[s.Code].PurchasePrice)).ToList();

        await ReceiptAsync("DM-OP-1", 2, "موجودی افتتاحیه‌ی مواد اولیه — کارخانه آریا", rawLines);
        await ReceiptAsync("DM-OP-2", 1, "موجودی افتتاحیه‌ی نیم‌ساخت و محصول — کارخانه آریا", mainLines);

        // --- سفارش‌های فروش باز (محرک MRP) ---
        var customers = await db.Customers.ToDictionaryAsync(c => c.Code, c => c.Id);
        foreach (var so in DemoCatalog.SalesOrders)
        {
            if (!customers.TryGetValue(so.CustomerCode, out var customerId)) continue;
            var order = new SalesOrder
            {
                Date = DateTime.Today.AddDays(so.InDays),
                CustomerId = customerId,
                Description = so.Desc + " — دیتاست دمو",
                CreatedBy = "دمو",
                Lines = so.Lines.Where(l => products.ContainsKey(l.Code)).Select(l => new SalesOrderLine
                {
                    ProductId = products[l.Code].Id,
                    Quantity = l.Qty,
                    UnitPrice = l.Price,
                }).ToList(),
            };
            var r = await soSvc.CreateAsync(order, "دمو");
            if (r.Ok) await soSvc.ConfirmAsync(order.Id, "دمو");
        }

        // --- سفارش‌های خرید باز (رسید در راه MRP) ---
        var vendors = await db.Vendors.ToDictionaryAsync(v => v.Code, v => v.Id);
        foreach (var po in DemoCatalog.PurchaseOrders)
        {
            if (!vendors.TryGetValue(po.VendorCode, out var vendorId)) continue;
            var order = new PurchaseOrder
            {
                Date = DateTime.Today.AddDays(po.InDays),
                VendorId = vendorId,
                Description = po.Desc + " — دیتاست دمو",
                CreatedBy = "دمو",
                Lines = po.Lines.Where(l => products.ContainsKey(l.Code)).Select(l => new PurchaseOrderLine
                {
                    ProductId = products[l.Code].Id,
                    Quantity = l.Qty,
                    UnitPrice = l.Price,
                    ReceivedQuantity = 0,
                }).ToList(),
            };
            var r = await poSvc.CreateAsync(order, "دمو");
            if (r.Ok) await poSvc.ConfirmAsync(order.Id, "دمو");
        }

        // --- یک اجرای MRP آماده تا صفحه‌ی /mrp بی‌درنگ نتیجه نشان دهد ---
        try
        {
            await mrpSvc.RunAsync(new MrpRunInput
            {
                Weeks = 12,
                IncludeOpenSalesOrders = true,
                Title = $"سناریوی نمونه — {DemoCatalog.CompanyTitle}",
            }, "دمو");
        }
        catch { /* اگر MRP اجرا نشد، بقیه‌ی دمو سالم می‌ماند */ }

        // --- گردش تأیید پیش‌فرض خرید: حسابدار ← مدیر (فقط ≥۵۰۰ میلیون) ---
        if (!await db.WorkflowDefs.AnyAsync(d => d.DocType == WorkflowService.PurchaseOrderDocType))
        {
            var def = new WorkflowDef
            {
                Name = "گردش استاندارد خرید", DocType = WorkflowService.PurchaseOrderDocType,
                IsActive = true, CreatedBy = "دمو",
            };
            db.WorkflowDefs.Add(def);
            await db.SaveChangesAsync();
            db.WorkflowSteps.Add(new WorkflowStep
            {
                WorkflowDefId = def.Id, OrderIndex = 0, Title = "بررسی مالی",
                ApproverRole = UserRole.Accountant, MinAmount = 0,
            });
            db.WorkflowSteps.Add(new WorkflowStep
            {
                WorkflowDefId = def.Id, OrderIndex = 1, Title = "تأیید نهایی مدیریت",
                ApproverRole = UserRole.Admin, MinAmount = 500_000_000m,
            });
            await db.SaveChangesAsync();
        }

        db.AppSettings.Add(new AppSetting { Key = DemoCatalog.FlagKey, Value = DemoCatalog.Version });
        await db.SaveChangesAsync();
        await audit.LogAsync("دمو", "بارگذاری دیتاست نمونه", "Demo", null,
            $"{DemoCatalog.CompanyTitle} — {DemoCatalog.Products.Count} کالا، {DemoCatalog.Boms.Count} BOM");
    }

    /// <summary>گروه‌ها/واحدها/تأمین‌کننده/مشتری/کالا/BOM کاتالوگ را می‌سازد و کالاها را برمی‌گرداند</summary>
    private async Task<Dictionary<string, Product>> UpsertCatalogAsync()
    {
        // --- واحدهای تکمیلی ---
        var units = await db.Units.ToListAsync();
        foreach (var (title, cat) in DemoCatalog.ExtraUnits)
            if (units.All(u => u.Title != title))
            {
                var u = new Unit { Title = title, Category = cat };
                db.Units.Add(u);
                units.Add(u);
            }

        // --- گروه‌ها (درخت دو مرحله‌ای) ---
        var groups = await db.ProductGroups.ToListAsync();
        var groupMap = groups.Where(g => g.Code != "")
            .GroupBy(g => g.Code).ToDictionary(g => g.Key, g => g.First());
        foreach (var row in DemoCatalog.Groups)
        {
            if (groupMap.ContainsKey(row.Code)) continue;
            var g = new ProductGroup { Code = row.Code, Title = row.Title, Description = row.Desc, IsActive = true };
            db.ProductGroups.Add(g);
            groupMap[row.Code] = g;
        }
        foreach (var row in DemoCatalog.Groups.Where(r => r.ParentCode is not null))
        {
            if (groupMap.TryGetValue(row.Code, out var g) && groupMap.TryGetValue(row.ParentCode!, out var parent))
            {
                g.Parent = parent;
                if (parent.Id > 0) g.ParentId = parent.Id;
            }
        }

        // --- تأمین‌کنندگان ---
        var vendorMap = (await db.Vendors.ToListAsync())
            .GroupBy(v => v.Code).ToDictionary(g => g.Key, g => g.First());
        foreach (var v in DemoCatalog.Vendors)
            if (!vendorMap.ContainsKey(v.Code))
            {
                var e = new Vendor { Code = v.Code, Name = v.Name, Phone = v.Phone, IsActive = true };
                db.Vendors.Add(e);
                vendorMap[v.Code] = e;
            }

        // --- مشتریان ---
        var custMap = (await db.Customers.ToListAsync())
            .GroupBy(c => c.Code).ToDictionary(g => g.Key, g => g.First());
        foreach (var c in DemoCatalog.Customers)
            if (!custMap.ContainsKey(c.Code))
            {
                var e = new Customer { Code = c.Code, Name = c.Name, Phone = c.Phone, IsActive = true, PersonType = c.Legal ? PersonType.Legal : PersonType.Real };
                db.Customers.Add(e);
                custMap[c.Code] = e;
            }

        await db.SaveChangesAsync(); // تا Idها ساخته شوند

        // --- کالاها ---
        var vendorIds = vendorMap.ToDictionary(kv => kv.Key, kv => kv.Value.Id);
        var unitMap = units.GroupBy(u => u.Title).ToDictionary(g => g.Key, g => g.First().Id);
        var groupIds = groupMap.ToDictionary(kv => kv.Key, kv => kv.Value.Id);
        var products = await db.Products.ToListAsync();
        var byCode = products.Where(p => p.Code != "")
            .GroupBy(p => p.Code).ToDictionary(g => g.Key, g => g.First());

        foreach (var row in DemoCatalog.Products)
        {
            if (!byCode.TryGetValue(row.Code, out var p))
            {
                p = new Product { Code = row.Code };
                db.Products.Add(p);
                byCode[row.Code] = p;
            }
            p.Name = row.Name;
            p.LatinName = row.Latin;
            p.Type = row.Type;
            if (groupIds.TryGetValue(row.GroupCode, out var gid)) p.GroupId = gid;
            if (unitMap.TryGetValue(row.Unit, out var uid)) p.MainUnitId = uid;
            p.PurchasePrice = row.Purchase;
            p.SalePrice = row.Sale;
            p.Procurement = row.Type == ProductType.RawMaterial ? ProcurementType.Buy : ProcurementType.Make;
            p.LeadTimeDays = row.LeadTime;
            p.SafetyStock = row.Safety;
            p.LotSizing = row.Lot;
            p.FixedOrderQty = row.FixedQty;
            p.MinOrderQty = row.MinOrder;
            p.ScrapPercent = row.Scrap;
            p.ReorderPoint = row.Safety * 2;
            p.DefaultVendorId = row.VendorCode is not null && vendorIds.TryGetValue(row.VendorCode, out var vid) ? vid : null;
            p.IsActive = true;
        }
        await db.SaveChangesAsync();

        // --- BOMها (فقط برای کالاهای دمو که BOM فعال ندارند) ---
        var codes = byCode;
        var existingBomOwners = (await db.Boms.Where(b => b.IsActive).Select(b => b.ProductId).ToListAsync())
            .ToHashSet();
        foreach (var grp in DemoCatalog.Boms.GroupBy(b => b.ProductCode))
        {
            if (!codes.TryGetValue(grp.Key, out var owner) || existingBomOwners.Contains(owner.Id)) continue;
            var lines = grp.Where(x => codes.ContainsKey(x.ComponentCode) && x.ComponentCode != grp.Key)
                .Select(x => new BomLine { ComponentProductId = codes[x.ComponentCode].Id, Quantity = x.Qty })
                .ToList();
            if (lines.Count == 0) continue;
            db.Boms.Add(new Bom
            {
                ProductId = owner.Id,
                Title = $"BOM {owner.Name}",
                IsActive = true,
                Lines = lines,
            });
        }
        await db.SaveChangesAsync();
        return byCode.Where(kv => DemoCatalog.Products.Any(r => r.Code == kv.Key))
            .ToDictionary(kv => kv.Key, kv => kv.Value);
    }

    // ==================== حذف دمو ====================
    private async Task WipeCoreAsync()
    {
        var codes = DemoCatalog.Products.Select(p => p.Code).ToList();
        var ids = await db.Products.Where(p => codes.Contains(p.Code)).Select(p => p.Id).ToListAsync();
        if (ids.Count == 0) return;

        // BOMهایی که مالک یا جزءشان دمو است
        var bomIds = await db.Boms.Where(b => ids.Contains(b.ProductId) ||
                db.BomLines.Any(l => l.BomId == b.Id && ids.Contains(l.ComponentProductId)))
            .Select(b => b.Id).ToListAsync();
        var delLines = db.BomLines.Where(l => bomIds.Contains(l.BomId));
        db.BomLines.RemoveRange(await delLines.ToListAsync());
        db.Boms.RemoveRange(await db.Boms.Where(b => bomIds.Contains(b.Id)).ToListAsync());

        // اسناد و سطرهایشان
        var docIds = await db.InventoryDocuments.Where(d => d.Number.StartsWith("DM-")).Select(d => d.Id).ToListAsync();
        db.InventoryDocumentLines.RemoveRange(await db.InventoryDocumentLines
            .Where(l => docIds.Contains(l.DocumentId)).ToListAsync());
        var docs = await db.InventoryDocuments.Where(d => docIds.Contains(d.Id)).ToListAsync();
        db.InventoryDocuments.RemoveRange(docs);

        // سفارش‌های فروش/خرید دمو (توضیحشان برچسب دمو دارد)
        var soIds = await db.SalesOrders.Where(o => (o.Description ?? "").Contains("دمو")).Select(o => o.Id).ToListAsync();
        db.SalesOrderLines.RemoveRange(await db.SalesOrderLines.Where(l => soIds.Contains(l.OrderId)).ToListAsync());
        db.SalesOrders.RemoveRange(await db.SalesOrders.Where(o => soIds.Contains(o.Id)).ToListAsync());

        var poIds = await db.PurchaseOrders.Where(o => (o.Description ?? "").Contains("دمو")).Select(o => o.Id).ToListAsync();
        db.PurchaseOrderLines.RemoveRange(await db.PurchaseOrderLines.Where(l => poIds.Contains(l.OrderId)).ToListAsync());
        db.PurchaseOrders.RemoveRange(await db.PurchaseOrders.Where(o => poIds.Contains(o.Id)).ToListAsync());

        // موجودی‌های ایجادشده توسط اسناد دمو باقی می‌مانند (کاردکس پاک می‌شود ولی WarehouseItem تراز دستی لازم نیست
        // چون حذف اسناد دمو فقط همان ورودی‌ها را کم می‌کند و موجودی صفر می‌شود)
        foreach (var wi in await db.WarehouseItems.Where(w => ids.Contains(w.ProductId)).ToListAsync())
            if (wi.Quantity > 0)
                wi.Quantity = 0;

        // اجراهای MRP دمو
        var runs = await db.MrpRuns.ToListAsync();
        if (runs.Count > 0)
        {
            db.MrpPlannedOrders.RemoveRange(await db.MrpPlannedOrders.ToListAsync());
            db.MrpRunMessages.RemoveRange(await db.MrpRunMessages.ToListAsync());
            db.MrpRuns.RemoveRange(runs);
        }

        // تأمین‌کننده/مشتری دمو (اگر بدون استفاده)
        var demoVCodes = DemoCatalog.Vendors.Select(x => x.Code).ToList();
        var demoCCodes = DemoCatalog.Customers.Select(x => x.Code).ToList();
        var vIds = await db.PurchaseOrders.Select(o => o.VendorId).ToListAsync();
        db.Vendors.RemoveRange(await db.Vendors
            .Where(v => demoVCodes.Contains(v.Code) && !vIds.Contains(v.Id)).ToListAsync());
        var cIds = await db.SalesOrders.Select(o => o.CustomerId).ToListAsync();
        db.Customers.RemoveRange(await db.Customers
            .Where(c => demoCCodes.Contains(c.Code) && !cIds.Contains(c.Id)).ToListAsync());
        var docLineProductIds = await db.InventoryDocumentLines.Select(l => l.ProductId).Distinct().ToListAsync();
        var deletable = await db.Products
            .Where(p => ids.Contains(p.Id) && !docLineProductIds.Contains(p.Id)).ToListAsync();
        db.Products.RemoveRange(deletable);

        var flag = await db.AppSettings.FirstOrDefaultAsync(s => s.Key == DemoCatalog.FlagKey);
        if (flag is not null) db.AppSettings.Remove(flag);
        await db.SaveChangesAsync();
    }

    // ---------- ابزارک ----------
    private static DocumentLineDto Dto(int productId, decimal qty, decimal price) =>
        new(0, productId, "", "", "", qty, price, 0, qty * price);

    private async Task ReceiptAsync(string number, int warehouseId, string desc, List<DocumentLineDto> lines)
    {
        if (lines.Count == 0) return;
        var doc = new InventoryDocument
        {
            Number = number,
            Date = DateTime.Now,
            Type = DocumentType.OpeningReceipt,
            Status = DocumentStatus.Draft,
            WarehouseId = warehouseId,
            Description = desc,
            PartyName = "موجودی افتتاحیه",
            CreatedBy = "دمو",
        };
        var r = await docs.CreateAsync(doc, lines);
        if (r.Ok) await docs.ConfirmAsync(doc.Id, DemoUser);
    }
}
