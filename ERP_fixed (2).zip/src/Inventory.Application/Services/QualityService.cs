using Inventory.Application.Common;
using Inventory.Application.DTOs;
using Inventory.Domain.Entities;
using Inventory.Domain.Enums;
using Microsoft.EntityFrameworkCore;

namespace Inventory.Application.Services;

public interface IQualityService
{
    Task<List<QualityInspectionDto>> GetListAsync();
    Task<List<QualityInspectionDto>> GetPendingAsync();
    Task<CheckResult> InspectAsync(int documentId, QualityStatus status, string? notes, string? user);
    Task<CheckResult> DeleteAsync(int id, string? user);
}

/// <summary>کنترل کیفیت — بازرسی سند ورود و صدور سند برگشت برای موارد ردشده</summary>
public class QualityService(IAppDbContext db, IDocumentsService documents, IAuditService audit) : IQualityService
{
    public async Task<List<QualityInspectionDto>> GetListAsync()
    {
        var docs = await db.QualityInspections.AsNoTracking()
            .Include(q => q.Document)
            .OrderByDescending(q => q.Date).ThenByDescending(q => q.Id)
            .ToListAsync();

        return docs.Select(q => new QualityInspectionDto(q.Id, q.Number, q.Date.ToFa(),
            q.DocumentId, q.Document.Number,
            q.Document.Type == DocumentType.PurchaseReceipt ? "رسید خرید" : "سند ورود",
            q.Document.PartyName ?? "—",
            q.Status, q.Status == QualityStatus.Passed ? "قبول" : "رد",
            q.Notes, q.CreatedBy)).ToList();
    }

    public async Task<List<QualityInspectionDto>> GetPendingAsync()
    {
        // اسناد ورود تأییدنشده‌ای که هنوز بازرسی نشده‌اند
        var inspected = await db.QualityInspections.AsNoTracking().Select(q => q.DocumentId).ToListAsync();
        var docs = await db.InventoryDocuments.AsNoTracking()
                        .Where(d => d.Type == DocumentType.PurchaseReceipt && d.Status == DocumentStatus.Confirmed && !inspected.Contains(d.Id))
            .OrderByDescending(d => d.Date).ThenByDescending(d => d.Id)
            .ToListAsync();

        return docs.Select(d => new QualityInspectionDto(0, "", d.Date.ToFa(),
            d.Id, d.Number, "رسید خرید", d.PartyName ?? "—",
            QualityStatus.Passed, "در انتظار بازرسی", null, d.CreatedBy)).ToList();
    }

    public async Task<CheckResult> InspectAsync(int documentId, QualityStatus status, string? notes, string? user)
    {
        var doc = await db.InventoryDocuments.Include(d => d.Lines)            .FirstOrDefaultAsync(d => d.Id == documentId);
        if (doc is null || doc.Type != DocumentType.PurchaseReceipt)
            return new CheckResult(false, "سند ورود معتبر انتخاب کنید.");
        if (await db.QualityInspections.AnyAsync(q => q.DocumentId == documentId))
            return new CheckResult(false, "این سند قبلاً بازرسی شده است.");

        if (status == QualityStatus.Rejected)
        {
            // صدور سند برگشت (خروج از انبار) به اندازه‌ی ردیف‌های سند
            var returnDoc = new InventoryDocument
            {
                Number = await documents.GenerateNumberAsync(DocumentType.PurchaseReturnIssue),
                Date = DateTime.Now,
                Type = DocumentType.PurchaseReturnIssue,
                WarehouseId = doc.WarehouseId,
                PartyName = doc.PartyName,
                Description = $"برگشت کالای مردودی — بازرسی سند {doc.Number}" + (string.IsNullOrWhiteSpace(notes) ? "" : $" ({notes})"),
                CreatedBy = user ?? "سیستم",
                CreatedAt = DateTime.Now
            };
            var returnLines = new List<DocumentLineDto>();
            foreach (var line in doc.Lines)
            {
                var remaining = (await db.StockBatches.AsNoTracking()
                    .Where(s => s.ProductId == line.ProductId && s.DocumentId == doc.Id && s.Quantity > 0)
                    .Select(s => s.Quantity).ToListAsync()).Sum();
                var qty = Math.Min(line.Quantity, remaining);
                if (qty > 0)
                    returnLines.Add(new DocumentLineDto(0, line.ProductId, "", "", "", qty, 0, 0, 0));
            }
            if (returnLines.Count == 0)
                return new CheckResult(false, "موجودی قابل برگشتی از این سند باقی نمانده است.");

            var result = await documents.CreateAsync(returnDoc, returnLines);
            if (!result.Ok) return result;
            var confirmReturn = await documents.ConfirmAsync(returnDoc.Id, new UserInfo(user ?? "سیستم", UserRole.Admin));
            if (!confirmReturn.Ok) return confirmReturn;
        }

        var next = await db.QualityInspections.CountAsync();
        db.QualityInspections.Add(new QualityInspection
        {
            Number = $"QC-{DateTime.Now:yyyyMMdd}-{next + 1:000}",
            Date = DateTime.Now,
            DocumentId = documentId,
            Status = status,
            Notes = notes,
            CreatedBy = user ?? "سیستم"
        });
        await db.SaveChangesAsync();

        await audit.LogAsync(user, "بازرسی کیفیت", "کنترل کیفیت", documentId.ToString(),
            $"سند {doc.Number} — {status} {(string.IsNullOrWhiteSpace(notes) ? "" : $"({notes})")}");
        return new CheckResult(true,
            status == QualityStatus.Passed
                ? "بازرسی ثبت شد: کالا قبول و در انبار ماندگار است."
                : "کالا رد شد و سند برگشت صادر گردید.");
    }

    public async Task<CheckResult> DeleteAsync(int id, string? user)
    {
        var q = await db.QualityInspections.FindAsync(id);
        if (q is null) return new CheckResult(false, "بازرسی یافت نشد.");
        db.QualityInspections.Remove(q);
        await db.SaveChangesAsync();
        await audit.LogAsync(user, "حذف", "کنترل کیفیت", id.ToString(), $"سند {q.Number}");
        return new CheckResult(true, "رکورد بازرسی حذف شد.");
    }
}
