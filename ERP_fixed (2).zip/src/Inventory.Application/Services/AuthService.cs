using System.Security.Cryptography;
using System.Text;
using Inventory.Application.Common;
using Inventory.Application.DTOs;
using Inventory.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace Inventory.Application.Services;

public interface IAuthService
{
    Task<AppUser?> ValidateAsync(string username, string password);
    Task<UserInfo?> GetUserInfoAsync(string username);
    Task<CheckResult> ChangePasswordAsync(string username, string currentPassword, string newPassword);
}

public class AuthService(IAppDbContext db) : IAuthService
{
    public static string HashPassword(string password)
    {
        var bytes = SHA256.HashData(Encoding.UTF8.GetBytes(password));
        return Convert.ToHexString(bytes).ToLowerInvariant();
    }

    public async Task<AppUser?> ValidateAsync(string username, string password)
    {
        var user = await db.Users.FirstOrDefaultAsync(u => u.Username == username.Trim().ToLowerInvariant());
        if (user is null || !user.IsActive) return null;
        return HashPassword(password) == user.PasswordHash ? user : null;
    }

    public async Task<UserInfo?> GetUserInfoAsync(string username)
    {
        var user = await db.Users.AsNoTracking()
            .FirstOrDefaultAsync(u => u.Username == username.Trim().ToLowerInvariant());
        return user is null ? null : new UserInfo(user.DisplayName, user.Role);
    }

    public async Task<CheckResult> ChangePasswordAsync(string username, string currentPassword, string newPassword)
    {
        var user = await db.Users.FirstOrDefaultAsync(u => u.Username == username.Trim().ToLowerInvariant());
        if (user is null) return new CheckResult(false, "کاربر یافت نشد.");
        if (HashPassword(currentPassword) != user.PasswordHash)
            return new CheckResult(false, "رمز فعلی صحیح نیست.");
        if (string.IsNullOrWhiteSpace(newPassword) || newPassword.Length < 4)
            return new CheckResult(false, "رمز جدید باید حداقل ۴ کاراکتر باشد.");

        user.PasswordHash = HashPassword(newPassword);
        await db.SaveChangesAsync();
        return new CheckResult(true, "رمز عبور با موفقیت تغییر کرد.");
    }
}
