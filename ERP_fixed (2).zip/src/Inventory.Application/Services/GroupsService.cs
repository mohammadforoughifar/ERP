using Inventory.Application.Common;
using Inventory.Application.DTOs;
using Inventory.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace Inventory.Application.Services;

public interface IGroupsService
{
    Task<List<ProductGroupDto>> GetAllAsync();
    Task<CheckResult> CreateAsync(ProductGroup group);
    Task<CheckResult> UpdateAsync(ProductGroup group);
    Task<CheckResult> DeleteAsync(int id);
}

public class GroupsService(IAppDbContext db) : IGroupsService
{
    public async Task<List<ProductGroupDto>> GetAllAsync() =>
        await db.ProductGroups.OrderBy(g => g.Code)
            .Select(g => new ProductGroupDto(g.Id, g.Code, g.Title, g.ParentId, g.IsActive, g.Description))
            .ToListAsync();

    public async Task<CheckResult> CreateAsync(ProductGroup group)
    {
        if (string.IsNullOrWhiteSpace(group.Code) || string.IsNullOrWhiteSpace(group.Title))
            return new CheckResult(false, "کد و عنوان گروه الزامی است.");
        if (await db.ProductGroups.AnyAsync(g => g.Code == group.Code))
            return new CheckResult(false, "این کد گروه قبلاً ثبت شده است.");

        db.ProductGroups.Add(group);
        await db.SaveChangesAsync();
        return new CheckResult(true, "گروه با موفقیت ثبت شد.");
    }

    public async Task<CheckResult> UpdateAsync(ProductGroup group)
    {
        var existing = await db.ProductGroups.FindAsync(group.Id);
        if (existing is null) return new CheckResult(false, "گروه یافت نشد.");
        if (await db.ProductGroups.AnyAsync(g => g.Code == group.Code && g.Id != group.Id))
            return new CheckResult(false, "این کد گروه قبلاً ثبت شده است.");

        existing.Code = group.Code;
        existing.Title = group.Title;
        existing.ParentId = group.ParentId;
        existing.IsActive = group.IsActive;
        existing.Description = group.Description;
        await db.SaveChangesAsync();
        return new CheckResult(true, "گروه با موفقیت ویرایش شد.");
    }

    public async Task<CheckResult> DeleteAsync(int id)
    {
        if (await db.Products.AnyAsync(p => p.GroupId == id))
            return new CheckResult(false, "این گروه دارای کالا است و قابل حذف نیست.");

        var group = await db.ProductGroups.FindAsync(id);
        if (group is null) return new CheckResult(false, "گروه یافت نشد.");

        db.ProductGroups.Remove(group);
        await db.SaveChangesAsync();
        return new CheckResult(true, "گروه حذف شد.");
    }
}
