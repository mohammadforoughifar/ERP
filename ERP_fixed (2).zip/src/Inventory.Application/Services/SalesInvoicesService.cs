using Inventory.Application.Common;
using Inventory.Application.DTOs;
using Inventory.Domain.Entities;
using Inventory.Domain.Enums;
using Microsoft.EntityFrameworkCore;

namespace Inventory.Application.Services;

public interface ISalesInvoicesService
{
    Task<List<SalesInvoiceDto>> GetListAsync(int? customerId);
    Task<SalesInvoiceDto?> GetAsync(int id);
    Task<CheckResult> ReturnAsync(int id, string? user);
}

/// <summary>فاکتور فروش — صدور، مشاهده و برگشت از فروش</summary>
public class SalesInvoicesService(IAppDbContext db, IDocumentsService documents, IAuditService audit) : ISalesInvoicesService
{
    public async Task<List<SalesInvoiceDto>> GetListAsync(int? customerId)
    {
        var query = db.SalesInvoices.AsNoTracking()
            .Include(i => i.Customer)
            .Include(i => i.Lines).ThenInclude(l => l.Product).ThenInclude(p => p.MainUnit)
            .AsQueryable();
        if (customerId is > 0) query = query.Where(i => i.CustomerId == customerId);

        var invoices = await query.OrderByDescending(i => i.Date).ThenByDescending(i => i.Id).ToListAsync();
        return invoices.Select(ToDto).ToList();
    }

    public async Task<SalesInvoiceDto?> GetAsync(int id) =>
        ToDto(await db.SalesInvoices.AsNoTracking()
            .Include(i => i.Customer)
            .Include(i => i.Order)
            .Include(i => i.Lines).ThenInclude(l => l.Product).ThenInclude(p => p.MainUnit)
            .FirstOrDefaultAsync(i => i.Id == id) ?? throw new InvalidOperationException("فاکتور یافت نشد."));

    /// <summary>برگشت کامل فاکتور: صدور سند رسید برگشت از فروش + تأیید خودکار</summary>
    public async Task<CheckResult> ReturnAsync(int id, string? user)
    {
        var invoice = await db.SalesInvoices.Include(i => i.Customer).Include(i => i.IssueDocument)
            .Include(i => i.Lines).ThenInclude(l => l.Product)
            .FirstOrDefaultAsync(i => i.Id == id);
        if (invoice is null) return new CheckResult(false, "فاکتور یافت نشد.");
        if (invoice.IsReturned)
            return new CheckResult(false, "این فاکتور قبلاً برگشت خورده است.");

        var returnDoc = new InventoryDocument
        {
            Number = await documents.GenerateNumberAsync(DocumentType.SalesReturnReceipt),
            Date = DateTime.Now,
            Type = DocumentType.SalesReturnReceipt,
            WarehouseId = invoice.IssueDocument?.WarehouseId ??
                await db.Warehouses.AsNoTracking().OrderBy(w => w.Id).Select(w => (int?)w.Id).FirstOrDefaultAsync(),
            PartyName = invoice.Customer.Name,
            Description = $"برگشت از فروش فاکتور {invoice.Number}",
            CreatedBy = user ?? "سیستم",
            CreatedAt = DateTime.Now
        };
        var returnLines = new List<DocumentLineDto>();
        foreach (var line in invoice.Lines)
            returnLines.Add(new DocumentLineDto(0, line.ProductId, "", "", "",
                line.Quantity, line.UnitCost, 0, 0));

        var result = await documents.CreateAsync(returnDoc, returnLines);
        if (!result.Ok) return result;
        var confirm = await documents.ConfirmAsync(returnDoc.Id, new UserInfo(user ?? "سیستم", UserRole.Admin));
        if (!confirm.Ok) return confirm;

        invoice.IsReturned = true;
        invoice.ReturnDocumentId = returnDoc.Id;
        invoice.ReturnedAt = DateTime.Now;
        invoice.ReturnedBy = user ?? "سیستم";
        await db.SaveChangesAsync();

        await audit.LogAsync(user, "برگشت", "فاکتور فروش", invoice.Id.ToString(),
            $"فاکتور {invoice.Number} — سند رسید برگشت {returnDoc.Number}");
        return new CheckResult(true, $"برگشت ثبت شد: کالا به انبار بازگشت (سند {returnDoc.Number}).");
    }

    private static SalesInvoiceDto ToDto(SalesInvoice i) => new()
    {
        Id = i.Id,
        Number = i.Number,
        Date = i.Date,
        DateFa = i.Date.ToFa(),
        CustomerId = i.CustomerId,
        CustomerName = i.Customer.Name,
        CustomerPhone = i.Customer.Phone,
        CustomerAddress = i.Customer.Address,
        OrderId = i.OrderId,
        OrderNumber = i.Order?.Number,
        IssueDocumentId = i.IssueDocumentId,
        Description = i.Description,
        CreatedBy = i.CreatedBy,
        DiscountPercent = i.DiscountPercent,
        Subtotal = i.Subtotal,
        DiscountAmount = i.DiscountAmount,
        Total = i.Total,
        IsReturned = i.IsReturned,
        ReturnDocumentId = i.ReturnDocumentId,
        ReturnedAt = i.ReturnedAt,
        ReturnedBy = i.ReturnedBy,
        Lines = i.Lines.Select(l => new SalesInvoiceLineDto(l.ProductId,
            l.Product.Code, l.Product.Name, l.Product.MainUnit.Title,
            l.Quantity, l.UnitPrice, l.UnitCost, l.Total)).ToList()
    };
}
