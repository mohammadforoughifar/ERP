using Inventory.Domain.Enums;
using System.Text.Json;
using Inventory.Application.Common;
using Inventory.Application.DTOs;
using Inventory.Domain.Entities;
using Inventory.Domain.Enums;
using Microsoft.EntityFrameworkCore;

namespace Inventory.Application.Services;

public interface IWorkflowService
{
    const string PurchaseOrderDocType = "PurchaseOrder";

    /// <summary>برای استفاده‌ی راحت در کامپوننت‌ها (نمونه‌ای)</summary>
    string PoDocType { get; }

    /// <summary>عنوان فارسی نوع سند (نمونه‌ای)</summary>
    string DocTypeTitle(string docType);

    // ---------- طراح (مدیر) ----------
    Task<List<WorkflowDefDto>> GetDefsAsync();
    Task<CheckResult> SaveDefAsync(WorkflowDefDto dto, string? user);
    Task<CheckResult> DeleteDefAsync(int id, string? user);

    /// <summary>آیا برای این نوع سند گردشِ فعالی وجود دارد؟ (برای مخفی‌کردن دکمه‌ی تأیید مستقیم)</summary>
    Task<bool> HasActiveAsync(string docType);

    // ---------- اجرا ----------
    Task<CheckResult> SubmitAsync(string docType, int entityId, UserInfo user);
    Task<WorkflowInstanceDto?> GetForEntityAsync(string docType, int entityId);
    Task<Dictionary<int, WorkflowInstanceDto>> GetForEntitiesAsync(string docType, List<int> entityIds);

    /// <summary>گردش‌های در جریان که گام فعلی‌شان متعلق به این کاربر است</summary>
    Task<List<WorkflowInstanceDto>> PendingForMeAsync(UserInfo user);

    Task<CheckResult> ActAsync(int instanceId, bool approve, string? comment, UserInfo user);
    Task<CheckResult> CancelAsync(int instanceId, UserInfo user);
}

/// <summary>
/// موتور گردش کار — زنجیره‌ای از گام‌های تأیید با نقش/کاربرِ مشخص و شرط حداقل مبلغ.
/// گام‌ها هنگام ارسال اسنپ‌شات می‌شوند؛ گام‌هایی که شرط مبلغشان برسد عبور می‌شوند؛
/// تأیید گام آخر، سند را به‌صورت خودکار تأیید نهایی می‌کند (برای خرید: ConfirmAsync).
/// </summary>
public class WorkflowService(IAppDbContext db, IAuditService audit,
    IPurchaseOrdersService poService) : IWorkflowService
{
    public const string PurchaseOrderDocType = IWorkflowService.PurchaseOrderDocType;
    private static readonly JsonSerializerOptions JsonOpts = new(JsonSerializerDefaults.Web);

    public string PoDocType => PurchaseOrderDocType;

    public string DocTypeTitle(string docType) => docType switch
    {
        PurchaseOrderDocType => "سفارش خرید",
        _ => docType,
    };

    // ==================== طراح ====================
    public async Task<List<WorkflowDefDto>> GetDefsAsync()
    {
        var defs = await db.WorkflowDefs.AsNoTracking().OrderBy(d => d.Id).ToListAsync();
        var steps = await db.WorkflowSteps.AsNoTracking().OrderBy(s => s.OrderIndex).ToListAsync();

        return defs.Select(d => new WorkflowDefDto
        {
            Id = d.Id,
            Name = d.Name,
            DocType = d.DocType,
            IsActive = d.IsActive,
            Steps = steps.Where(s => s.WorkflowDefId == d.Id)
                .Select(ToStepDto).ToList(),
        }).ToList();
    }

    public async Task<CheckResult> SaveDefAsync(WorkflowDefDto dto, string? user)
    {
        if (string.IsNullOrWhiteSpace(dto.Name)) return new CheckResult(false, "نام گردش الزامی است.");
        if (dto.Steps.Count == 0) return new CheckResult(false, "حداقل یک گام تأیید تعریف کنید.");
        if (dto.Steps.Any(s => string.IsNullOrWhiteSpace(s.Title)))
            return new CheckResult(false, "عنوان همه‌ی گام‌ها را وارد کنید.");
        if (dto.Steps.Any(s => s.ApproverRole is null && string.IsNullOrWhiteSpace(s.ApproverUserName)))
            return new CheckResult(false, "هر گام باید نقش یا کاربرِ تأییدکننده داشته باشد.");

        WorkflowDef def;
        if (dto.Id > 0)
        {
            def = await db.WorkflowDefs.Include(d => d.Steps).FirstOrDefaultAsync(d => d.Id == dto.Id);
            if (def is null) return new CheckResult(false, "گردش یافت نشد.");
        }
        else
        {
            def = new WorkflowDef { DocType = dto.DocType, CreatedBy = user ?? "سیستم" };
            db.WorkflowDefs.Add(def);
        }

        def.Name = dto.Name.Trim();
        def.IsActive = dto.IsActive;
        await db.SaveChangesAsync(); // تا شناسه‌ی def برای گام‌ها مقدار بگیرد

        // فعال‌سازی انحصاری برای هر نوع سند
        if (def.IsActive)
        {
            var others = await db.WorkflowDefs.Where(d => d.DocType == def.DocType && d.Id != def.Id).ToListAsync();
            foreach (var o in others) o.IsActive = false;
        }

        // بازسازی گام‌ها
        if (def.Id > 0)
        {
            var olds = await db.WorkflowSteps.Where(s => s.WorkflowDefId == def.Id).ToListAsync();
            db.WorkflowSteps.RemoveRange(olds);
        }
        var i = 0;
        foreach (var s in dto.Steps)
            db.WorkflowSteps.Add(new WorkflowStep
            {
                WorkflowDefId = def.Id,
                OrderIndex = i++,
                Title = s.Title.Trim(),
                ApproverRole = s.ApproverRole,
                ApproverUserName = s.ApproverRole is null ? s.ApproverUserName?.Trim() : null,
                MinAmount = s.MinAmount,
            });

        await db.SaveChangesAsync();
        await audit.LogAsync(user, def.Id > 0 && dto.Id > 0 ? "ویرایش گردش تأیید" : "ایجاد گردش تأیید",
            "Workflow", def.Id.ToString(), $"{def.Name} ({dto.Steps.Count} گام)");
        return new CheckResult(true, def.Id > 0 && dto.Id > 0 ? "گردش ویرایش شد." : "گردش ساخته شد.");
    }

    public async Task<CheckResult> DeleteDefAsync(int id, string? user)
    {
        var running = await db.WorkflowInstances.AnyAsync(i => i.DefId == id && i.Status == WorkflowRunStatus.InProgress);
        if (running) return new CheckResult(false, "این گردش، نمونه‌ی در جریان دارد و قابل حذف نیست.");

        var def = await db.WorkflowDefs.FindAsync(id);
        if (def is null) return new CheckResult(false, "گردش یافت نشد.");
        var steps = await db.WorkflowSteps.Where(s => s.WorkflowDefId == id).ToListAsync();
        db.WorkflowSteps.RemoveRange(steps);
        db.WorkflowDefs.Remove(def);
        await db.SaveChangesAsync();
        await audit.LogAsync(user, "حذف گردش تأیید", "Workflow", id.ToString(), def.Name);
        return new CheckResult(true, "گردش حذف شد.");
    }

    public async Task<bool> HasActiveAsync(string docType) =>
        await db.WorkflowDefs.AsNoTracking().AnyAsync(d => d.DocType == docType && d.IsActive);

    // ==================== اجرا ====================
    public async Task<CheckResult> SubmitAsync(string docType, int entityId, UserInfo user)
    {
        if (await db.WorkflowInstances.AnyAsync(i => i.DocType == docType && i.EntityId == entityId
                && i.Status == WorkflowRunStatus.InProgress))
            return new CheckResult(false, "این سند از قبل در حال گردش است.");

        var def = await db.WorkflowDefs.Include(d => d.Steps)
            .FirstOrDefaultAsync(d => d.DocType == docType && d.IsActive);
        if (def is null) return new CheckResult(false, "برای این نوع سند گردشِ فعالی تعریف نشده است.");

        // مبلغ سند
        decimal total = 0;
        string docNumber = entityId.ToString();
        if (docType == PurchaseOrderDocType)
        {
            var po = await db.PurchaseOrders.AsNoTracking().Include(o => o.Lines)
                .FirstOrDefaultAsync(o => o.Id == entityId);
            if (po is null) return new CheckResult(false, "سفارش خرید یافت نشد.");
            if (po.Status != PurchaseOrderStatus.Draft)
                return new CheckResult(false, "فقط سفارش پیش‌نویس قابل ارسال به گردش است.");
            total = po.Lines.Sum(l => l.Quantity * l.UnitPrice);
            docNumber = po.Number;
        }

        // پلان: فقط گام‌های واجد شرطِ مبلغ
        var plan = def.Steps.OrderBy(s => s.OrderIndex)
            .Where(s => s.MinAmount <= 0 || total >= s.MinAmount)
            .Select(s => new WorkflowPlanStepDto(s.Title,
                s.ApproverRole is not null ? s.ApproverRole.Value.Title()
                    : "@" + (s.ApproverUserName ?? "—"),
                s.MinAmount, WorkflowStepState.Pending, s.ApproverRole, s.ApproverUserName))
            .ToList();
        if (plan.Count == 0)
            return new CheckResult(false,
                $"هیچ گامی واجد شرط نیست (مبلغ سند {total:N0} و همه‌ی گام‌ها حداقل مبلغ دارند). طرح گردش را اصلاح کنید.");

        var instance = new WorkflowInstance
        {
            DocType = docType,
            EntityId = entityId,
            DocNumber = docNumber,
            DefId = def.Id,
            DefName = def.Name,
            TotalAmount = total,
            PlanJson = JsonSerializer.Serialize(plan, JsonOpts),
            CurrentIndex = 0,
            Status = WorkflowRunStatus.InProgress,
            StartedBy = user.DisplayName,
        };
        db.WorkflowInstances.Add(instance);
        await db.SaveChangesAsync();

        // ثبت لاگ «عبور از گام» برای گام‌هایی که به‌خاطر شرط مبلغ از پلان حذف شدند
        var skipped = def.Steps.OrderBy(x => x.OrderIndex)
            .Where(x => x.MinAmount > 0 && total < x.MinAmount).ToList();
        var ms = 0;
        foreach (var sk in skipped)
        {
            instance.Logs.Add(new WorkflowLog
            {
                InstanceId = instance.Id, StepTitle = sk.Title, UserName = "موتور",
                Action = "عبور از گام (شرط مبلغ)",
                Comment = $"مبلغ سند {total:N0} کمتر از حداقل {sk.MinAmount:N0} است.",
                At = DateTime.Now.AddMilliseconds(++ms),
            });
        }
        await db.SaveChangesAsync();

        instance.Logs.Add(new WorkflowLog
        {
            InstanceId = instance.Id,
            StepTitle = plan[0].Title,
            UserName = user.DisplayName,
            Action = "ارسال به گردش",
            Comment = null,
            At = DateTime.Now,
        });
        await db.SaveChangesAsync();
        await audit.LogAsync(user.DisplayName, "ارسال به گردش تأیید", DocTypeTitle(docType), entityId.ToString(), docNumber);
        return new CheckResult(true, $"سند به گردش «{def.Name}» ارسال شد — گام اول: {plan[0].Title}");
    }

    public async Task<WorkflowInstanceDto?> GetForEntityAsync(string docType, int entityId)
    {
        var i = await db.WorkflowInstances.AsNoTracking()
            .Include(x => x.Logs)
            .Where(x => x.DocType == docType && x.EntityId == entityId)
            .OrderByDescending(x => x.Id).FirstOrDefaultAsync();
        return i is null ? null : ToInstanceDto(i);
    }

    public async Task<Dictionary<int, WorkflowInstanceDto>> GetForEntitiesAsync(string docType, List<int> entityIds)
    {
        if (entityIds.Count == 0) return new();
        var list = await db.WorkflowInstances.AsNoTracking().Include(x => x.Logs)
            .Where(x => x.DocType == docType && entityIds.Contains(x.EntityId))
            .OrderByDescending(x => x.Id).ToListAsync();

        return list.GroupBy(x => x.EntityId).ToDictionary(g => g.Key, g => ToInstanceDto(g.First()));
    }

    public async Task<List<WorkflowInstanceDto>> PendingForMeAsync(UserInfo user)
    {
        var list = await db.WorkflowInstances.AsNoTracking().Include(x => x.Logs)
            .Where(x => x.Status == WorkflowRunStatus.InProgress)
            .OrderBy(x => x.StartedAt).ToListAsync();
        return list.Where(i => MatchesCurrentStep(i, user)).Select(ToInstanceDto).ToList();
    }

    public async Task<CheckResult> ActAsync(int instanceId, bool approve, string? comment, UserInfo user)
    {
        var i = await db.WorkflowInstances.Include(x => x.Logs).FirstOrDefaultAsync(x => x.Id == instanceId);
        if (i is null) return new CheckResult(false, "گردش یافت نشد.");
        if (i.Status != WorkflowRunStatus.InProgress) return new CheckResult(false, "این گردش تمام شده است.");

        var plan = ParsePlan(i.PlanJson);
        if (i.CurrentIndex >= plan.Count) return new CheckResult(false, "پلان گردش نامعتبر است.");
        var step = plan[i.CurrentIndex];

        if (!StepMatches(step, user))
            return new CheckResult(false, "گام فعلی متعلق به شما نیست — تأییدکننده‌ی این گام دیگری است.");

        if (!approve)
        {
            i.Status = WorkflowRunStatus.Rejected;
            i.FinishedAt = DateTime.Now;
            i.Logs.Add(new WorkflowLog
            {
                InstanceId = i.Id, StepTitle = step.Title, UserName = user.DisplayName,
                Action = "رد", Comment = string.IsNullOrWhiteSpace(comment) ? null : comment.Trim(), At = DateTime.Now,
            });
            await db.SaveChangesAsync();
            await audit.LogAsync(user.DisplayName, "رد گام گردش", DocTypeTitle(i.DocType), i.EntityId.ToString(), i.DocNumber);
            return new CheckResult(true, $"گردش رد شد — «{i.DocNumber}» به وضعیت پیش‌نویس برمی‌گردد.");
        }

        i.Logs.Add(new WorkflowLog
        {
            InstanceId = i.Id, StepTitle = step.Title, UserName = user.DisplayName,
            Action = "تأیید", Comment = string.IsNullOrWhiteSpace(comment) ? null : comment.Trim(), At = DateTime.Now,
        });

        // گام بعدی واجد شرط (شرط مبلغ بر اساس مبلغِ ثبت‌شده در ارسال)
        var next = FindNext(i, plan);
        if (next is { } n)
        {
            i.CurrentIndex = n;
            i.Logs.Add(new WorkflowLog
            {
                InstanceId = i.Id, StepTitle = plan[n].Title, UserName = "موتور",
                Action = "عبور به گام بعد", Comment = null, At = DateTime.Now.AddMilliseconds(1),
            });
            await db.SaveChangesAsync();
            return new CheckResult(true, $"تأیید شد — گام بعدی: {plan[n].Title}");
        }

        // گردش تمام شد → تأیید نهایی سند
        i.Status = WorkflowRunStatus.Approved;
        i.FinishedAt = DateTime.Now;

        string extra = "";
        if (i.DocType == PurchaseOrderDocType)
        {
            var po = await db.PurchaseOrders.FindAsync(i.EntityId);
            if (po is not null && po.Status == PurchaseOrderStatus.Draft)
            {
                var r = await poService.ConfirmAsync(i.EntityId, user.DisplayName);
                extra = r.Ok ? " — سفارش خرید تأیید نهایی شد ✅" : $" — اما تأیید سفارش ناموفق بود: {r.Message}";
            }
        }
        await db.SaveChangesAsync();
        await audit.LogAsync(user.DisplayName, "تأیید نهایی گردش", DocTypeTitle(i.DocType), i.EntityId.ToString(), i.DocNumber);
        return new CheckResult(true, "تأیید نهایی انجام شد — گردش کامل شد." + extra);
    }

    public async Task<CheckResult> CancelAsync(int instanceId, UserInfo user)
    {
        var i = await db.WorkflowInstances.Include(x => x.Logs).FirstOrDefaultAsync(x => x.Id == instanceId);
        if (i is null) return new CheckResult(false, "گردش یافت نشد.");
        if (i.Status != WorkflowRunStatus.InProgress) return new CheckResult(false, "این گردش تمام شده است.");
        if (i.StartedBy != user.DisplayName && user.Role != UserRole.Admin)
            return new CheckResult(false, "فقط فرستنده یا مدیر می‌تواند گردش را لغو کند.");

        i.Status = WorkflowRunStatus.Cancelled;
        i.FinishedAt = DateTime.Now;
        var plan = ParsePlan(i.PlanJson);
        i.Logs.Add(new WorkflowLog
        {
            InstanceId = i.Id,
            StepTitle = i.CurrentIndex < plan.Count ? plan[i.CurrentIndex].Title : "—",
            UserName = user.DisplayName, Action = "لغو گردش",
            Comment = null, At = DateTime.Now,
        });
        await db.SaveChangesAsync();
        return new CheckResult(true, "گردش لغو شد.");
    }

    // ==================== ابزارک‌ها ====================
    private static WorkflowStepDto ToStepDto(WorkflowStep s) => new()
    {
        Id = s.Id, OrderIndex = s.OrderIndex, Title = s.Title,
        ApproverRole = s.ApproverRole, ApproverUserName = s.ApproverUserName, MinAmount = s.MinAmount,
    };

    private static WorkflowInstanceDto ToInstanceDto(WorkflowInstance i)
    {
        var plan = ParsePlan(i.PlanJson);
        var steps = new List<WorkflowPlanStepDto>();
        for (var k = 0; k < plan.Count; k++)
        {
            var s = plan[k] with
            {
                State = i.Status != WorkflowRunStatus.InProgress
                    ? (i.Status == WorkflowRunStatus.Approved || k < i.CurrentIndex ? WorkflowStepState.Done
                        : i.Status == WorkflowRunStatus.Rejected && k == i.CurrentIndex ? WorkflowStepState.Current
                        : WorkflowStepState.Pending)
                    : k < i.CurrentIndex ? WorkflowStepState.Done
                    : k == i.CurrentIndex ? WorkflowStepState.Current
                    : WorkflowStepState.Pending,
            };
            steps.Add(s);
        }

        return new WorkflowInstanceDto
        {
            Id = i.Id, DocType = i.DocType, EntityId = i.EntityId, DocNumber = i.DocNumber,
            DefName = i.DefName, TotalAmount = i.TotalAmount, Status = i.Status,
            StartedBy = i.StartedBy, StartedAt = i.StartedAt, FinishedAt = i.FinishedAt,
            CurrentStepTitle = i.Status == WorkflowRunStatus.InProgress && i.CurrentIndex < plan.Count
                ? plan[i.CurrentIndex].Title : null,
            Steps = steps,
            Logs = i.Logs.OrderBy(l => l.At).ThenBy(l => l.Id)
                .Select(l => new WorkflowLogDto(l.UserName, l.Action, l.StepTitle, l.Comment, l.At)).ToList(),
        };
    }

    private static List<WorkflowPlanStepDto> ParsePlan(string json) =>
        JsonSerializer.Deserialize<List<WorkflowPlanStepDto>>(json, JsonOpts) ?? new();

    private static bool StepMatches(WorkflowPlanStepDto step, UserInfo user) =>
        step.Role is not null ? step.Role == user.Role
        : !string.IsNullOrWhiteSpace(step.UserName) && step.UserName == user.DisplayName;

    private static bool MatchesCurrentStep(WorkflowInstance i, UserInfo user)
    {
        var plan = ParsePlan(i.PlanJson);
        return i.CurrentIndex < plan.Count && StepMatches(plan[i.CurrentIndex], user);
    }

    /// <summary>ایندکس گام بعدیِ واجد شرط (گام‌هایی که حداقل مبلغشان می‌رسد عبور می‌شوند)</summary>
    private static int? FindNext(WorkflowInstance i, List<WorkflowPlanStepDto> plan)
    {
        for (var k = i.CurrentIndex + 1; k < plan.Count; k++)
        {
            if (plan[k].MinAmount <= 0 || i.TotalAmount >= plan[k].MinAmount) return k;
            i.Logs.Add(new WorkflowLog
            {
                InstanceId = i.Id, StepTitle = plan[k].Title, UserName = "موتور",
                Action = "عبور از گام (شرط مبلغ)",
                Comment = $"حداقل {plan[k].MinAmount:N0} — مبلغ سند {i.TotalAmount:N0}", At = DateTime.Now,
            });
        }
        return null;
    }
}
