using Inventory.Application.Common;
using Inventory.Application.DTOs;
using Inventory.Domain.Enums;
using Microsoft.EntityFrameworkCore;

namespace Inventory.Application.Services;

public interface IDashboardService
{
    Task<DashboardDto> GetAsync();
}

public class DashboardService(IAppDbContext db) : IDashboardService
{
    public async Task<DashboardDto> GetAsync()
    {
        var today = DateTime.Today;

        var productCount = await db.Products.CountAsync();
        var warehouseCount = await db.Warehouses.CountAsync();
        var groupCount = await db.ProductGroups.CountAsync();
        var unitCount = await db.Units.CountAsync();

        var stocks = await db.WarehouseItems.ToListAsync();
        var totalStock = stocks.Sum(s => s.Quantity);
        var totalStockValue = stocks.Sum(s => s.TotalCost);

        var documentsToday = await db.InventoryDocuments.CountAsync(d => d.Date.Date == today);
        var drafts = await db.InventoryDocuments.CountAsync(d => d.Status == DocumentStatus.Draft);

        // کالاهای زیر نقطه‌ی سفارش (SQLite نمی‌تواند Sum روی decimal بزند؛ در حافظه محاسبه می‌شود)
        var lowStock = (await db.Products.AsNoTracking()
            .Select(p => new
            {
                p.Id, p.Code, p.Name, p.ReorderPoint,
                Items = p.WarehouseItems.Select(w => w.Quantity).ToList()
            })
            .ToListAsync())
            .Select(p => new { p.Id, p.Code, p.Name, p.ReorderPoint, Stock = p.Items.Sum() })
            .ToList();

        var lowStockItems = lowStock
            .Where(p => p.ReorderPoint > 0 && p.Stock < p.ReorderPoint)
            .OrderBy(p => p.Stock - p.ReorderPoint)
            .Select(p => new LowStockItemDto(p.Id, p.Code, p.Name, p.Stock, p.ReorderPoint))
            .Take(8)
            .ToList();

        // اسناد اخیر
        var recent = await db.InventoryDocuments.AsNoTracking()
            .Include(d => d.Warehouse)
            .OrderByDescending(d => d.Date).ThenByDescending(d => d.Id)
            .Take(8)
            .ToListAsync();

        var recentDocs = recent.Select(d => new RecentDocumentDto(
            d.Number, d.Type.Title(), d.Status.Title(), d.Date.ToFa(),
            d.Warehouse?.Title, d.Lines.Sum(l => l.Total))).ToList();

        return new DashboardDto(productCount, warehouseCount, groupCount, unitCount,
            totalStock, totalStockValue, documentsToday, drafts,
            lowStockItems.Count, lowStockItems, recentDocs);
    }
}
