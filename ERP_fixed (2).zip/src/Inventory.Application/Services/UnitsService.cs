using Inventory.Application.Common;
using Inventory.Application.DTOs;
using Inventory.Domain.Entities;
using Inventory.Domain.Enums;
using Microsoft.EntityFrameworkCore;

namespace Inventory.Application.Services;

public interface IUnitsService
{
    Task<List<UnitDto>> GetAllAsync();
    Task<CheckResult> CreateAsync(Unit unit);
    Task<CheckResult> UpdateAsync(Unit unit);
    Task<CheckResult> DeleteAsync(int id);
}

public class UnitsService(IAppDbContext db) : IUnitsService
{
    public async Task<List<UnitDto>> GetAllAsync() =>
        await db.Units.OrderBy(u => u.Title)
            .Select(u => new UnitDto(u.Id, u.Title, u.Category, u.Category.Title(),
                u.BaseUnitId, u.BaseUnit != null ? u.BaseUnit.Title : null, u.Factor, u.Description))
            .ToListAsync();

    public async Task<CheckResult> CreateAsync(Unit unit)
    {
        if (string.IsNullOrWhiteSpace(unit.Title))
            return new CheckResult(false, "عنوان واحد الزامی است.");
        if (unit.BaseUnitId is not null && unit.BaseUnitId == unit.Id)
            return new CheckResult(false, "واحد نمی‌تواند پایه‌ی خودش باشد.");
        if (unit.BaseUnitId is not null && unit.Factor <= 0)
            return new CheckResult(false, "ضریب تبدیل باید بزرگ‌تر از صفر باشد.");

        db.Units.Add(unit);
        await db.SaveChangesAsync();
        return new CheckResult(true, "واحد با موفقیت ثبت شد.");
    }

    public async Task<CheckResult> UpdateAsync(Unit unit)
    {
        var existing = await db.Units.FindAsync(unit.Id);
        if (existing is null) return new CheckResult(false, "واحد یافت نشد.");

        existing.Title = unit.Title;
        existing.Category = unit.Category;
        existing.BaseUnitId = unit.BaseUnitId;
        existing.Factor = unit.Factor;
        existing.Description = unit.Description;
        await db.SaveChangesAsync();
        return new CheckResult(true, "واحد با موفقیت ویرایش شد.");
    }

    public async Task<CheckResult> DeleteAsync(int id)
    {
        if (await db.Products.AnyAsync(p => p.MainUnitId == id))
            return new CheckResult(false, "این واحد برای برخی کالاها استفاده شده است.");

        var unit = await db.Units.FindAsync(id);
        if (unit is null) return new CheckResult(false, "واحد یافت نشد.");

        db.Units.Remove(unit);
        await db.SaveChangesAsync();
        return new CheckResult(true, "واحد حذف شد.");
    }
}
