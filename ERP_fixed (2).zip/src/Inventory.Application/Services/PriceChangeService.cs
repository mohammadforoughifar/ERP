using Inventory.Application.Common;
using Inventory.Application.DTOs;
using Inventory.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace Inventory.Application.Services;

public interface IPriceChangeService
{
    Task<List<PriceChangeDto>> GetListAsync();
    Task<CheckResult> CreateAsync(PriceChangeDocument doc, string? user);
}

/// <summary>سند تعدیل قیمت — ثبت دستی تغییر قیمت خرید/فروش با تاریخچه</summary>
public class PriceChangeService(IAppDbContext db, IAuditService audit) : IPriceChangeService
{
    public async Task<List<PriceChangeDto>> GetListAsync()
    {
        var docs = await db.PriceChangeDocuments.AsNoTracking()
            .Include(d => d.Product)
            .OrderByDescending(d => d.Date).ThenByDescending(d => d.Id)
            .ToListAsync();

        return docs.Select(d => new PriceChangeDto(d.Id, d.Number, d.Date.ToFa(),
            d.Product.Code, d.Product.Name, d.OldPurchasePrice, d.NewPurchasePrice,
            d.OldSalePrice, d.NewSalePrice, d.Reason, d.CreatedBy)).ToList();
    }

    public async Task<CheckResult> CreateAsync(PriceChangeDocument doc, string? user)
    {
        if (doc.ProductId <= 0) return new CheckResult(false, "انتخاب کالا الزامی است.");
        if (doc.NewPurchasePrice < 0 || (doc.NewSalePrice is not null && doc.NewSalePrice < 0))
            return new CheckResult(false, "قیمت نمی‌تواند منفی باشد.");
        if (doc.NewPurchasePrice == doc.OldPurchasePrice && doc.NewSalePrice == doc.OldSalePrice)
            return new CheckResult(false, "مقدار جدید با قبلی یکسان است.");

        var product = await db.Products.FindAsync(doc.ProductId);
        if (product is null) return new CheckResult(false, "کالا یافت نشد.");

        var next = await db.PriceChangeDocuments.CountAsync();
        doc.Number = $"PC-{DateTime.Now:yyyyMMdd}-{next + 1:000}";
        doc.CreatedBy = user ?? "سیستم";
        doc.CreatedAt = DateTime.Now;
        doc.OldPurchasePrice = product.PurchasePrice;
        doc.OldSalePrice = product.SalePrice;

        product.PurchasePrice = doc.NewPurchasePrice;
        if (doc.NewSalePrice is not null) product.SalePrice = doc.NewSalePrice.Value;

        db.PriceChangeDocuments.Add(doc);
        await db.SaveChangesAsync();
        await audit.LogAsync(user, "تعدیل قیمت", "کالا", product.Id.ToString(),
            $"{product.Code}: قیمت خرید {doc.OldPurchasePrice:N0} → {doc.NewPurchasePrice:N0}" +
            (doc.NewSalePrice is not null ? $"، فروش {doc.OldSalePrice:N0} → {doc.NewSalePrice:N0}" : "") +
            (string.IsNullOrWhiteSpace(doc.Reason) ? "" : $" ({doc.Reason})"));
        return new CheckResult(true, $"سند {doc.Number} ثبت و قیمت کالا به‌روزرسانی شد.");
    }
}
