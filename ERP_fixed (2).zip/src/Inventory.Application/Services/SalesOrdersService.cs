using Inventory.Application.Common;
using Inventory.Application.DTOs;
using Inventory.Domain.Entities;
using Inventory.Domain.Enums;
using Microsoft.EntityFrameworkCore;

namespace Inventory.Application.Services;

public interface ISalesOrdersService
{
    Task<List<SalesOrderDto>> GetListAsync();
    Task<CheckResult> CreateAsync(SalesOrder order, string? user);
    Task<CheckResult> ConfirmAsync(int id, string? user);
    Task<CheckResult> InvoiceAsync(int id, decimal discount, string? user);
    Task<CheckResult> CancelAsync(int id, string? user);
    Task<CheckResult> DeleteAsync(int id, string? user);
}

/// <summary>سفارش فروش — از پیش‌نویس تا تأیید و صدور فاکتور + حواله فروش</summary>
public class SalesOrdersService(IAppDbContext db, IDocumentsService documents, IAuditService audit) : ISalesOrdersService
{
    public async Task<List<SalesOrderDto>> GetListAsync()
    {
        var orders = await db.SalesOrders.AsNoTracking()
            .Include(o => o.Customer).Include(o => o.Lines).ThenInclude(l => l.Product).ThenInclude(p => p.MainUnit)
            .OrderByDescending(o => o.Date).ThenByDescending(o => o.Id)
            .ToListAsync();

        return orders.Select(o => new SalesOrderDto
        {
            Id = o.Id,
            Number = o.Number,
            Date = o.Date,
            DateFa = o.Date.ToFa(),
            CustomerId = o.CustomerId,
            CustomerName = o.Customer.Name,
            Status = o.Status,
            StatusTitle = o.Status switch
            {
                SalesOrderStatus.Draft => "پیش‌نویس",
                SalesOrderStatus.Confirmed => "تأییدشده",
                SalesOrderStatus.Invoiced => "فاکتور شده",
                _ => "لغو شده"
            },
            Description = o.Description,
            CreatedBy = o.CreatedBy,
            TotalQuantity = o.Lines.Sum(l => l.Quantity),
            TotalAmount = o.Lines.Sum(l => l.Total),
            InvoiceId = o.InvoiceId,
            Lines = o.Lines.Select(l => new SalesOrderLineDto(l.Id, l.ProductId,
                l.Product.Code, l.Product.Name, l.Product.MainUnit?.Title ?? "",
                l.Quantity, l.UnitPrice, l.Total)).ToList()
        }).ToList();
    }

    public async Task<CheckResult> CreateAsync(SalesOrder order, string? user)
    {
        if (order.CustomerId <= 0) return new CheckResult(false, "انتخاب مشتری الزامی است.");
        if (order.Lines.Count == 0 || order.Lines.All(l => l.Quantity <= 0))
            return new CheckResult(false, "حداقل یک ردیف با مقدار معتبر وارد کنید.");

        var next = await db.SalesOrders.CountAsync();
        order.Number = $"SO-{DateTime.Now:yyyyMMdd}-{next + 1:000}";
        order.Status = SalesOrderStatus.Draft;
        order.CreatedBy = user ?? "سیستم";
        order.CreatedAt = DateTime.Now;
        order.Lines = order.Lines.Where(l => l.Quantity > 0).ToList();

        db.SalesOrders.Add(order);
        await db.SaveChangesAsync();
        await audit.LogAsync(user, "ایجاد", "سفارش فروش", order.Id.ToString(),
            $"شماره {order.Number} — مشتری {order.CustomerId} — {order.Lines.Count} ردیف");
        return new CheckResult(true, $"سفارش {order.Number} ثبت شد.");
    }

    public async Task<CheckResult> ConfirmAsync(int id, string? user)
    {
        var order = await db.SalesOrders.FirstOrDefaultAsync(o => o.Id == id);
        if (order is null) return new CheckResult(false, "سفارش یافت نشد.");
        if (order.Status is SalesOrderStatus.Cancelled or SalesOrderStatus.Invoiced)
            return new CheckResult(false, "این سفارش قابل تأیید نیست.");

        order.Status = SalesOrderStatus.Confirmed;
        order.ConfirmedAt = DateTime.Now;
        await db.SaveChangesAsync();
        await audit.LogAsync(user, "تأیید", "سفارش فروش", id.ToString(), $"شماره {order.Number}");
        return new CheckResult(true, "سفارش تأیید شد.");
    }

    /// <summary>صدور فاکتور: ساخت حواله فروش + تأیید خودکار + صدور فاکتور با اعمال تخفیف</summary>
    public async Task<CheckResult> InvoiceAsync(int id, decimal discount, string? user)
    {
        var order = await db.SalesOrders.Include(o => o.Customer).Include(o => o.Lines).ThenInclude(l => l.Product).ThenInclude(p => p.MainUnit)
            .FirstOrDefaultAsync(o => o.Id == id);
        if (order is null) return new CheckResult(false, "سفارش یافت نشد.");
        if (order.Status != SalesOrderStatus.Confirmed)
            return new CheckResult(false, "فقط سفارش‌های تأییدشده قابل صدور فاکتور هستند.");
        if (order.InvoiceId is not null)
            return new CheckResult(false, "برای این سفارش قبلاً فاکتور صادر شده است.");

        // ۱) حواله فروش
        var issueDoc = new InventoryDocument
        {
            Number = await documents.GenerateNumberAsync(DocumentType.SalesIssue),
            Date = DateTime.Now,
            Type = DocumentType.SalesIssue,
            WarehouseId = order.WarehouseId ?? await db.Warehouses.AsNoTracking()
                .OrderBy(w => w.Id).Select(w => (int?)w.Id).FirstOrDefaultAsync(),
            PartyName = order.Customer.Name,
            Description = $"حواله فروش سفارش {order.Number}",
            CreatedBy = user ?? "سیستم",
            CreatedAt = DateTime.Now
        };
        var lines = new List<DocumentLineDto>();
        foreach (var line in order.Lines)
            lines.Add(new DocumentLineDto(0, line.ProductId, "", "", "", line.Quantity, line.UnitPrice, 0, 0));

        var result = await documents.CreateAsync(issueDoc, lines);
        if (!result.Ok) return result;
        var confirm = await documents.ConfirmAsync(issueDoc.Id, new UserInfo(user ?? "سیستم", UserRole.Admin));
        if (!confirm.Ok) return confirm;

        // ۲) فاکتور از روی حواله‌ی تأییدشده (با بهای تمام‌شده‌ی واقعی)
        var confirmedLines = await db.InventoryDocumentLines.AsNoTracking()
            .Where(l => l.DocumentId == issueDoc.Id)
            .Include(l => l.Product).ThenInclude(p => p.MainUnit)
            .ToListAsync();

        var factor = discount > 0 && discount < 100 ? 1m - discount / 100m : 1m;
        var next = await db.SalesInvoices.CountAsync();
        var invoice = new SalesInvoice
        {
            Number = $"INV-{DateTime.Now:yyyyMMdd}-{next + 1:000}",
            Date = DateTime.Now,
            CustomerId = order.CustomerId,
            OrderId = order.Id,
            IssueDocumentId = issueDoc.Id,
            Description = order.Description,
            CreatedBy = user ?? "سیستم",
            CreatedAt = DateTime.Now,
            DiscountPercent = discount > 0 && discount < 100 ? discount : 0
        };
        decimal subtotal = 0;
        foreach (var l in confirmedLines)
        {
            var lineTotal = l.Quantity * l.UnitPrice;
            subtotal += lineTotal;
            invoice.Lines.Add(new SalesInvoiceLine
            {
                ProductId = l.ProductId,
                Quantity = l.Quantity,
                UnitPrice = Math.Round(l.UnitPrice * factor, 2),
                UnitCost = l.UnitCost
            });
        }
        invoice.Subtotal = Math.Round(subtotal, 2);
        invoice.DiscountAmount = Math.Round(subtotal * (1m - factor), 2);
        invoice.Total = Math.Round(subtotal * factor, 2);
        db.SalesInvoices.Add(invoice);
        await db.SaveChangesAsync();

        order.InvoiceId = invoice.Id;
        order.IssueDocumentId = issueDoc.Id;
        order.Status = SalesOrderStatus.Invoiced;
        order.InvoicedAt = DateTime.Now;
        await db.SaveChangesAsync();

        await audit.LogAsync(user, "فاکتور", "سفارش فروش", order.Id.ToString(),
            $"شماره {invoice.Number} — مبلغ {invoice.Total:N0} ریال — سند حواله {issueDoc.Number}");
        return new CheckResult(true, $"فاکتور {invoice.Number} صادر شد و کالا از انبار خارج گردید.");
    }

    public async Task<CheckResult> CancelAsync(int id, string? user)
    {
        var order = await db.SalesOrders.FindAsync(id);
        if (order is null) return new CheckResult(false, "سفارش یافت نشد.");
        if (order.Status == SalesOrderStatus.Invoiced)
            return new CheckResult(false, "سفارش فاکتور شده قابل لغو نیست — از برگشت فاکتور استفاده کنید.");
        if (order.Status == SalesOrderStatus.Cancelled)
            return new CheckResult(false, "سفارش قبلاً لغو شده است.");

        order.Status = SalesOrderStatus.Cancelled;
        await db.SaveChangesAsync();
        await audit.LogAsync(user, "لغو", "سفارش فروش", id.ToString(), $"شماره {order.Number}");
        return new CheckResult(true, "سفارش لغو شد.");
    }

    public async Task<CheckResult> DeleteAsync(int id, string? user)
    {
        var order = await db.SalesOrders.FindAsync(id);
        if (order is null) return new CheckResult(false, "سفارش یافت نشد.");
        if (order.Status != SalesOrderStatus.Draft)
            return new CheckResult(false, "فقط سفارش‌های پیش‌نویس قابل حذف هستند.");

        db.SalesOrders.Remove(order);
        await db.SaveChangesAsync();
        await audit.LogAsync(user, "حذف", "سفارش فروش", id.ToString(), $"شماره {order.Number}");
        return new CheckResult(true, "سفارش حذف شد.");
    }
}
