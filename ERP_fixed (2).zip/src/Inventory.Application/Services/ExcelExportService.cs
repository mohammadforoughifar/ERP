using System.Globalization;
using System.IO.Compression;
using System.Text;

namespace Inventory.Application.Services;

public interface IExcelExportService
{
    /// <summary>خروجی اکسل از روی جدول — ستون‌ها: (عنوان، عرض تقریبی) و ردیف‌های داده</summary>
    byte[] Build(string sheetTitle, List<(string Title, double Width)> columns, IEnumerable<string[]> rows, bool rtl = true);
}

/// <summary>تولید فایل اکسل (xlsx) با OpenXML خالص — بدون وابستگی به کتابخانه‌ی سنگین</summary>
public class ExcelExportService : IExcelExportService
{
    public byte[] Build(string sheetTitle, List<(string Title, double Width)> columns, IEnumerable<string[]> rows, bool rtl = true)
    {
        var data = new List<string[]>();
        data.Add(columns.Select(c => c.Title).ToArray());
        data.AddRange(rows.Select(r => Enumerable.Range(0, columns.Count).Select(i => i < r.Length ? r[i] ?? "" : "").ToArray()));

        string sheetName = Sanitize(sheetTitle);
        int colCount = Math.Max(columns.Count, 1);
        var letters = Enumerable.Range(0, colCount).Select(i => ColumnName(i)).ToList();

        var sb = new StringBuilder();
        sb.Append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>");
        sb.Append("<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">");
        if (rtl) sb.Append("<sheetViews><sheetView workbookViewId=\"0\" rightToLeft=\"1\"/></sheetViews>");
        sb.Append("<cols>");
        for (int i = 0; i < colCount; i++)
            sb.Append($"<col min=\"{i + 1}\" max=\"{i + 1}\" width=\"{Math.Max(8, columns[i].Width)}\" customWidth=\"1\"/>");
        sb.Append("</cols>");
        sb.Append("<sheetData>");
        for (int r = 0; r < data.Count; r++)
        {
            sb.Append($"<row r=\"{r + 1}\">");
            for (int c = 0; c < colCount; c++)
            {
                var cell = XmlEscape(data[r][c]);
                var isNum = r > 0 && decimal.TryParse(cell, NumberStyles.Any, CultureInfo.InvariantCulture, out _) &&
                            double.TryParse(cell, NumberStyles.Any, CultureInfo.InvariantCulture, out _);
                if (isNum)
                    sb.Append($"<c r=\"{letters[c]}{r + 1}\" t=\"n\"><v>{cell.Replace(',', '.')}</v></c>");
                else
                    sb.Append($"<c r=\"{letters[c]}{r + 1}\" t=\"inlineStr\"><is><t xml:space=\"preserve\">{cell}</t></is></c>");
            }
            sb.Append("</row>");
        }
        sb.Append("</sheetData></worksheet>");

        string shared = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<sst xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" count=\"0\" uniqueCount=\"0\"></sst>";
        string styles = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">" +
            "<fonts count=\"1\"><font><sz val=\"11\"/><name val=\"Calibri\"/></font></fonts>" +
            "<fills count=\"1\"><fill><patternFill patternType=\"none\"/></fill></fills>" +
            "<borders count=\"1\"><border/></borders>" +
            "<cellStyleXfs count=\"1\"><xf/></cellStyleXfs>" +
            "<cellXfs count=\"1\"><xf xfId=\"0\"/></cellXfs>" +
            "</styleSheet>";

        using var ms = new MemoryStream();
        using (var zip = new ZipArchive(ms, ZipArchiveMode.Create, true))
        {
            void Add(string path, string content)
            {
                var entry = zip.CreateEntry(path);
                using var writer = new StreamWriter(entry.Open(), new UTF8Encoding(false));
                writer.Write(content);
            }

            Add("[Content_Types].xml",
                "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
                "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
                "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
                "<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>" +
                "<Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>" +
                "<Override PartName=\"/xl/sharedStrings.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml\"/>" +
                "<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>" +
                "</Types>");
            Add("_rels/.rels",
                "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/>" +
                "</Relationships>");
            Add("xl/workbook.xml",
                "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">" +
                "<sheets><sheet name=\"" + sheetName + "\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>");
            Add("xl/_rels/workbook.xml.rels",
                "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/>" +
                "<Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings\" Target=\"sharedStrings.xml\"/>" +
                "<Relationship Id=\"rId3\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/>" +
                "</Relationships>");
            Add("xl/worksheets/sheet1.xml", sb.ToString());
            Add("xl/sharedStrings.xml", shared);
            Add("xl/styles.xml", styles);
        }
        return ms.ToArray();
    }

    private static string Sanitize(string title)
    {
        var t = new string(title.Where(ch => !":\\/?*[]".Contains(ch)).Take(31).ToArray());
        return string.IsNullOrWhiteSpace(t) ? "Sheet1" : t;
    }

    private static string ColumnName(int index)
    {
        var name = "";
        while (index >= 0)
        {
            name = (char)('A' + index % 26) + name;
            index = index / 26 - 1;
        }
        return name;
    }

    private static string XmlEscape(string s) =>
        s.Replace("&", "&amp;").Replace("<", "&lt;").Replace(">", "&gt;").Replace("\"", "&quot;");
}
