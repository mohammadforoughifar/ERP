using System.Globalization;
using System.Text;

namespace Inventory.Application.Common;

/// <summary>
/// تبدیل تاریخ میلادی به شمسی و اعداد فارسی
/// </summary>
public static class FaDate
{
    private static readonly PersianCalendar Pc = new();

    /// <summary>تبدیل تاریخ میلادی به رشته‌ی شمسی (مثال: ۱۴۰۴/۰۵/۱۵)</summary>
    public static string ToFa(this DateTime dt) =>
        $"{Pc.GetYear(dt):0000}/{Pc.GetMonth(dt):00}/{Pc.GetDayOfMonth(dt):00}";

    /// <summary>تبدیل اعداد انگلیسی به فارسی</summary>
    public static string FaDigits(this string s)
    {
        var sb = new StringBuilder(s.Length);
        foreach (var c in s)
            sb.Append(c switch
            {
                '0' => '۰', '1' => '۱', '2' => '۲', '3' => '۳', '4' => '۴',
                '5' => '۵', '6' => '۶', '7' => '۷', '8' => '۸', '9' => '۹',
                _ => c
            });
        return sb.ToString();
    }

    /// <summary>عدد را با جداکننده‌ی هزارگان و رقم فارسی برمی‌گرداند</summary>
    public static string FaNumber(this decimal value, int decimals = 0) =>
        value.ToString($"N{decimals}", CultureInfo.InvariantCulture).FaDigits();

    /// <summary>Overload برای عدد صحیح (گسترش‌دهنده‌ها تبدیل ضمنی نمی‌پذیرند)</summary>
    public static string FaNumber(this int value, int decimals = 0) =>
        ((decimal)value).FaNumber(decimals);

    /// <summary>Overload برای عدد صحیح بزرگ</summary>
    public static string FaNumber(this long value, int decimals = 0) =>
        ((decimal)value).FaNumber(decimals);

    // ============ ابزارهای تقویم شمسی ============

    public static readonly string[] MonthNames =
    {
        "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
        "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"
    };

    /// <summary>نام فارسی ماه شمسی</summary>
    public static string MonthName(int month) => MonthNames[month - 1];

    /// <summary>نام فارسی روز هفته</summary>
    public static string DayName(DayOfWeek day) => day switch
    {
        DayOfWeek.Saturday => "شنبه",
        DayOfWeek.Sunday => "یکشنبه",
        DayOfWeek.Monday => "دوشنبه",
        DayOfWeek.Tuesday => "سه‌شنبه",
        DayOfWeek.Wednesday => "چهارشنبه",
        DayOfWeek.Thursday => "پنجشنبه",
        _ => "جمعه"
    };

    /// <summary>سال، ماه و روز شمسی</summary>
    public static (int Year, int Month, int Day) ToFaParts(this DateTime dt) =>
        (Pc.GetYear(dt), Pc.GetMonth(dt), Pc.GetDayOfMonth(dt));

    /// <summary>تبدیل تاریخ شمسی به میلادی (اعتبارسنجی هم می‌کند)</summary>
    public static DateTime ToGregorian(int year, int month, int day) =>
        Pc.ToDateTime(year, month, day, 0, 0, 0, 0);

    /// <summary>آیا تاریخ شمسی معتبر است؟</summary>
    public static bool IsValidJalali(int year, int month, int day)
    {
        try
        {
            Pc.ToDateTime(year, month, day, 0, 0, 0, 0);
            return year >= 1300 && year <= 1500 && month >= 1 && month <= 12 && day >= 1;
        }
        catch
        {
            return false;
        }
    }

    /// <summary>تعداد روزهای ماه شمسی</summary>
    public static int DaysInJalaliMonth(int year, int month) =>
        Pc.GetDaysInMonth(year, month);

    /// <summary>روز هفته‌ی شمسی (شنبه شروع هفته است)</summary>
    public static DayOfWeek JalaliDayOfWeek(DateTime dt) => Pc.GetDayOfWeek(dt);

    /// <summary>تبدیل ارقام فارسی/عربی به لاتین</summary>
    public static string ToLatinDigits(this string s)
    {
        var sb = new StringBuilder(s.Length);
        foreach (var c in s)
            sb.Append(c switch
            {
                '۰' or '٠' => '0', '۱' or '١' => '1', '۲' or '٢' => '2', '۳' or '٣' => '3',
                '۴' or '٤' => '4', '۵' or '٥' => '5', '۶' or '٦' => '6', '۷' or '٧' => '7',
                '۸' or '٨' => '8', '۹' or '٩' => '9', _ => c
            });
        return sb.ToString();
    }

    /// <summary>
    /// تفسیر رشته‌ی تاریخ شمسی واردشده توسط کاربر.
    /// فرمت‌های پذیرفته‌شده: 1404/05/15 ، 1404-5-15 ، ۱۴۰۴/۵/۱۵ ، 14040515
    /// </summary>
    public static bool TryParseFaDate(string input, out DateTime result)
    {
        result = DateTime.MinValue;
        if (string.IsNullOrWhiteSpace(input)) return false;

        var s = input.ToLatinDigits().Trim().Replace("٫", "/").Replace("،", "/");
        var parts = s.Split('/', '-', ' ', '\\');
        var nums = new List<int>();
        foreach (var p in parts)
            if (int.TryParse(p, out var n)) nums.Add(n);

        // فرمت فشرده‌ی ۸ رقمی: 14040515
        if (nums.Count == 0 && s.Length == 8 && int.TryParse(s, out var packed))
        {
            nums = new List<int> { packed / 10000, packed / 100 % 100, packed % 100 };
        }

        if (nums.Count != 3) return false;

        var year = nums[0];
        if (year < 100) year += 1300;
        if (!IsValidJalali(year, nums[1], nums[2])) return false;

        result = ToGregorian(year, nums[1], nums[2]);
        return true;
    }
}
