using Inventory.Domain.Enums;

namespace Inventory.Application.Common;

/// <summary>
/// دیتاست نمونه‌ی واقعی «کارخانه مبلمان اداری آریا» — مشترک بین seed دیتابیس (MRP/کارت کالا)
/// و فایل‌های نمونه‌ی اکسل، تا هر دو مسیر یک دیتای یکسان بسازند:
/// محصول نهایی ← نیم‌ساخت ← مواد اولیه (BOM سه‌سطحی) + سفارش فروش/خرید باز برای MRP.
/// </summary>
public static class DemoCatalog
{
    public const string FlagKey = "Demo.Factory";
    public const string Version = "1";
    public const string CompanyTitle = "کارخانه مبلمان اداری آریا";

    // ==================== گروه‌ها (درخت) ====================
    public record GroupRow(string Code, string Title, string? ParentCode, string? Desc);

    public static readonly List<GroupRow> Groups = new()
    {
        new("G-01", "مبلمان اداری", null, "محصولات نهایی کارخانه"),
        new("G-02", "میز", "G-01", null),
        new("G-03", "صندلی", "G-01", null),
        new("G-04", "پرونده و کمد", "G-01", null),
        new("G-05", "قطعات نیم‌ساخت", null, "خروجی سالن تولید که ورودی مونتاژ است"),
        new("G-06", "مواد اولیه", null, null),
        new("G-07", "چوب و ورق", "G-06", null),
        new("G-08", "فلزات", "G-06", null),
        new("G-09", "رنگ، چسب و فوم", "G-06", null),
        new("G-10", "یراق‌آلات", "G-06", null),
    };

    // ==================== واحدهای تکمیلی ====================
    public static readonly List<(string Title, UnitCategory Cat)> ExtraUnits = new()
    {
        ("شیت", UnitCategory.Other),
        ("مترمربع", UnitCategory.Other),
        ("ست", UnitCategory.Other),
    };

    // ==================== تأمین‌کنندگان ====================
    public record VendorRow(string Code, string Name, string Phone);

    public static readonly List<VendorRow> Vendors = new()
    {
        new("V-01", "چوبستان پارس", "021-55667788"),
        new("V-02", "فلزکاران تهران", "021-44556677"),
        new("V-03", "شیمی‌سازان آریا", "031-33445566"),
        new("V-04", "یراق‌گستر اصفهان", "031-77889900"),
    };

    // ==================== مشتریان ====================
    public record CustomerRow(string Code, string Name, string Phone, bool Legal = true);

    public static readonly List<CustomerRow> Customers = new()
    {
        new("C-01", "هلدینگ اداری نوآور", "021-88776655", true),
        new("C-02", "اداره کل آموزش پرشین", "021-99887766", true),
        new("C-03", "برج اداری آسمان", "021-77889911", true),
        new("C-04", "فروشگاه مبلمان کارنو", "021-66775544", false),
    };

    // ==================== کالاها (۲۶ قلم در ۳ سطح) ====================
    public record ProductRow(string Code, string Name, string Latin, ProductType Type, string GroupCode,
        string Unit, decimal Purchase, decimal Sale, int LeadTime, decimal Safety,
        LotSizingPolicy Lot, decimal FixedQty, decimal MinOrder, decimal Scrap, string? VendorCode);

    public static readonly List<ProductRow> Products = new()
    {
        // ---------- محصول نهایی (ساخت داخلی — سطح ۰) ----------
        new("F-100", "میز اداری ۱۴۰ پلاس", "Desk 140 Plus", ProductType.Finished, "G-02",
            "عدد", 15_000_000, 24_500_000, 7, 2, LotSizingPolicy.LotForLot, 0, 0, 2m, null),
        new("F-101", "میز کنفرانسی ۸ نفره", "Conference Table 8P", ProductType.Finished, "G-02",
            "عدد", 32_000_000, 48_000_000, 14, 1, LotSizingPolicy.LotForLot, 0, 0, 2m, null),
        new("F-200", "صندلی مدیریتی کلاسیک", "Executive Chair", ProductType.Finished, "G-03",
            "عدد", 8_500_000, 13_800_000, 10, 3, LotSizingPolicy.LotForLot, 0, 0, 2m, null),
        new("F-201", "صندلی کارمندی چرخ‌دار", "Task Chair", ProductType.Finished, "G-03",
            "عدد", 3_200_000, 5_400_000, 7, 5, LotSizingPolicy.LotForLot, 0, 0, 3m, null),
        new("F-300", "کمد فایلی دو درب", "Filing Cabinet 2D", ProductType.Finished, "G-04",
            "عدد", 12_000_000, 19_500_000, 10, 2, LotSizingPolicy.LotForLot, 0, 0, 2m, null),

        // ---------- نیم‌ساخت (ساخت داخلی — سطح ۱) ----------
        new("S-101", "صفحه‌ی روکش‌خورده‌ی میز ۱۴۰", "Desk Top Laminated", ProductType.SemiFinished, "G-05",
            "عدد", 7_800_000, 0, 4, 0, LotSizingPolicy.LotForLot, 0, 0, 5m, null),
        new("S-102", "پایه‌ی جوش‌شده‌ی میز (جفت)", "Welded Desk Legs Pair", ProductType.SemiFinished, "G-05",
            "ست", 2_900_000, 0, 5, 0, LotSizingPolicy.LotForLot, 0, 0, 5m, null),
        new("S-103", "صفحه‌ی کنفرانسی روکش‌خورده", "Conf. Top Laminated", ProductType.SemiFinished, "G-05",
            "عدد", 19_500_000, 0, 5, 0, LotSizingPolicy.LotForLot, 0, 0, 5m, null),
        new("S-201", "قاب پنج‌تکه‌ی صندلی مدیریتی", "Chair Base Frame", ProductType.SemiFinished, "G-05",
            "عدد", 2_400_000, 0, 5, 0, LotSizingPolicy.LotForLot, 0, 0, 8m, null),
        new("S-202", "نشیمن فوم‌کاری‌شده", "Upholstered Seat", ProductType.SemiFinished, "G-05",
            "عدد", 1_900_000, 0, 3, 0, LotSizingPolicy.LotForLot, 0, 0, 3m, null),
        new("S-301", "بدنه‌ی رنگ‌شده‌ی کمد", "Cabinet Body Painted", ProductType.SemiFinished, "G-05",
            "عدد", 8_200_000, 0, 6, 0, LotSizingPolicy.LotForLot, 0, 0, 5m, null),

        // ---------- مواد اولیه (خرید — سطح ۲) ----------
        new("R-101", "ورق MDF ۱۶ میلی‌متر", "MDF Sheet 16mm", ProductType.RawMaterial, "G-07",
            "شیت", 4_300_000, 0, 14, 6, LotSizingPolicy.LotForLot, 0, 10, 0, "V-01"),
        new("R-102", "ورق MDF ۸ میلی‌متر", "MDF Sheet 8mm", ProductType.RawMaterial, "G-07",
            "شیت", 3_100_000, 0, 14, 4, LotSizingPolicy.LotForLot, 0, 10, 0, "V-01"),
        new("R-103", "روکش چوب بلوط", "Oak Veneer", ProductType.RawMaterial, "G-07",
            "مترمربع", 850_000, 0, 10, 20, LotSizingPolicy.LotForLot, 0, 0, 0, "V-01"),
        new("R-109", "پارچه‌ی مخمل اداری", "Office Velvet Fabric", ProductType.RawMaterial, "G-07",
            "متر", 980_000, 0, 15, 30, LotSizingPolicy.LotForLot, 0, 0, 0, "V-01"),
        new("R-105", "لوله‌ی فلزی ۲۵×۲۵", "Steel Tube 25x25", ProductType.RawMaterial, "G-08",
            "متر", 210_000, 0, 7, 50, LotSizingPolicy.LotForLot, 0, 0, 0, "V-02"),
        new("R-106", "پروفیل فلزی ۴۰×۴۰", "Steel Profile 40x40", ProductType.RawMaterial, "G-08",
            "متر", 340_000, 0, 7, 30, LotSizingPolicy.LotForLot, 0, 0, 0, "V-02"),
        new("R-104", "چسب چوب فشرده", "Wood Adhesive", ProductType.RawMaterial, "G-09",
            "کیلوگرم", 320_000, 0, 5, 10, LotSizingPolicy.FixedQty, 100, 0, 0, "V-03"),
        new("R-107", "رنگ پودری الکترواستاتیک", "Powder Coating", ProductType.RawMaterial, "G-09",
            "کیلوگرم", 480_000, 0, 10, 25, LotSizingPolicy.FixedQty, 50, 0, 0, "V-03"),
        new("R-108", "فوم سرد ۵ سانتی", "Cold Foam 5cm", ProductType.RawMaterial, "G-09",
            "مترمربع", 1_250_000, 0, 12, 15, LotSizingPolicy.LotForLot, 0, 0, 0, "V-03"),
        new("R-110", "تخته‌ی فشرده‌ی زیرنشیمن", "Seat Board", ProductType.RawMaterial, "G-07",
            "عدد", 450_000, 0, 7, 0, LotSizingPolicy.LotForLot, 0, 0, 0, "V-01"),
        new("R-111", "پیچ و مهره M6 (بسته ۵۰تایی)", "Screw Pack M6", ProductType.RawMaterial, "G-10",
            "بسته", 85_000, 0, 3, 20, LotSizingPolicy.FixedQty, 200, 0, 0, "V-04"),
        new("R-112", "قفل کمد سه‌کلیده", "Cabinet Lock", ProductType.RawMaterial, "G-10",
            "عدد", 620_000, 0, 7, 4, LotSizingPolicy.LotForLot, 0, 20, 0, "V-04"),
        new("R-113", "دستگیره‌ی فلزی کمد", "Cabinet Handle", ProductType.RawMaterial, "G-10",
            "عدد", 310_000, 0, 7, 6, LotSizingPolicy.LotForLot, 0, 0, 0, "V-04"),
        new("R-114", "ست چرخ صندلی (۵تایی)", "Chair Caster Set", ProductType.RawMaterial, "G-10",
            "ست", 540_000, 0, 5, 8, LotSizingPolicy.FixedQty, 100, 0, 0, "V-04"),
        new("R-115", "ریل کشو ۴۵ سانتی", "Drawer Slide 45cm", ProductType.RawMaterial, "G-10",
            "عدد", 720_000, 0, 6, 4, LotSizingPolicy.LotForLot, 0, 0, 0, "V-04"),
    };

    // ==================== BOM چندسطحی (۱۱ BOM) ====================
    public record BomRow(string ProductCode, string ComponentCode, decimal Qty);

    public static readonly List<BomRow> Boms = new()
    {
        // میز اداری ۱۴۰
        new("F-100", "S-101", 1), new("F-100", "S-102", 1), new("F-100", "R-111", 1),
        // میز کنفرانسی
        new("F-101", "S-103", 1), new("F-101", "S-102", 2), new("F-101", "R-111", 2),
        // صندلی مدیریتی
        new("F-200", "S-201", 1), new("F-200", "S-202", 1), new("F-200", "R-111", 1),
        // صندلی کارمندی (تخت)
        new("F-201", "R-106", 2.5m), new("F-201", "R-107", 0.35m),
        new("F-201", "R-114", 1), new("F-201", "R-111", 1),
        // کمد فایلی
        new("F-300", "S-301", 1), new("F-300", "R-112", 2), new("F-300", "R-113", 2),
        new("F-300", "R-115", 1), new("F-300", "R-111", 2),
        // --- اجزای نیم‌ساخت‌ها (سطح دوم انفجار) ---
        new("S-101", "R-101", 0.6m), new("S-101", "R-103", 2.4m), new("S-101", "R-104", 0.35m),
        new("S-102", "R-105", 6), new("S-102", "R-107", 0.4m),
        new("S-103", "R-101", 1.6m), new("S-103", "R-103", 5.2m), new("S-103", "R-104", 0.75m),
        new("S-201", "R-106", 3.2m), new("S-201", "R-107", 0.5m),
        new("S-202", "R-108", 0.8m), new("S-202", "R-109", 1.2m), new("S-202", "R-110", 1),
        new("S-301", "R-101", 2.2m), new("S-301", "R-102", 0.9m), new("S-301", "R-107", 0.8m),
    };

    // ==================== موجودی افتتاحیه ====================
    public record StockRow(string ProductCode, decimal Qty, decimal WarehouseId);

    /// <summary>موجودی شروع — عمداً کم تا MRF سفارش پیشنهادی واقعی تولید کند</summary>
    public static readonly List<(string Code, decimal Qty, int Warehouse)> OpeningStock = new()
    {
        // انبار مواد اولیه (W2)
        ("R-101", 18, 2), ("R-102", 10, 2), ("R-103", 60, 2), ("R-104", 40, 2),
        ("R-105", 150, 2), ("R-106", 120, 2), ("R-107", 30, 2), ("R-108", 12, 2),
        ("R-109", 40, 2), ("R-110", 25, 2), ("R-111", 90, 2), ("R-112", 16, 2),
        ("R-113", 18, 2), ("R-114", 8, 2), ("R-115", 14, 2),
        // انبار مرکزی (W1) — نیم‌ساخت و محصول
        ("S-101", 3, 1), ("S-102", 2, 1), ("S-103", 1, 1), ("S-201", 4, 1),
        ("S-202", 2, 1), ("S-301", 1, 1),
        ("F-100", 5, 1), ("F-101", 1, 1), ("F-200", 3, 1), ("F-201", 6, 1), ("F-300", 2, 1),
    };

    // ==================== سفارش‌های فروش باز (محرک MRP) ====================
    public record SoRow(string CustomerCode, int InDays, string? Desc, (string Code, decimal Qty, decimal Price)[] Lines);

    public static readonly List<SoRow> SalesOrders = new()
    {
        new("C-01", 10, "پروژه‌ی طبقه‌ی پنجم برج نوآور",
            new[] { ("F-100", 20m, 24_500_000m), ("F-201", 30m, 5_400_000m) }),
        new("C-02", 17, "مجهزسازی مدارس نمونه",
            new[] { ("F-300", 15m, 19_500_000m), ("F-100", 10m, 24_500_000m) }),
        new("C-03", 24, "اتاق‌های کنفرانس برج آسمان",
            new[] { ("F-101", 4m, 48_000_000m), ("F-200", 12m, 13_800_000m) }),
    };

    // ==================== سفارش‌های خرید باز (رسید در راه MRP) ====================
    public record PoRow(string VendorCode, int InDays, string? Desc, (string Code, decimal Qty, decimal Price)[] Lines);

    public static readonly List<PoRow> PurchaseOrders = new()
    {
        // رسید MDF دیرهنگام: +۸ روز ثبت + ۱۴ روز تحویل → برای نیاز هفته‌ی ۱-۲ دیر است → پیام «عجیل»
        new("V-01", 8, "سفارش ورق و روکش — دوره‌ی مهر",
            new[] { ("R-101", 30m, 4_150_000m), ("R-103", 100m, 820_000m) }),
        // لوله سریع می‌رسد
        new("V-02", 2, "سفارش لوله‌ی فولادی",
            new[] { ("R-105", 200m, 205_000m) }),
    };
}
