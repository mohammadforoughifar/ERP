using Inventory.Domain.Entities;

namespace Inventory.Application.Common;

/// <summary>شماره‌گذاری خودکار اسناد به تفکیک سال</summary>
public static class DocumentNumberingService
{
    public static string NextNumber(IEnumerable<InventoryDocument> documents, DateTime date)
    {
        var year = date.Year;
        var max = documents
            .Where(d => d.Date.Year == year)
            .Select(d =>
            {
                var i = d.Number.LastIndexOf('-');
                return int.TryParse(i >= 0 ? d.Number[(i + 1)..] : d.Number, out var n) ? n : 0;
            })
            .DefaultIfEmpty(0)
            .Max();

        return $"{year:0000}-{max + 1:0000}";
    }
}
