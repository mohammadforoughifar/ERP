using System.Globalization;
using System.IO.Compression;
using System.Text;
using System.Xml.Linq;

namespace Inventory.Application.Common;

/// <summary>یک ردیف از شیت اکسل — مقدار سلول‌ها با کلیدِ عنوان ستون</summary>
public class ExcelRow
{
    /// <summary>شماره‌ی ردیف در فایل اکسل (برای پیام خطا)</summary>
    public int RowNumber { get; init; }

    private readonly Dictionary<string, string> _cells;

    internal ExcelRow(int rowNumber, Dictionary<string, string> cells)
    {
        RowNumber = rowNumber;
        _cells = cells;
    }

    /// <summary>مقدار سلول با عنوان ستون (بدون حساسیت به نیم‌فاصله/ی/ک عربی)</summary>
    public string Get(string header) =>
        _cells.TryGetValue(ExcelReader.Norm(header), out var v) ? v : "";

    public bool IsEmpty => _cells.Values.All(string.IsNullOrWhiteSpace);
}

/// <summary>شیت خوانده‌شده از فایل اکسل — ردیف اول به‌عنوان سرستون</summary>
public class ExcelSheet
{
    public List<string> Headers { get; init; } = new();
    public List<ExcelRow> Rows { get; init; } = new();

    public bool HasHeader(string header) =>
        Headers.Any(h => ExcelReader.Norm(h) == ExcelReader.Norm(header));
}

/// <summary>
/// خواننده‌ی xlsx با OpenXML خالص (بدون کتابخانه‌ی خارجی) — جفتِ ExcelExportService.
/// sharedStrings + inlineStr + عدد را پشتیبانی می‌کند و سرستون‌ها را نرمال‌سازی می‌کند.
/// </summary>
public static class ExcelReader
{
    public static ExcelSheet ReadFirstSheet(Stream xlsxStream)
    {
        using var zip = new ZipArchive(xlsxStream, ZipArchiveMode.Read, leaveOpen: true);

        XNamespace main = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
        XNamespace relNs = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
        XNamespace pkgRel = "http://schemas.openxmlformats.org/package/2006/relationships";

        // ---------- sharedStrings ----------
        var shared = new List<string>();
        var sstEntry = zip.GetEntry("xl/sharedStrings.xml");
        if (sstEntry is not null)
        {
            var sst = XDocument.Load(sstEntry.Open());
            foreach (var si in sst.Descendants(main + "si"))
                shared.Add(string.Concat(si.Descendants(main + "t").Select(t => t.Value)));
        }

        // ---------- مسیر شیت اول ----------
        var wbEntry = zip.GetEntry("xl/workbook.xml") ?? throw new InvalidDataException("فایل اکسل معتبر نیست (workbook یافت نشد).");
        var wb = XDocument.Load(wbEntry.Open());
        var firstSheet = wb.Descendants(main + "sheet").FirstOrDefault()
            ?? throw new InvalidDataException("هیچ شیتی در فایل اکسل یافت نشد.");
        var rid = (string?)firstSheet.Attribute(relNs + "id") ?? (string?)firstSheet.Attribute("r:id") ?? "";

        var relsEntry = zip.GetEntry("xl/_rels/workbook.xml.rels")
            ?? throw new InvalidDataException("فایل اکسل معتبر نیست (rels یافت نشد).");
        var rels = XDocument.Load(relsEntry.Open());
        var rel = rels.Descendants(pkgRel + "Relationship")
            .FirstOrDefault(x => (string?)x.Attribute("Id") == rid)
            ?? throw new InvalidDataException("فایل اکسل معتبر نیست (رابطه‌ی شیت یافت نشد).");
        var target = (string?)rel.Attribute("Target") ?? "";
        target = target.StartsWith('/') ? target.TrimStart('/') : "xl/" + target;

        var wsEntry = zip.GetEntry(target) ?? throw new InvalidDataException("فایل اکسل معتبر نیست (شیت یافت نشد).");
        var ws = XDocument.Load(wsEntry.Open());

        // ---------- ردیف‌ها ----------
        var headers = new List<string>();
        var rows = new List<ExcelRow>();

        foreach (var rowEl in ws.Descendants(main + "row"))
        {
            var rowNum = int.TryParse((string?)rowEl.Attribute("r"), out var rn) ? rn : rows.Count + 2;
            var cells = new Dictionary<int, string>();

            foreach (var c in rowEl.Elements(main + "c"))
            {
                var refAttr = (string?)c.Attribute("r");
                if (string.IsNullOrEmpty(refAttr)) continue;
                var col = ColIndex(refAttr);
                if (cells.ContainsKey(col)) continue;

                var t = (string?)c.Attribute("t") ?? "n";
                var vEl = c.Element(main + "v");
                string val;

                switch (t)
                {
                    case "s": // shared string
                        val = int.TryParse(vEl?.Value, out var si) && si >= 0 && si < shared.Count ? shared[si] : "";
                        break;
                    case "inlineStr": // رشته‌ی درون‌سلولی (خروجی ExcelExportService)
                        val = string.Concat(c.Descendants(main + "t").Select(x => x.Value));
                        break;
                    case "e": // خطا
                        continue;
                    default: // n = عدد، str = نتیجه‌ی فرمول
                        val = vEl?.Value ?? "";
                        if (t == "n" && decimal.TryParse(val, NumberStyles.Float, CultureInfo.InvariantCulture, out var d))
                            val = d.ToString("0.############################", CultureInfo.InvariantCulture);
                        break;
                }
                cells[col] = val;
            }

            if (cells.Count == 0 || cells.Values.All(string.IsNullOrWhiteSpace)) continue; // ردیف خالی

            if (headers.Count == 0)
            {
                var maxCol = cells.Keys.DefaultIfEmpty(0).Max();
                for (var i = 0; i <= maxCol; i++)
                    headers.Add(cells.TryGetValue(i, out var v) ? v : "");
                continue; // ردیف اول = سرستون
            }

            var dict = new Dictionary<string, string>();
            for (var i = 0; i < headers.Count; i++)
                if (cells.TryGetValue(i, out var v))
                    dict[Norm(headers[i])] = v;
            rows.Add(new ExcelRow(rowNum, dict));
        }

        return new ExcelSheet { Headers = headers, Rows = rows };
    }

    /// <summary>«AB12» → شماره‌ی ستون (۰ مبنا)</summary>
    private static int ColIndex(string cellRef)
    {
        var idx = 0;
        foreach (var ch in cellRef)
        {
            if (!char.IsLetter(ch)) break;
            idx = idx * 26 + (char.ToUpperInvariant(ch) - 'A' + 1);
        }
        return idx - 1;
    }

    /// <summary>نرمال‌سازی متن: حذف نیم‌فاصله/علامات، یکسان‌سازی ی/ک/ة/أ، فشرده‌ی فاصله‌ها، حروف کوچک لاتین</summary>
    public static string Norm(string? s)
    {
        if (string.IsNullOrWhiteSpace(s)) return "";
        var sb = new StringBuilder(s.Length);
        var prevSpace = true;
        foreach (var ch in s.Trim())
        {
            char? map = ch switch
            {
                '\u200c' or '\u200f' or '\u200e' or '\ufeff' => null,
                'ي' or 'ى' => 'ی',
                'ك' => 'ک',
                'ة' => 'ه',
                'أ' or 'إ' or 'آ' => 'ا',
                'ؤ' => 'و',
                _ => ch,
            };
            if (map is null) continue;
            var c = map.Value;
            if (c == ' ')
            {
                if (prevSpace) continue;
                prevSpace = true;
            }
            else prevSpace = false;
            sb.Append(char.IsWhiteSpace(c) ? ' ' : char.ToLowerInvariant(c));
        }
        return sb.ToString().TrimEnd();
    }

    /// <summary>تبدیل ارقام فارسی/عربی به لاتین + جداکننده‌ها</summary>
    public static string FixDigits(string? s)
    {
        if (string.IsNullOrWhiteSpace(s)) return "";
        var sb = new StringBuilder(s.Length);
        foreach (var ch in s)
        {
            sb.Append(ch switch
            {
                '۰' or '٠' => '0', '۱' or '١' => '1', '۲' or '٢' => '2', '۳' or '٣' => '3',
                '۴' or '٤' => '4', '۵' or '٥' => '5', '۶' or '٦' => '6', '۷' or '٧' => '7',
                '۸' or '٨' => '8', '۹' or '٩' => '9',
                '٫' or '，' => '.',
                '٬' or ',' or ' ' or '\u00a0' or '\'' => "",
                _ => ch,
            });
        }
        return sb.ToString().Trim();
    }

    /// <summary>پارس عدد اعشاری از سلول (پشتیبانی ارقام فارسی و جداکننده‌ی هزارگان) — null یعنی خالی/نامعتبر</summary>
    public static decimal? ParseDec(string? raw)
    {
        var s = FixDigits(raw);
        if (s == "") return null;
        return decimal.TryParse(s, NumberStyles.Float, CultureInfo.InvariantCulture, out var d) ? d : null;
    }

    /// <summary>پارس صحیح — null یعنی خالی، null بودن parse → int?</summary>
    public static int? ParseInt(string? raw) => ParseDec(raw) is { } d ? (int)Math.Round(d) : null;

    /// <summary>پارس بله/خیر — true/false مشخص، null یعنی خالی یا نامشخص</summary>
    public static bool? ParseBool(string? raw)
    {
        var s = Norm(raw);
        if (s == "") return null;
        if (s is "بله" or "بلی" or "فعال" or "yes" or "y" or "true" or "1" or "✓" or "دارد") return true;
        if (s is "خیر" or "نه" or "غیرفعال" or "no" or "n" or "false" or "0" or "ندارد") return false;
        return null;
    }
}
