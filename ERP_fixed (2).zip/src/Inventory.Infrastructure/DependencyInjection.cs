using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Inventory.Application.Common;
using Inventory.Infrastructure.Persistence;

namespace Inventory.Infrastructure;

public static class DependencyInjection
{
    /// <summary>
    /// انتخاب دیتابیس از روی تنظیمات:
    ///   "Database:Provider" = "SqlServer" → SQL Server با میرگریشن (تولید/اعمال خودکار)
    ///   "Database:Provider" = "Sqlite" (پیش‌فرض توسعه) → SQLite با EnsureCreated
    /// </summary>
    public static IServiceCollection AddInfrastructure(this IServiceCollection services, IConfiguration configuration)
    {
        var provider = configuration["Database:Provider"] ?? "Sqlite";

        if (provider.Equals("SqlServer", StringComparison.OrdinalIgnoreCase))
        {
            var connectionString = configuration.GetConnectionString("SqlServer")
                ?? throw new InvalidOperationException(
                    "ConnectionStrings:SqlServer در appsettings.json تنظیم نشده است.");

            services.AddDbContext<IAppDbContext, AppDbContext>(options =>
                options.UseSqlServer(connectionString, sql =>
                    sql.MigrationsAssembly("Inventory.Infrastructure")));
        }
        else
        {
            var connectionString = configuration.GetConnectionString("DefaultConnection")
                                   ?? "Data Source=inventory.db";

            services.AddDbContext<IAppDbContext, AppDbContext>(options =>
                options.UseSqlite(connectionString));
        }

        services.AddScoped<IDateTime, DateTimeProvider>();
        return services;
    }
}

public class DateTimeProvider : IDateTime
{
    public DateTime Now => DateTime.Now;
}
