using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;

namespace Inventory.Infrastructure.Persistence;

/// <summary>
/// فکتوری دیزاین‌تایم برای ابزارهای dotnet ef (migrations/script) —
/// بدون نیاز به اجرای برنامه و اتصال واقعی، اسکیمای SQL Server ساخته می‌شود.
/// </summary>
public class DesignTimeDbContextFactory : IDesignTimeDbContextFactory<AppDbContext>
{
    public AppDbContext CreateDbContext(string[] args)
    {
        var connectionString = Environment.GetEnvironmentVariable("INVENTORY_SQL_CONNECTION")
            ?? "Server=localhost,1433;Database=InventoryDb;User Id=sa;Password=Your_password123;TrustServerCertificate=True;";

        var options = new DbContextOptionsBuilder<AppDbContext>()
            .UseSqlServer(connectionString, sql => sql.MigrationsAssembly("Inventory.Infrastructure"))
            .Options;

        return new AppDbContext(options);
    }
}
