namespace Inventory.Web.Components.Shared;

/// <summary>گزینه‌ی کمبوباکس جستجوپذیر</summary>
public record SelectItem<TValue>(TValue Value, string Text);
