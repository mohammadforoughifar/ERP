using System.Security.Claims;
using Inventory.Application.DTOs;
using Inventory.Domain.Enums;
using Microsoft.AspNetCore.Components.Authorization;

namespace Inventory.Web.Services;

/// <summary>کاربر جاری واردشده — اطلاعات نمایشی و نقش برای مجوزها</summary>
public class CurrentUserService(AuthenticationStateProvider provider)
{
    public async Task<UserInfo?> GetAsync()
    {
        var state = await provider.GetAuthenticationStateAsync();
        var principal = state.User;
        if (principal.Identity is not { IsAuthenticated: true }) return null;

        var roleText = principal.FindFirstValue(ClaimTypes.Role);
        var role = Enum.TryParse<UserRole>(roleText, out var r) ? r : UserRole.Storekeeper;
        var name = principal.Identity.Name ?? "کاربر";

        return new UserInfo(name, role);
    }

    public static string RoleTitle(UserRole role) => role switch
    {
        UserRole.Admin => "مدیر سیستم",
        UserRole.Accountant => "حسابدار",
        _ => "انباردار"
    };
}
