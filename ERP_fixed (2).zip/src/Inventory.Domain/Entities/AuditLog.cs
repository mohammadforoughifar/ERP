namespace Inventory.Domain.Entities;

/// <summary>لاگ حسابرسی — ثبت هر عملیات مهم (چه کسی، کی، چه چیزی)</summary>
public class AuditLog
{
    public int Id { get; set; }
    public DateTime Date { get; set; } = DateTime.Now;

    public string UserName { get; set; } = string.Empty;

    /// <summary>عملیات (ایجاد / ویرایش / تأیید / حذف / ورود / ...)</summary>
    public string Action { get; set; } = string.Empty;

    /// <summary>نوع موجودیت (کالا / سند / انبارگردانی / سفارش خرید / ...)</summary>
    public string EntityType { get; set; } = string.Empty;

    public string? EntityId { get; set; }

    /// <summary>شرح و جزئیات (مقادیر قبل/بعد به‌صورت خلاصه)</summary>
    public string? Details { get; set; }
}
