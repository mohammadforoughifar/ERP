namespace Inventory.Domain.Entities;

/// <summary>موجودی هر کالا در هر انبار (تعدادی و ریالی)</summary>
public class WarehouseItem
{
    public int Id { get; set; }
    public int WarehouseId { get; set; }
    public Warehouse Warehouse { get; set; } = null!;

    public int ProductId { get; set; }
    public Product Product { get; set; } = null!;

    /// <summary>موجودی تعدادی</summary>
    public decimal Quantity { get; set; }

    /// <summary>موجودی ریالی (به قیمت تمام‌شده)</summary>
    public decimal TotalCost { get; set; }

    /// <summary>قیمت میانگین موزون هر واحد</summary>
    public decimal AverageUnitCost =>
        Quantity == 0 ? 0 : Math.Round(TotalCost / Quantity, 4);

    public DateTime UpdatedAt { get; set; } = DateTime.Now;
}
