namespace Inventory.Domain.Entities;

/// <summary>سند حسابداری (حواله‌ی حسابداری) — خروجی اتصال انبار به حسابداری</summary>
public class AccountingVoucher
{
    public int Id { get; set; }
    public string Number { get; set; } = string.Empty;
    public DateTime Date { get; set; } = DateTime.Now;

    /// <summary>نوع سند مبدأ (InventoryDocument)</summary>
    public string SourceType { get; set; } = "InventoryDocument";

    /// <summary>شناسه‌ی سند انبار مبدأ</summary>
    public int? SourceId { get; set; }
    public InventoryDocument? Source { get; set; }

    public string? Description { get; set; }
    public string CreatedBy { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; } = DateTime.Now;

    public ICollection<AccountingVoucherLine> Lines { get; set; } = new List<AccountingVoucherLine>();

    public decimal TotalDebit => Lines.Sum(l => l.Debit);
    public decimal TotalCredit => Lines.Sum(l => l.Credit);
}

/// <summary>ردیف سند حسابداری — یک بدهکار یا بستانکار</summary>
public class AccountingVoucherLine
{
    public int Id { get; set; }
    public int VoucherId { get; set; }
    public AccountingVoucher Voucher { get; set; } = null!;

    public string AccountCode { get; set; } = string.Empty;
    public string AccountTitle { get; set; } = string.Empty;
    public decimal Debit { get; set; }
    public decimal Credit { get; set; }
}
