using Inventory.Domain.Enums;

namespace Inventory.Domain.Entities;

/// <summary>تعریف یک گردش تأیید (مثلاً گردش خرید) — توسط مدیر سیستم طراحی می‌شود</summary>
public class WorkflowDef
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;

    /// <summary>نوع سندِ مشمول گردش (مثلاً PurchaseOrder)</summary>
    public string DocType { get; set; } = "PurchaseOrder";

    /// <summary>فقط یک گردشِ فعال برای هر نوع سند — با فعال‌کردن این، بقیه غیرفعال می‌شوند</summary>
    public bool IsActive { get; set; }

    public string CreatedBy { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; } = DateTime.Now;

    public ICollection<WorkflowStep> Steps { get; set; } = new List<WorkflowStep>();
}

/// <summary>یک گام از زنجیره‌ی تأیید — ترتیب با OrderIndex</summary>
public class WorkflowStep
{
    public int Id { get; set; }
    public int WorkflowDefId { get; set; }
    public WorkflowDef WorkflowDef { get; set; } = null!;

    public int OrderIndex { get; set; }
    public string Title { get; set; } = string.Empty;

    /// <summary>تأییدکننده بر اساس نقش (اگر نقش تعیین شود، کاربر خاص نادیده گرفته می‌شود)</summary>
    public UserRole? ApproverRole { get; set; }

    /// <summary>تأییدکننده‌ی خاص (نام کاربری) — وقتی نقش خالی است</summary>
    public string? ApproverUserName { get; set; }

    /// <summary>این گام فقط برای سفارش‌های با مبلغ ≥ این مقدار اجرا می‌شود (۰ = همیشه)</summary>
    public decimal MinAmount { get; set; }
}

/// <summary>وضعیت اجرای یک گردش</summary>
public enum WorkflowRunStatus
{
    /// <summary>در حال گردش</summary>
    InProgress = 1,

    /// <summary>تأیید نهایی شد</summary>
    Approved = 2,

    /// <summary>رد شد</summary>
    Rejected = 3,

    /// <summary>لغو توسط فرستنده</summary>
    Cancelled = 4,
}

/// <summary>
/// اجرای زنده‌ی یک گردش روی یک سند — پلان گام‌ها در لحظه‌ی ارسال به‌صورت JSON
/// اسنپ‌شات می‌شود تا ویرایش بعدیِ تعریف، گردش‌های در جریان را به‌هم نریزد.
/// </summary>
public class WorkflowInstance
{
    public int Id { get; set; }

    public string DocType { get; set; } = "PurchaseOrder";
    public int EntityId { get; set; }

    /// <summary>شماره‌ی سند (اسنپ‌شات برای نمایش لیست انتظار)</summary>
    public string DocNumber { get; set; } = string.Empty;

    public int DefId { get; set; }
    public string DefName { get; set; } = string.Empty;

    /// <summary>مبلغ سند در لحظه‌ی ارسال — ملاک شرط حداقل مبلغِ گام‌ها</summary>
    public decimal TotalAmount { get; set; }

    /// <summary>اسنپ‌شات گام‌های واجد شرط (List&lt;WorkflowPlanStep&gt;)</summary>
    public string PlanJson { get; set; } = "[]";

    /// <summary>ایندکس گام جاری در پلان (۰ مبنا)</summary>
    public int CurrentIndex { get; set; }

    public WorkflowRunStatus Status { get; set; } = WorkflowRunStatus.InProgress;

    public string StartedBy { get; set; } = string.Empty;
    public DateTime StartedAt { get; set; } = DateTime.Now;
    public DateTime? FinishedAt { get; set; }

    public ICollection<WorkflowLog> Logs { get; set; } = new List<WorkflowLog>();
}

/// <summary>تاریخچه‌ی رویدادهای یک گردش (ارسال/تأیید/رد/عبور از گام)</summary>
public class WorkflowLog
{
    public int Id { get; set; }
    public int InstanceId { get; set; }
    public WorkflowInstance Instance { get; set; } = null!;

    public string StepTitle { get; set; } = string.Empty;
    public string UserName { get; set; } = string.Empty;
    public string Action { get; set; } = string.Empty;
    public string? Comment { get; set; }
    public DateTime At { get; set; } = DateTime.Now;
}
