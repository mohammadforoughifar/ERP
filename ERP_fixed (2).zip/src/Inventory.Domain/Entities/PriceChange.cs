namespace Inventory.Domain.Entities;

/// <summary>سند تعدیل قیمت کالا — اصلاح دستی قیمت با ثبت تاریخچه</summary>
public class PriceChangeDocument
{
    public int Id { get; set; }
    public string Number { get; set; } = string.Empty;
    public DateTime Date { get; set; } = DateTime.Now;

    public int ProductId { get; set; }
    public Product Product { get; set; } = null!;

    public decimal OldPurchasePrice { get; set; }
    public decimal NewPurchasePrice { get; set; }

    public decimal? OldSalePrice { get; set; }
    public decimal? NewSalePrice { get; set; }

    public string? Reason { get; set; }
    public string CreatedBy { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; } = DateTime.Now;
}
