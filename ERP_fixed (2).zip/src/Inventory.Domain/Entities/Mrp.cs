using Inventory.Domain.Enums;

namespace Inventory.Domain.Entities;

/// <summary>یک اجرای موتور MRP — سناریوی ذخیره‌شده</summary>
public class MrpRun
{
    public int Id { get; set; }
    public string Title { get; set; } = string.Empty;
    public string CreatedBy { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; } = DateTime.Now;

    /// <summary>افق برنامه‌ریزی (هفته)</summary>
    public int Weeks { get; set; } = 8;

    /// <summary>تاریخ شروع افق</summary>
    public DateTime StartDate { get; set; } = DateTime.Today;

    /// <summary>توضیح منبع نیاز (سفارش‌های فروش باز + دستی)</summary>
    public string? Source { get; set; }

    /// <summary>خلاصه‌ی جدول زمان‌بندی همه‌ی اقلام (JSON) برای نمایش سناریو</summary>
    public string? ResultJson { get; set; }

    public ICollection<MrpPlannedOrder> PlannedOrders { get; set; } = new List<MrpPlannedOrder>();
    public ICollection<MrpRunMessage> Messages { get; set; } = new List<MrpRunMessage>();
}

/// <summary>سفارش پیشنهادی MRP — قابل تبدیل به سفارش خرید</summary>
public class MrpPlannedOrder
{
    public int Id { get; set; }
    public int MrpRunId { get; set; }
    public MrpRun MrpRun { get; set; } = null!;

    public int ProductId { get; set; }
    public Product Product { get; set; } = null!;

    public decimal Quantity { get; set; }

    /// <summary>تاریخ سفارش (امروز باید سفارش داده شود)</summary>
    public DateTime OrderDate { get; set; }

    /// <summary>تاریخ نیاز (رسید)</summary>
    public DateTime NeedDate { get; set; }

    /// <summary>خرید یا ساخت</summary>
    public ProcurementType Type { get; set; } = ProcurementType.Buy;

    public int? VendorId { get; set; }
    public Vendor? Vendor { get; set; }

    /// <summary>رد پا — این نیاز از کجا آمده (سفارش فروش / والد BOM)</summary>
    public string? Pegging { get; set; }

    public bool IsConverted { get; set; }
    public int? PurchaseOrderId { get; set; }
}

/// <summary>پیام اقدام MRP — عجیل / موکول / لغو درباره‌ی سفارش‌های خرید باز</summary>
public class MrpRunMessage
{
    public int Id { get; set; }
    public int MrpRunId { get; set; }
    public MrpRun MrpRun { get; set; } = null!;

    /// <summary>Expedite / Postpone / Cancel</summary>
    public string Type { get; set; } = "Expedite";

    public int PurchaseOrderId { get; set; }
    public string PoNumber { get; set; } = string.Empty;

    public int ProductId { get; set; }
    public string ProductName { get; set; } = string.Empty;

    public string Text { get; set; } = string.Empty;
}
