namespace Inventory.Domain.Entities;

/// <summary>ردیف سند انبار — یک حرکت کالا</summary>
public class InventoryDocumentLine
{
    public int Id { get; set; }
    public int DocumentId { get; set; }
    public InventoryDocument Document { get; set; } = null!;

    public int ProductId { get; set; }
    public Product Product { get; set; } = null!;

    /// <summary>تعداد (همیشه مثبت ذخیره می‌شود؛ جهت از روی سند مشخص است)</summary>
    public decimal Quantity { get; set; }

    /// <summary>قیمت واحد</summary>
    public decimal UnitPrice { get; set; }

    /// <summary>بهای تمام‌شده‌ی واحد در لحظه‌ی ثبت (برای خروج‌ها)</summary>
    public decimal UnitCost { get; set; }

    // ============ رهگیری لوت / انقضا / سریال (فاز ۳) ============

    /// <summary>شماره‌ی لوت / بچ</summary>
    public string? LotNumber { get; set; }

    /// <summary>تاریخ انقضا</summary>
    public DateTime? ExpiryDate { get; set; }

    /// <summary>شماره سریال‌ها (با کاما جدا شده) — برای کالاهای سریال‌دار</summary>
    public string? SerialNumbers { get; set; }

    /// <summary>محل نگهداری (قفسه/رف) — اختیاری</summary>
    public int? BinId { get; set; }
    public StorageBin? Bin { get; set; }

    public decimal Total => Quantity * UnitPrice;
}
