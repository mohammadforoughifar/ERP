using Inventory.Domain.Enums;

namespace Inventory.Domain.Entities;

/// <summary>تأمین‌کننده (فروشنده)</summary>
public class Vendor
{
    public int Id { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Phone { get; set; }
    public string? Address { get; set; }
    public string? TaxId { get; set; }

    /// <summary>نوع شخصیت: حقیقی یا حقوقی</summary>
    public PersonType PersonType { get; set; } = PersonType.Real;

    public bool IsActive { get; set; } = true;
}

/// <summary>سفارش خرید (PO)</summary>
public class PurchaseOrder
{
    public int Id { get; set; }
    public string Number { get; set; } = string.Empty;
    public DateTime Date { get; set; } = DateTime.Now;

    public int VendorId { get; set; }
    public Vendor Vendor { get; set; } = null!;

    public PurchaseOrderStatus Status { get; set; } = PurchaseOrderStatus.Draft;

    /// <summary>انبار پیش‌فرض رسید این سفارش</summary>
    public int? WarehouseId { get; set; }
    public Warehouse? Warehouse { get; set; }

    public string? Description { get; set; }
    public string CreatedBy { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; } = DateTime.Now;

    public DateTime? ConfirmedAt { get; set; }
    public DateTime? ReceivedAt { get; set; }

    /// <summary>سند رسید خرید صادره از این سفارش</summary>
    public int? ReceiptDocumentId { get; set; }
    public InventoryDocument? ReceiptDocument { get; set; }

    public ICollection<PurchaseOrderLine> Lines { get; set; } = new List<PurchaseOrderLine>();
}

/// <summary>ردیف سفارش خرید</summary>
public class PurchaseOrderLine
{
    public int Id { get; set; }
    public int OrderId { get; set; }
    public PurchaseOrder Order { get; set; } = null!;

    public int ProductId { get; set; }
    public Product Product { get; set; } = null!;

    public decimal Quantity { get; set; }
    public decimal UnitPrice { get; set; }

    /// <summary>تعداد رسیدشده (تاکنون)</summary>
    public decimal ReceivedQuantity { get; set; }

    public decimal Total => Quantity * UnitPrice;
}
