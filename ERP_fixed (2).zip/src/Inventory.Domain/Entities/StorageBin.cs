namespace Inventory.Domain.Entities;

/// <summary>محل نگهداری (قفسه / رف / Bin) داخل یک انبار</summary>
public class StorageBin
{
    public int Id { get; set; }

    public int WarehouseId { get; set; }
    public Warehouse Warehouse { get; set; } = null!;

    /// <summary>کد محل (مثلاً A1-02)</summary>
    public string Code { get; set; } = string.Empty;

    /// <summary>عنوان / ناحیه (مثلاً قفسه‌ی شرقی)</summary>
    public string Title { get; set; } = string.Empty;

    public bool IsActive { get; set; } = true;

    public ICollection<BinStock> Stocks { get; set; } = new List<BinStock>();
}

/// <summary>موجودی کالا در یک محل نگهداری (سطح زیرین موجودی انبار)</summary>
public class BinStock
{
    public int Id { get; set; }
    public int BinId { get; set; }
    public StorageBin Bin { get; set; } = null!;

    public int ProductId { get; set; }
    public Product Product { get; set; } = null!;

    public decimal Quantity { get; set; }
    public decimal TotalCost { get; set; }
}
