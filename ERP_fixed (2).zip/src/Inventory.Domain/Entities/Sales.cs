using Inventory.Domain.Enums;

namespace Inventory.Domain.Entities;

/// <summary>مشتری</summary>
public class Customer
{
    public int Id { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Phone { get; set; }
    public string? Address { get; set; }
    public string? NationalId { get; set; }

    /// <summary>نوع شخصیت: حقیقی یا حقوقی</summary>
    public PersonType PersonType { get; set; } = PersonType.Real;

    public bool IsActive { get; set; } = true;
}

/// <summary>سفارش فروش (SO)</summary>
public class SalesOrder
{
    public int Id { get; set; }
    public string Number { get; set; } = string.Empty;
    public DateTime Date { get; set; } = DateTime.Now;

    public int CustomerId { get; set; }
    public Customer Customer { get; set; } = null!;

    public SalesOrderStatus Status { get; set; } = SalesOrderStatus.Draft;

    /// <summary>انبار خروج این سفارش</summary>
    public int? WarehouseId { get; set; }
    public Warehouse? Warehouse { get; set; }

    public string? Description { get; set; }
    public string CreatedBy { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; } = DateTime.Now;

    public DateTime? ConfirmedAt { get; set; }
    public DateTime? InvoicedAt { get; set; }

    /// <summary>حواله فروش صادره از این سفارش</summary>
    public int? IssueDocumentId { get; set; }
    public InventoryDocument? IssueDocument { get; set; }

    /// <summary>فاکتور صادره از این سفارش</summary>
    public int? InvoiceId { get; set; }
    public SalesInvoice? Invoice { get; set; }

    public ICollection<SalesOrderLine> Lines { get; set; } = new List<SalesOrderLine>();
}

/// <summary>ردیف سفارش فروش</summary>
public class SalesOrderLine
{
    public int Id { get; set; }
    public int OrderId { get; set; }
    public SalesOrder Order { get; set; } = null!;

    public int ProductId { get; set; }
    public Product Product { get; set; } = null!;

    public decimal Quantity { get; set; }
    public decimal UnitPrice { get; set; }

    public decimal Total => Quantity * UnitPrice;
}

/// <summary>فاکتور فروش</summary>
public class SalesInvoice
{
    public int Id { get; set; }
    public string Number { get; set; } = string.Empty;
    public DateTime Date { get; set; } = DateTime.Now;

    public int CustomerId { get; set; }
    public Customer Customer { get; set; } = null!;

    public int? OrderId { get; set; }
    public SalesOrder? Order { get; set; }

    /// <summary>حواله فروش مرتبط (صادرشده هنگام فاکتور)</summary>
    public int? IssueDocumentId { get; set; }
    public InventoryDocument? IssueDocument { get; set; }

    public string? Description { get; set; }
    public string CreatedBy { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; } = DateTime.Now;

    /// <summary>درصد تخفیف کل فاکتور</summary>
    public decimal DiscountPercent { get; set; }

    public decimal Subtotal { get; set; }
    public decimal DiscountAmount { get; set; }
    public decimal Total { get; set; }

    /// <summary>آیا این فاکتور برگشت خورده است؟</summary>
    public bool IsReturned { get; set; }

    /// <summary>سند رسید برگشت از فروش</summary>
    public int? ReturnDocumentId { get; set; }
    public InventoryDocument? ReturnDocument { get; set; }

    public DateTime? ReturnedAt { get; set; }
    public string? ReturnedBy { get; set; }

    public ICollection<SalesInvoiceLine> Lines { get; set; } = new List<SalesInvoiceLine>();
}

/// <summary>ردیف فاکتور فروش</summary>
public class SalesInvoiceLine
{
    public int Id { get; set; }
    public int InvoiceId { get; set; }
    public SalesInvoice Invoice { get; set; } = null!;

    public int ProductId { get; set; }
    public Product Product { get; set; } = null!;

    public decimal Quantity { get; set; }
    public decimal UnitPrice { get; set; }

    /// <summary>بهای تمام‌شده در لحظه خروج (برای برگشت و سود ناخالص)</summary>
    public decimal UnitCost { get; set; }

    public decimal Total => Quantity * UnitPrice;
}
