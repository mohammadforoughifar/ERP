namespace Inventory.Domain.Entities;

/// <summary>انبار — چند انبار از روز اول پشتیبانی می‌شود</summary>
public class Warehouse
{
    public int Id { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Title { get; set; } = string.Empty;

    public string? ManagerName { get; set; }
    public string? Address { get; set; }
    public string? Phone { get; set; }
    public bool IsActive { get; set; } = true;

    public ICollection<WarehouseItem> Items { get; set; } = new List<WarehouseItem>();
}
