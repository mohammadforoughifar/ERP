using Inventory.Domain.Enums;

namespace Inventory.Domain.Entities;

/// <summary>کاربر سیستم</summary>
public class AppUser
{
    public int Id { get; set; }
    public string Username { get; set; } = string.Empty;
    public string PasswordHash { get; set; } = string.Empty;
    public string DisplayName { get; set; } = string.Empty;
    public UserRole Role { get; set; } = UserRole.Storekeeper;
    public bool IsActive { get; set; } = true;
}
