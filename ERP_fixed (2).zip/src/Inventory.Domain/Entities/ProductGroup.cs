namespace Inventory.Domain.Entities;

/// <summary>گروه کالا — دسته‌بندی سلسله‌مراتبی</summary>
public class ProductGroup
{
    public int Id { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Title { get; set; } = string.Empty;

    /// <summary>گروه والد (برای ساختار درختی)</summary>
    public int? ParentId { get; set; }
    public ProductGroup? Parent { get; set; }
    public ICollection<ProductGroup> Children { get; set; } = new List<ProductGroup>();

    public bool IsActive { get; set; } = true;
    public string? Description { get; set; }

    public ICollection<Product> Products { get; set; } = new List<Product>();
}
