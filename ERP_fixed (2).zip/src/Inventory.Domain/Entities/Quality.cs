using Inventory.Domain.Enums;

namespace Inventory.Domain.Entities;

/// <summary>بازرسی کیفیت یک سند ورود (رسید) — قبول یا رد</summary>
public class QualityInspection
{
    public int Id { get; set; }
    public string Number { get; set; } = string.Empty;
    public DateTime Date { get; set; } = DateTime.Now;

    /// <summary>سند ورود مورد بازرسی (رسید خرید / برگشت از فروش)</summary>
    public int DocumentId { get; set; }
    public InventoryDocument Document { get; set; } = null!;

    public QualityStatus Status { get; set; }
    public string? Notes { get; set; }
    public string CreatedBy { get; set; } = string.Empty;
}
