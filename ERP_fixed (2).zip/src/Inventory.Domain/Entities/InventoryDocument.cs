using Inventory.Domain.Entities;

namespace Inventory.Domain.Entities;

/// <summary>سند انبار (رسید / حواله / تعدیل)</summary>
public class InventoryDocument
{
    public int Id { get; set; }

    /// <summary>شماره‌ی سند (خودکار)</summary>
    public string Number { get; set; } = string.Empty;

    /// <summary>نوع سند</summary>
    public Enums.DocumentType Type { get; set; }

    /// <summary>وضعیت سند — فقط تأییدشده روی موجودی اثر می‌گذارد</summary>
    public Enums.DocumentStatus Status { get; set; } = Enums.DocumentStatus.Draft;

    public DateTime Date { get; set; } = DateTime.Now;
    public int? WarehouseId { get; set; }
    public Warehouse? Warehouse { get; set; }

    /// <summary>انبار مقصد (فقط برای سند انتقال بین انبار)</summary>
    public int? DestinationWarehouseId { get; set; }
    public Warehouse? DestinationWarehouse { get; set; }

    /// <summary>آیا سند انبار در حسابداری ثبت شده است؟</summary>
    public bool IsPostedToAccounting { get; set; }

    /// <summary>شناسه‌ی سند حسابداری صادره از این سند</summary>
    public int? AccountingVoucherId { get; set; }
    public AccountingVoucher? AccountingVoucher { get; set; }

    public string? PartyName { get; set; }
    public string? Description { get; set; }

    public string CreatedBy { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; } = DateTime.Now;
    public string? ConfirmedBy { get; set; }
    public DateTime? ConfirmedAt { get; set; }

    public ICollection<InventoryDocumentLine> Lines { get; set; } = new List<InventoryDocumentLine>();

    /// <summary>جهت اثر روی موجودی: ورود = مثبت، خروج = منفی</summary>
    public int Direction =>
        Type is Enums.DocumentType.PurchaseReceipt or Enums.DocumentType.SalesReturnReceipt
            or Enums.DocumentType.ProductionReceipt or Enums.DocumentType.OpeningReceipt
            or Enums.DocumentType.TransferReceipt or Enums.DocumentType.AdjustmentReceipt
            or Enums.DocumentType.ConsignmentReceipt
        ? +1 : -1;

    /// <summary>آیا سند نوع ورود (رسید) است؟</summary>
    public bool IsReceipt => Direction > 0;

    /// <summary>آیا سند از نوع انتقال بین انبار است؟</summary>
    public bool IsTransfer => Type is Enums.DocumentType.TransferReceipt or Enums.DocumentType.TransferIssue;

    /// <summary>آیا سند از نوع کالای امانی است؟</summary>
    public bool IsConsignment => Type is Enums.DocumentType.ConsignmentReceipt or Enums.DocumentType.ConsignmentReturn;
}
