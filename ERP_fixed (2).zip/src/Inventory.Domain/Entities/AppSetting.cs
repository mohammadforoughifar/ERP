using System.ComponentModel.DataAnnotations;

namespace Inventory.Domain.Entities;

/// <summary>تنظیمات کلید/مقدار برنامه (مثل اجازه‌ی موجودی منفی، ماهیت اسناد و...)</summary>
public class AppSetting
{
    [Key]
    public string Key { get; set; } = string.Empty;
    public string? Value { get; set; }
}
