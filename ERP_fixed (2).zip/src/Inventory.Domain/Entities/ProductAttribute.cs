namespace Inventory.Domain.Entities;

/// <summary>تعریف ویژگی تکمیلی کالا — رنگ، سایز، وزن، ابعاد، مدل و... (قابل تعریف)</summary>
public class ProductAttributeDefinition
{
    public int Id { get; set; }

    /// <summary>نام ویژگی (مثلاً «رنگ»)</summary>
    public string Name { get; set; } = string.Empty;

    public bool IsActive { get; set; } = true;

    public ICollection<ProductAttributeValue> Values { get; set; } = new List<ProductAttributeValue>();
}

/// <summary>مقدار ویژگی برای یک کالای خاص (مثلاً رنگ کالای X = قرمز)</summary>
public class ProductAttributeValue
{
    public int Id { get; set; }

    public int ProductId { get; set; }
    public Product Product { get; set; } = null!;

    public int DefinitionId { get; set; }
    public ProductAttributeDefinition Definition { get; set; } = null!;

    /// <summary>مقدار ویژگی (متن آزاد)</summary>
    public string Value { get; set; } = string.Empty;
}
