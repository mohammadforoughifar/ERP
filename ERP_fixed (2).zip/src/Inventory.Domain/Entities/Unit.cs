using Inventory.Domain.Enums;

namespace Inventory.Domain.Entities;

/// <summary>واحد سنجش با قابلیت تبدیل واحد</summary>
public class Unit
{
    public int Id { get; set; }
    public string Title { get; set; } = string.Empty;
    public UnitCategory Category { get; set; } = UnitCategory.Count;

    /// <summary>واحد پایه‌ای که این واحد به آن تبدیل می‌شود (مثال: کارتن → عدد)</summary>
    public int? BaseUnitId { get; set; }
    public Unit? BaseUnit { get; set; }

    /// <summary>ضریب تبدیل به واحد پایه (مثال: کارتن = ۲۴ عدد → 24)</summary>
    public decimal Factor { get; set; } = 1;

    public string? Description { get; set; }
}
