namespace Inventory.Domain.Entities;

/// <summary>کالای مرکب / کیت — تعریف بیل‌آف‌متریال (BOM)</summary>
public class Bom
{
    public int Id { get; set; }

    /// <summary>کالای نهایی (محصول / کیت)</summary>
    public int ProductId { get; set; }
    public Product Product { get; set; } = null!;

    public string? Title { get; set; }
    public bool IsActive { get; set; } = true;

    public ICollection<BomLine> Lines { get; set; } = new List<BomLine>();
}

/// <summary>ردیف BOM — یک جزء از کیت</summary>
public class BomLine
{
    public int Id { get; set; }
    public int BomId { get; set; }
    public Bom Bom { get; set; } = null!;

    public int ComponentProductId { get; set; }
    public Product ComponentProduct { get; set; } = null!;

    /// <summary>مقدار جزء برای یک واحد کالای نهایی</summary>
    public decimal Quantity { get; set; }
}
