namespace Inventory.Domain.Entities;

/// <summary>لوت / بچ موجودی — رهگیری گروه ورود و تاریخ انقضا در سطح انبار</summary>
public class StockBatch
{
    public int Id { get; set; }

    public int ProductId { get; set; }
    public Product Product { get; set; } = null!;

    public int WarehouseId { get; set; }
    public Warehouse Warehouse { get; set; } = null!;

    /// <summary>شماره‌ی لوت (دست‌ساز یا خودکار)</summary>
    public string LotNumber { get; set; } = string.Empty;

    /// <summary>تاریخ انقضا (برای کالاهای دارای رهگیری انقضا)</summary>
    public DateTime? ExpiryDate { get; set; }

    /// <summary>موجودی باقی‌مانده‌ی این لوت</summary>
    public decimal Quantity { get; set; }

    /// <summary>بهای تمام‌شده‌ی واحد در لحظه‌ی ورود (اطلاعاتی)</summary>
    public decimal UnitCost { get; set; }

    /// <summary>تاریخ ورود لوت به انبار</summary>
    public DateTime ReceivedAt { get; set; } = DateTime.Now;

    /// <summary>سند ورود مبدأ</summary>
    public int? DocumentId { get; set; }
    public InventoryDocument? Document { get; set; }
}

/// <summary>ردیف سریال — رهگیری یکتای هر دستگاه/واحد کالا</summary>
public class SerialItem
{
    public int Id { get; set; }

    /// <summary>شماره سریال (یکتا در کل سیستم)</summary>
    public string SerialNumber { get; set; } = string.Empty;

    public int ProductId { get; set; }
    public Product Product { get; set; } = null!;

    /// <summary>انبار فعلی (آخرین محل نگهداری)</summary>
    public int WarehouseId { get; set; }
    public Warehouse Warehouse { get; set; } = null!;

    public string? LotNumber { get; set; }
    public DateTime? ExpiryDate { get; set; }

    public Enums.SerialStatus Status { get; set; } = Enums.SerialStatus.InStock;

    /// <summary>سند ورود (ثبت سریال)</summary>
    public int? ReceivedDocumentId { get; set; }
    public InventoryDocument? ReceivedDocument { get; set; }

    /// <summary>سند خروج (صادر شدن)</summary>
    public int? IssuedDocumentId { get; set; }
    public InventoryDocument? IssuedDocument { get; set; }

    public DateTime ReceivedAt { get; set; } = DateTime.Now;
}
