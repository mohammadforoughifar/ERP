namespace Inventory.Domain.Entities;

/// <summary>برگه‌ی انبارگردانی (شمارش فیزیکی)</summary>
public class Stocktake
{
    public int Id { get; set; }

    /// <summary>شماره‌ی برگه (خودکار: STK-سال-توالی)</summary>
    public string Number { get; set; } = string.Empty;

    public int WarehouseId { get; set; }
    public Warehouse Warehouse { get; set; } = null!;

    public DateTime Date { get; set; } = DateTime.Now;

    public Enums.StocktakeStatus Status { get; set; } = Enums.StocktakeStatus.Draft;

    public string? Description { get; set; }

    public string CreatedBy { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; } = DateTime.Now;

    public string? VerifiedBy { get; set; }
    public DateTime? VerifiedAt { get; set; }

    public DateTime? PostedAt { get; set; }

    public ICollection<StocktakeLine> Lines { get; set; } = new List<StocktakeLine>();
}

/// <summary>ردیف انبارگردانی — شمارش فیزیکی یک کالا</summary>
public class StocktakeLine
{
    public int Id { get; set; }
    public int StocktakeId { get; set; }
    public Stocktake Stocktake { get; set; } = null!;

    public int ProductId { get; set; }
    public Product Product { get; set; } = null!;

    /// <summary>موجودی سیستم در لحظه‌ی صدور برگه</summary>
    public decimal BookQuantity { get; set; }

    /// <summary>شمارش اول (توسط شمارنده)</summary>
    public decimal? CountedQuantity { get; set; }

    /// <summary>شمارش دوم (تأیید توسط نفر دوم)</summary>
    public decimal? CountedQuantity2 { get; set; }

    /// <summary>علت مغایرت (تحلیل علت)</summary>
    public string? Reason { get; set; }

    /// <summary>سند تعدیل صادره برای این ردیف (در صورت مغایرت)</summary>
    public int? AdjustmentDocumentId { get; set; }
    public InventoryDocument? AdjustmentDocument { get; set; }

    /// <summary>مغایرت = شمارش تأییدشده منهای موجودی سیستم</summary>
    public decimal Difference => (CountedQuantity2 ?? CountedQuantity ?? 0) - BookQuantity;
}
