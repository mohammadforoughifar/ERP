@echo off
chcp 65001 >nul
title Samane Anbar - ERP Inventory (MRP)
where dotnet >nul 2>nul
if errorlevel 1 (
    echo [.NET 8 SDK peyda nashod] lotfan .NET 8 ra az https://dotnet.microsoft.com/download/dotnet/8.0 nasb konid.
    pause
    exit /b 1
)
cd /d "%~dp0src\Inventory.Web"
echo Samane dar http://localhost:5192 (karbar: admin / ramz: admin123) ...
dotnet run -c Debug --urls http://localhost:5192
pause
