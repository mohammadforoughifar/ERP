// هارنس تست ورود اکسل (گروه/کالا/BOM) + تولید فایل‌های نمونه از دیتاست کارخانه آریا
using Inventory.Application.Common;
using Inventory.Application.DTOs;
using Inventory.Application.Services;
using Inventory.Domain.Entities;
using Inventory.Domain.Enums;
using Inventory.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

var export = new ExcelExportService();
var options = new DbContextOptionsBuilder<AppDbContext>().UseSqlite("Data Source=exceltest.db").Options;
if (File.Exists("exceltest.db")) File.Delete("exceltest.db");
var db = new AppDbContext(options);
db.Database.EnsureCreated();
try { db.Database.ExecuteSqlRaw("CREATE TABLE IF NOT EXISTS AppSettings (Key TEXT NOT NULL PRIMARY KEY, Value TEXT NULL)"); } catch { }

var audit = new AuditService(db);
var importer = new ExcelImportService(db, audit);

int fails = 0;
void Check(string name, bool ok, string detail = "")
{
    Console.WriteLine($"{(ok ? "✅" : "❌")} {name} {(detail == "" ? "" : "— " + detail)}");
    if (!ok) fails++;
}

// ================= فایل‌های نمونه از کاتالوگ دمو =================
// --- گروه‌ها ---
var groupCols = new List<(string, double)> { ("کد گروه", 12), ("نام گروه", 28), ("گروه والد", 14), ("توضیح", 36), ("فعال", 8) };
var groupRows = DemoCatalog.Groups.Select(g => new[]
{
    g.Code, g.Title, g.ParentCode ?? "", g.Desc ?? "", "بله",
}).ToList();
var sampleGroups = export.Build("گروه‌های کالا", groupCols, groupRows);

// --- کالاها ---
var prodCols = new List<(string, double)>
{
    ("کد", 10), ("نام", 32), ("نام لاتین", 22), ("بارکد", 16), ("نوع کالا", 14), ("گروه", 10),
    ("واحد اصلی", 10), ("قیمت خرید", 14), ("قیمت فروش", 14), ("نقطه سفارش", 10), ("حداقل موجودی", 10),
    ("حداکثر موجودی", 10), ("روش ارزشیابی", 14), ("رهگیری سریال", 10), ("رهگیری انقضا", 10), ("رهگیری لوت", 10),
    ("فعال", 8), ("توضیح", 30), ("روش تأمین", 20), ("زمان تحویل (روز)", 10), ("موجودی اطمینان", 10),
    ("سیاست اندازه سفارش", 18), ("تعداد ثابت سفارش", 12), ("حداقل مقدار سفارش", 12), ("درصد ضایعات", 10),
    ("تأمین‌کننده", 12),
};
var prodRows = DemoCatalog.Products.Select(p => new[]
{
    p.Code, p.Name, p.Latin, "", p.Type.Title(), p.GroupCode, p.Unit,
    p.Purchase > 0 ? p.Purchase.ToString("0") : "", p.Sale > 0 ? p.Sale.ToString("0") : "",
    "", "", "", "", "", "", "", "بله", "",
    p.Type == ProductType.RawMaterial ? "خرید از تأمین‌کننده" : "ساخت داخلی (BOM)",
    p.LeadTime.ToString("0"), p.Safety > 0 ? p.Safety.ToString("0") : "",
    p.Lot == LotSizingPolicy.FixedQty ? "تعداد ثابت" : "مقدار به مقدار",
    p.FixedQty > 0 ? p.FixedQty.ToString("0") : "", p.MinOrder > 0 ? p.MinOrder.ToString("0") : "",
    p.Scrap > 0 ? p.Scrap.ToString("0.#") : "", p.VendorCode ?? "",
}).ToList();
var sampleProducts = export.Build("کالاها", prodCols, prodRows);

// --- BOM ---
var bomCols = new List<(string, double)> { ("کد محصول", 14), ("کد قطعه", 14), ("مقدار", 12) };
var bomRows = DemoCatalog.Boms.Select(b => new[]
{
    b.ProductCode, b.ComponentCode, b.Qty.ToString("0.##"),
}).ToList();
var sampleBoms = export.Build("BOM", bomCols, bomRows);

// کپی فایل‌های نمونه: wwwroot/samples + ورک‌اسپیس کاربر
string webroot = "/home/user/ERP/src/Inventory.Web/wwwroot/samples";
string userdir = "/home/user/نمونه-اکسل";
foreach (var dir in new[] { webroot, userdir }) Directory.CreateDirectory(dir);
File.WriteAllBytes(Path.Combine(webroot, "sample-groups.xlsx"), sampleGroups);
File.WriteAllBytes(Path.Combine(webroot, "sample-products.xlsx"), sampleProducts);
File.WriteAllBytes(Path.Combine(webroot, "sample-boms.xlsx"), sampleBoms);
File.WriteAllBytes(Path.Combine(userdir, "نمونه-ورود-گروه-کالا.xlsx"), sampleGroups);
File.WriteAllBytes(Path.Combine(userdir, "نمونه-ورود-کالا.xlsx"), sampleProducts);
File.WriteAllBytes(Path.Combine(userdir, "نمونه-ورود-BOM.xlsx"), sampleBoms);
Console.WriteLine($"📦 نمونه‌ها ذخیره شدند — {groupRows.Count} گروه / {prodRows.Count} کالا / {bomRows.Count} ردیف BOM");

// واحد‌های تکمیلی (در برنامه‌ی واقعی seed شروع می‌سازد؛ اینجا معادلش را دستی اضافه می‌کنیم)
foreach (var (title, cat) in DemoCatalog.ExtraUnits)
    if (db.Units.All(u => u.Title != title))
        db.Units.Add(new Unit { Title = title, Category = cat });
db.SaveChanges();

// ================= ۱) ورود گروه‌ها =================
var r1 = await importer.ImportGroupsAsync(new MemoryStream(sampleGroups), "تستر");
Check("گروه‌ها: موفق", r1.Ok, r1.Message);
Check($"گروه‌ها: {groupRows.Count} جدید، ۰ خطا", r1.Created == groupRows.Count && r1.Errors.Count == 0, $"{r1.Created}/{r1.Errors.Count}");

var g1 = await db.ProductGroups.AsNoTracking().FirstAsync(g => g.Code == "G-01");
var g2 = await db.ProductGroups.AsNoTracking().FirstAsync(g => g.Code == "G-02");
var g6 = await db.ProductGroups.AsNoTracking().FirstAsync(g => g.Code == "G-06");
var g7 = await db.ProductGroups.AsNoTracking().FirstAsync(g => g.Code == "G-07");
Check("گروه‌ها: والدِ میز=G-01 و چوب‌وورق=G-06", g2.ParentId == g1.Id && g7.ParentId == g6.Id);

// ================= ۲) ورود کالاها =================
var r2 = await importer.ImportProductsAsync(new MemoryStream(sampleProducts), "تستر");
var buyCount = DemoCatalog.Products.Count(p => p.Type == ProductType.RawMaterial);
Check("کالاها: موفق", r2.Ok, r2.Message);
Check($"کالاها: {prodRows.Count} جدید، ۰ خطا", r2.Created == prodRows.Count && r2.Errors.Count == 0, $"{r2.Created}/{r2.Errors.Count}");
Check($"کالاها: {buyCount} هشدار تأمین‌کننده‌ی ناموجود", r2.Warnings.Count == buyCount, $"{r2.Warnings.Count}");

var f100 = await db.Products.AsNoTracking().Include(p => p.Group).FirstAsync(p => p.Code == "F-100");
var r104 = await db.Products.AsNoTracking().FirstAsync(p => p.Code == "R-104");
Check("کالا: F-100 محصول نهایی/ساخت/LT=۷/اطمینان=۲/ضایعات=۲٪",
    f100.Type == ProductType.Finished && f100.Procurement == ProcurementType.Make &&
    f100.LeadTimeDays == 7 && f100.SafetyStock == 2 && f100.ScrapPercent == 2m);
Check("کالا: F-100 گروه G-02 و واحد عدد", f100.Group!.Code == "G-02" && f100.MainUnitId == 1);
Check("کالا: R-104 سیاست FOQ=۱۰۰ و واحد کیلوگرم", r104.LotSizing == LotSizingPolicy.FixedQty && r104.FixedOrderQty == 100 && r104.MainUnitId == 2);

// ================= ۳) ورود BOM =================
var r3 = await importer.ImportBomsAsync(new MemoryStream(sampleBoms), "تستر");
Check("BOM: موفق", r3.Ok, r3.Message);
Check("BOM: ۱۱ BOM جدید، ۰ خطا", r3.Created == 11 && r3.Errors.Count == 0, $"{r3.Created}/{r3.Errors.Count}");
Check("BOM: ۳۴ ردیف جزء ثبت شد", await db.BomLines.CountAsync() == 34, $"lines={await db.BomLines.CountAsync()}");

// ================= ۴) ورود مجدد = به‌روزرسانی =================
var r4 = await importer.ImportProductsAsync(new MemoryStream(sampleProducts), "تستر");
Check("کالاها دوباره: ۰ جدید، ۲۶ به‌روزرسانی", r4.Ok && r4.Created == 0 && r4.Updated == 26, $"{r4.Created}/{r4.Updated}");
var r5 = await importer.ImportBomsAsync(new MemoryStream(sampleBoms), "تستر");
Check("BOM دوباره: ۰ جدید، ۱۱ جایگزین و دوبل نشد",
    r5.Ok && r5.Created == 0 && r5.Updated == 11 && await db.BomLines.CountAsync() == 34,
    $"lines={await db.BomLines.CountAsync()}");

// ================= ۵) خطای ردیف، ادامه‌ی بقیه =================
var badRow = prodRows[0].ToArray();
badRow[5] = "G-99"; // گروه ناموجود
var goodRow = prodRows[1].ToArray();
goodRow[0] = "X-NEW1"; // کالای تازه
var badRows = new List<string[]> { badRow, goodRow };
var badFile = export.Build("کالاها", prodCols, badRows);
var r6 = await importer.ImportProductsAsync(new MemoryStream(badFile), "تستر");
Check("ردیف خطادار: ۱ خطا (گروه ناموجود) ولی ۱ کالا وارد شد",
    r6.Ok && r6.Errors.Count == 1 && r6.Created == 1, $"{r6.Errors.Count}خطا/{r6.Created}جدید");

// ================= ۶) فایل خراب =================
var r7 = await importer.ImportGroupsAsync(new MemoryStream(new byte[] { 1, 2, 3, 4, 5 }), "تستر");
Check("فایل خراب: خطای دوستانه", !r7.Ok && r7.Message.Length > 0, r7.Message);

// ================= ۷) فایل بدون سرستون درست =================
var noHead = export.Build("برگه", new List<(string, double)> { ("ستون۱", 10), ("ستون۲", 10) }, new List<string[]> { new[] { "a", "b" } });
var r8 = await importer.ImportBomsAsync(new MemoryStream(noHead), "تستر");
Check("سرستون نامعتبر: پیام راهنما", !r8.Ok && r8.Message.Contains("ستون‌های الزامی"), r8.Message);

Console.WriteLine(fails == 0 ? "\n🎉 همه‌ی تست‌های اکسل سبز" : $"\n💥 {fails} تست قرمز");
return fails == 0 ? 0 : 1;
