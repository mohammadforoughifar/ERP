using Inventory.Application.Common;
using Inventory.Application.DTOs;
using Inventory.Application.Services;
using Inventory.Domain.Entities;
using Inventory.Domain.Enums;
using Inventory.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

var options = new DbContextOptionsBuilder<AppDbContext>()
    .UseSqlite("Data Source=flowtest.db")
    .Options;
var db = new AppDbContext(options);
db.Database.EnsureCreated();

var audit = new AuditService(db);
var documents = new DocumentsService(db, audit);
var poSvc = new PurchaseOrdersService(db, documents, audit);
var priceSvc = new PriceChangeService(db, audit);
var bomSvc = new BomService(db, documents, audit);
var qualitySvc = new QualityService(db, documents, audit);
var mrpSvc = new MrpService(db, audit);
var customersSvc = new CustomersService(db, audit);
var salesOrdersSvc = new SalesOrdersService(db, documents, audit);
var salesInvoicesSvc = new SalesInvoicesService(db, documents, audit);

int pass = 0, fail = 0;
void Check(bool ok, string name)
{
    if (ok) { pass++; Console.WriteLine($"  ✅ {name}"); }
    else { fail++; Console.WriteLine($"  ❌ {name}"); }
}

Console.WriteLine("== Seed ==");
Check(db.Vendors.Count() == 3, $"3 تأمین‌کننده seed شده (واقعی: {db.Vendors.Count()})");
Check(db.StorageBins.Count() == 4, $"4 محل seed شده (واقعی: {db.StorageBins.Count()})");

// کالاهای RM-001 و RM-002 را FIFO کنیم
var rm1 = db.Products.First(p => p.Code == "RM-001");
var rm2 = db.Products.First(p => p.Code == "RM-002");
rm1.ValuationMethod = ValuationMethod.Fifo;
rm2.ValuationMethod = ValuationMethod.Fifo;
await db.SaveChangesAsync();

var rm1Start = (await db.WarehouseItems.Where(w => w.ProductId == rm1.Id && w.WarehouseId == 1)
    .Select(w => w.Quantity).ToListAsync()).Sum();

Console.WriteLine("== سفارش خرید ==");
var po = new PurchaseOrder
{
    VendorId = 1,
    WarehouseId = 1,
    Description = "سفارش تست",
    Lines =
    {
        new PurchaseOrderLine { ProductId = rm1.Id, Quantity = 10, UnitPrice = 1000 },
        new PurchaseOrderLine { ProductId = rm2.Id, Quantity = 5, UnitPrice = 2000 }
    }
};
var r = await poSvc.CreateAsync(po, "testuser");
Check(r.Ok && po.Number.StartsWith("PO-"), $"ایجاد سفارش ({r.Message})");
r = await poSvc.ConfirmAsync(po.Id, "testuser");
Check(r.Ok, $"تأیید سفارش ({r.Message})");
r = await poSvc.ReceiveAsync(po.Id, 10, "testuser"); // 10% تخفیف
Check(r.Ok, $"رسید سفارش ({r.Message})");
Check(po.Status == PurchaseOrderStatus.Received && po.ReceiptDocumentId is not null, "وضعیت سفارش = رسیدشده");

var item1 = await db.WarehouseItems.FirstAsync(w => w.ProductId == rm1.Id && w.WarehouseId == 1);
Check(item1.Quantity == rm1Start + 10, $"موجودی RM-001 = {rm1Start}+10 (واقعی: {item1.Quantity})");
var layer1 = await db.StockBatches.FirstAsync(b => b.ProductId == rm1.Id && b.Quantity > 0);
Check(layer1.UnitCost == 900m, $"لایه FIFO با قیمت 900 پس از تخفیف (واقعی: {layer1.UnitCost})");
rm1 = await db.Products.FindAsync(rm1.Id);
Check(rm1.PurchasePrice == 1000, $"قیمت خرید کالا به‌روزرسانی شد ({rm1.PurchasePrice})");

Console.WriteLine("== خروج FIFO ==");
var issue = new InventoryDocument { Type = DocumentType.SalesIssue, WarehouseId = 1, CreatedBy = "testuser", CreatedAt = DateTime.Now };
r = await documents.CreateAsync(issue, new List<DocumentLineDto> { new(0, rm1.Id, "", "", "", 4, 0, 0, 0) });
r = await documents.ConfirmAsync(issue.Id, new UserInfo("testuser", UserRole.Admin));
Check(r.Ok, $"تأیید حواله ۴ عدد ({r.Message})");
var issueLine = issue.Lines.First();
Check(issueLine.UnitCost == 900m, $"بهای تمام‌شده خروج = 900 (FIFO) (واقعی: {issueLine.UnitCost})");
var layer1b = await db.StockBatches.FirstAsync(b => b.ProductId == rm1.Id && b.Quantity > 0);
Check(layer1b.Quantity == 6, $"لایه باقی‌مانده = 6 (واقعی: {layer1b.Quantity})");

Console.WriteLine("== ورود دوم + خروج چندلایه ==");
var in2 = new InventoryDocument { Type = DocumentType.PurchaseReceipt, WarehouseId = 1, PartyName = "تأمین‌کننده ۲", CreatedBy = "testuser", CreatedAt = DateTime.Now };
r = await documents.CreateAsync(in2, new List<DocumentLineDto> { new(0, rm1.Id, "", "", "", 5, 1500, 0, 0) });
r = await documents.ConfirmAsync(in2.Id, new UserInfo("testuser", UserRole.Admin));
Check(r.Ok, $"ورود ۵ عدد با قیمت ۱۵۰۰");
var issue2 = new InventoryDocument { Type = DocumentType.SalesIssue, WarehouseId = 1, CreatedBy = "testuser", CreatedAt = DateTime.Now };
r = await documents.CreateAsync(issue2, new List<DocumentLineDto> { new(0, rm1.Id, "", "", "", 7, 0, 0, 0) });
r = await documents.ConfirmAsync(issue2.Id, new UserInfo("testuser", UserRole.Admin));
Check(r.Ok, $"خروج ۷ عدد");
var expected = (6m * 900m + 1m * 1500m) / 7m;
Check(Math.Abs(issue2.Lines.First().UnitCost - Math.Round(expected, 2)) < 0.01m,
    $"بهای تمام‌شده ۷ عدد = {Math.Round(expected, 2)} (واقعی: {issue2.Lines.First().UnitCost})");

Console.WriteLine("== تعدیل قیمت ==");
r = await priceSvc.CreateAsync(new PriceChangeDocument { ProductId = rm1.Id, NewPurchasePrice = 2000, NewSalePrice = 2200, Reason = "تست" }, "testuser");
Check(r.Ok, $"سند تعدیل ({r.Message})");
rm1 = await db.Products.FindAsync(rm1.Id);
Check(rm1.PurchasePrice == 2000 && rm1.SalePrice == 2200, $"قیمت‌ها اعمال شد (خرید {rm1.PurchasePrice}، فروش {rm1.SalePrice})");
var pc = await db.PriceChangeDocuments.FirstAsync();
Check(pc.OldPurchasePrice == 1000, $"قیمت قبلی ثبت شد ({pc.OldPurchasePrice})");

Console.WriteLine("== محل نگهداری (Bin) ==");
var rec = new InventoryDocument { Type = DocumentType.PurchaseReceipt, WarehouseId = 1, PartyName = "v", CreatedBy = "testuser", CreatedAt = DateTime.Now };
r = await documents.CreateAsync(rec, new List<DocumentLineDto> { new(0, rm2.Id, "", "", "", 3, 1000, 0, 0, BinId: 1) });
r = await documents.ConfirmAsync(rec.Id, new UserInfo("testuser", UserRole.Admin));
var binStock = await db.BinStocks.FirstAsync(b => b.BinId == 1 && b.ProductId == rm2.Id);
Check(binStock.Quantity == 3, $"ورود به محل A1-01 ثبت شد ({binStock.Quantity})");
var issue3 = new InventoryDocument { Type = DocumentType.SalesIssue, WarehouseId = 1, CreatedBy = "testuser", CreatedAt = DateTime.Now };
r = await documents.CreateAsync(issue3, new List<DocumentLineDto> { new(0, rm2.Id, "", "", "", 5, 0, 0, 0, BinId: 1) });
r = await documents.ConfirmAsync(issue3.Id, new UserInfo("testuser", UserRole.Admin));
Check(!r.Ok, $"خروج بیش از موجودی محل رد شد ({r.Message})");
var issue4 = new InventoryDocument { Type = DocumentType.SalesIssue, WarehouseId = 1, CreatedBy = "testuser", CreatedAt = DateTime.Now };
r = await documents.CreateAsync(issue4, new List<DocumentLineDto> { new(0, rm2.Id, "", "", "", 2, 0, 0, 0, BinId: 1) });
r = await documents.ConfirmAsync(issue4.Id, new UserInfo("testuser", UserRole.Admin));
binStock = await db.BinStocks.FirstAsync(b => b.BinId == 1 && b.ProductId == rm2.Id);
Check(r.Ok && binStock.Quantity == 1, $"خروج ۲ از محل — باقی‌مانده ۱ (واقعی: {binStock.Quantity})");

Console.WriteLine("== کالای مرکب (BOM) و جمع‌آوری ==");
var pr1 = db.Products.First(p => p.Code == "PR-001");
r = await bomSvc.SaveAsync(pr1.Id, "کیت تست", new List<BomLine>
{
    new() { ComponentProductId = rm1.Id, Quantity = 2 },
    new() { ComponentProductId = rm2.Id, Quantity = 1 }
}, "testuser");
Check(r.Ok, $"تعریف BOM ({r.Message})");
r = await bomSvc.AssembleAsync(pr1.Id, 2, "testuser");
Check(r.Ok, $"جمع‌آوری ۲ کیت ({r.Message})");
var pr1Stock = await db.WarehouseItems.FirstAsync(w => w.ProductId == pr1.Id && w.WarehouseId == 1);
Check(pr1Stock.Quantity == 122, $"کالای نهایی وارد شد — 120+2=122 (واقعی: {pr1Stock.Quantity})");
var rm1Stock = await db.WarehouseItems.FirstAsync(w => w.ProductId == rm1.Id && w.WarehouseId == 1);
Check(rm1Stock.Quantity == rm1Start + 10 - 4 - 7 + 5 - 4, $"اجزا خارج شدند — RM-001 = {rm1Start + 10 - 4 - 7 + 5 - 4} (واقعی: {rm1Stock.Quantity})");
// کمبود موجودی → رد
r = await bomSvc.AssembleAsync(pr1.Id, 9999, "testuser");
Check(!r.Ok, $"جمع‌آوری با کمبود موجودی رد شد");

Console.WriteLine("== کنترل کیفیت ==");
var pending = await qualitySvc.GetPendingAsync();
Check(pending.Count >= 2, $"سندهای در انتظار بازرسی ({pending.Count})");
r = await qualitySvc.InspectAsync(in2.Id, QualityStatus.Passed, null, "testuser");
Check(r.Ok, $"قبول بازرسی سند ورود دوم ({r.Message})");
// رسید جدید برای تست رد
var in3 = new InventoryDocument { Type = DocumentType.PurchaseReceipt, WarehouseId = 1, PartyName = "v3", CreatedBy = "testuser", CreatedAt = DateTime.Now };
r = await documents.CreateAsync(in3, new List<DocumentLineDto> { new(0, rm1.Id, "", "", "", 3, 500, 0, 0) });
r = await documents.ConfirmAsync(in3.Id, new UserInfo("testuser", UserRole.Admin));
r = await qualitySvc.InspectAsync(in3.Id, QualityStatus.Rejected, "مغایرت", "testuser");
Check(r.Ok, $"رد بازرسی — سند برگشت صادر شد ({r.Message})");
var returnDoc = await db.InventoryDocuments.FirstOrDefaultAsync(d => d.Description.Contains("برگشت کالای مردودی"));
Check(returnDoc is not null && returnDoc.Status == DocumentStatus.Confirmed, "سند برگشت تأیید شد");
rm1Stock = await db.WarehouseItems.FirstAsync(w => w.ProductId == rm1.Id && w.WarehouseId == 1);
Check(rm1Stock.Quantity == rm1Start + 10 - 4 - 7 + 5 - 4 + 3 - 3, $"موجودی RM-001 پس از برگشت = {rm1Start} (واقعی: {rm1Stock.Quantity})");

Console.WriteLine("== MRP ==");
// BOM برای PR-002 با جزء SP-001 (موجودی اولیه 250 در انبار ۱)
var pr2 = db.Products.First(p => p.Code == "PR-002");
var sp1 = db.Products.First(p => p.Code == "SP-001");
await bomSvc.SaveAsync(pr2.Id, null, new List<BomLine> { new() { ComponentProductId = sp1.Id, Quantity = 1 } }, "testuser");
// سفارش در جریان: ۳۰ عدد
var po2 = new PurchaseOrder { VendorId = 1, WarehouseId = 1, Lines = { new PurchaseOrderLine { ProductId = sp1.Id, Quantity = 30, UnitPrice = 100 } } };
await poSvc.CreateAsync(po2, "testuser");
await poSvc.ConfirmAsync(po2.Id, "testuser");
var mrp = await mrpSvc.CalculateAsync(pr2.Id, 300, "testuser");
var mrpSp1 = mrp.First(m => m.ProductId == sp1.Id);
// تقاضا 300 − موجودی 250 − در جریان 30 = 20
Check(mrpSp1.Suggested == 20, $"پیشنهاد خرید SP-001 = 20 (واقعی: {mrpSp1.Suggested})");

Console.WriteLine("== لاگ حسابرسی ==");
var logs = await audit.GetListAsync(null, null, null, null);
Check(logs.Count >= 12, $"تعداد رکوردهای لاگ: {logs.Count}");
Check(logs.Any(l => l.Action == "رسید" && l.EntityType == "سفارش خرید"), "لاگ رسید سفارش موجود است");
Check(logs.Any(l => l.Action == "تعدیل قیمت"), "لاگ تعدیل قیمت موجود است");
Check(logs.Any(l => l.Action == "بازرسی کیفیت"), "لاگ بازرسی کیفیت موجود است");
Check(logs.Any(l => l.Action == "محاسبه MRP"), "لاگ MRP موجود است");

Console.WriteLine("== چرخه فروش (فاز ۵) ==");
Check(db.Customers.Count() == 2, $"2 مشتری seed شده (واقعی: {db.Customers.Count()})");
var cust1 = db.Customers.First(c => c.Code == "C-001");

var so = new SalesOrder
{
    CustomerId = cust1.Id,
    WarehouseId = 1,
    Description = "سفارش فروش تست",
    Lines =
    {
        new SalesOrderLine { ProductId = rm1.Id, Quantity = 3, UnitPrice = 5000 },
        new SalesOrderLine { ProductId = rm2.Id, Quantity = 2, UnitPrice = 7000 }
    }
};
r = await salesOrdersSvc.CreateAsync(so, "testuser");
Check(r.Ok && so.Number.StartsWith("SO-"), $"ایجاد سفارش فروش ({r.Message})");
r = await salesOrdersSvc.ConfirmAsync(so.Id, "testuser");
Check(r.Ok, $"تأیید سفارش فروش ({r.Message})");

// موجودی قبل از فاکتور (RM-001 در انبار ۱)
var rm1Before = (await db.WarehouseItems.Where(w => w.ProductId == rm1.Id && w.WarehouseId == 1)
    .Select(w => w.Quantity).ToListAsync()).Sum();

r = await salesOrdersSvc.InvoiceAsync(so.Id, 10, "testuser"); // 10% تخفیف
Check(r.Ok, $"صدور فاکتور ({r.Message})");
Check(so.Status == SalesOrderStatus.Invoiced && so.InvoiceId is not null, "وضعیت سفارش = فاکتور شده");

var invoice = await db.SalesInvoices.Include(i => i.Lines).FirstAsync(i => i.OrderId == so.Id);
Check(invoice.Number.StartsWith("INV-"), $"شماره فاکتور ({invoice.Number})");
Check(invoice.DiscountPercent == 10, $"تخفیف ۱۰٪ ثبت شد");
var expectedSubtotal = 3m * 5000m + 2m * 7000m;
var expectedTotal = expectedSubtotal * 0.9m;
Check(invoice.Subtotal == expectedSubtotal, $"جمع کل قبل از تخفیف = {expectedSubtotal} (واقعی: {invoice.Subtotal})");
Check(Math.Abs(invoice.Total - expectedTotal) < 1m, $"مبلغ نهایی = {expectedTotal} (واقعی: {invoice.Total})");

var rm1After = (await db.WarehouseItems.Where(w => w.ProductId == rm1.Id && w.WarehouseId == 1)
    .Select(w => w.Quantity).ToListAsync()).Sum();
Check(rm1After == rm1Before - 3, $"کالا از انبار خارج شد ({rm1Before} → {rm1After})");
var invLine1 = invoice.Lines.First(l => l.ProductId == rm1.Id);
Check(invLine1.UnitPrice == 4500, $"قیمت واحد با تخفیف روی ردیف اعمال شد ({invLine1.UnitPrice})");
Check(invLine1.UnitCost > 0, $"بهای تمام‌شده ثبت شد ({invLine1.UnitCost})");

// صدور فاکتور مجدد رد شود
r = await salesOrdersSvc.InvoiceAsync(so.Id, 0, "testuser");
Check(!r.Ok, "صدور فاکتور مجدد رد شد");

// چاپ: دیتای فاکتور
var invDto = await salesInvoicesSvc.GetAsync(invoice.Id);
Check(invDto is not null && invDto.Lines.Count == 2 && invDto.CustomerName == "بازرگانی امید",
    $"دیتای چاپ فاکتور کامل است ({invDto?.Lines.Count} ردیف)");

// برگشت از فروش
var rm1BeforeReturn = rm1After;
r = await salesInvoicesSvc.ReturnAsync(invoice.Id, "testuser");
Check(r.Ok, $"برگشت از فروش ({r.Message})");
invoice = await db.SalesInvoices.Include(i => i.Lines).FirstAsync(i => i.Id == invoice.Id);
Check(invoice.IsReturned && invoice.ReturnDocumentId is not null, "فاکتور برگشت خورده علامت خورد");
var rm1AfterReturn = (await db.WarehouseItems.Where(w => w.ProductId == rm1.Id && w.WarehouseId == 1)
    .Select(w => w.Quantity).ToListAsync()).Sum();
Check(rm1AfterReturn == rm1BeforeReturn + 3, $"کالا به انبار بازگشت ({rm1BeforeReturn} → {rm1AfterReturn})");
r = await salesInvoicesSvc.ReturnAsync(invoice.Id, "testuser");
Check(!r.Ok, "برگشت مجدد رد شد");
Check((await audit.GetListAsync(null, null, null, null)).Any(l => l.Action == "فاکتور" && l.EntityType == "سفارش فروش"), "لاگ فاکتور موجود است");
Check((await audit.GetListAsync(null, null, null, null)).Any(l => l.Action == "برگشت" && l.EntityType == "فاکتور فروش"), "لاگ برگشت فاکتور موجود است");

Console.WriteLine($"\n===== نتیجه: {pass} قبول، {fail} رد ===== ");
return fail == 0 ? 0 : 1;
