// هارنس تست موتور MRP — سناریوی چندسطحی کامل
using Inventory.Application.Common;
using Inventory.Application.DTOs;
using Inventory.Application.Services;
using Inventory.Domain.Entities;
using Inventory.Domain.Enums;
using Inventory.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

var options = new DbContextOptionsBuilder<AppDbContext>().UseSqlite("Data Source=mrptest.db").Options;
if (File.Exists("mrptest.db")) File.Delete("mrptest.db");
var db = new AppDbContext(options);
db.Database.EnsureCreated();
try { db.Database.ExecuteSqlRaw("CREATE TABLE IF NOT EXISTS AppSettings (Key TEXT NOT NULL PRIMARY KEY, Value TEXT NULL)"); } catch { }

var audit = new AuditService(db);
var docsSvc = new DocumentsService(db, audit, new SettingsService(db));
var poSvc = new PurchaseOrdersService(db, docsSvc, audit);
var mrp = new MrpService(db, audit, poSvc);
var today = DateTime.Today;

int fails = 0;
static string JoinDec(IEnumerable<decimal> xs) => string.Join("، ", xs);
void Check(string name, bool ok, string detail = "")
{
    Console.WriteLine($"{(ok ? "✅" : "❌")} {name} {(detail == "" ? "" : "— " + detail)}");
    if (!ok) fails++;
}

// ---------- داده‌ی آزمایشی ----------
var wh = db.Warehouses.First();
var unit = db.Units.First();
var group = db.ProductGroups.First();

var vendor = new Vendor { Code = "V-MRP", Name = "تأمین‌کننده‌ی MRP", IsActive = true };
var cust = new Customer { Code = "C-MRP", Name = "مشتری MRP", IsActive = true };
db.AddRange(vendor, cust);
db.SaveChanges();

Product P(string code, string name, ProcurementType proc, int lt, decimal safety,
    LotSizingPolicy lot, decimal foq, decimal moq, decimal scrap, int? vendorId) =>
    db.Products.Add(new Product
    {
        Code = code, Name = name, GroupId = group.Id, MainUnitId = unit.Id,
        Procurement = proc, LeadTimeDays = lt, SafetyStock = safety,
        LotSizing = lot, FixedOrderQty = foq, MinOrderQty = moq, ScrapPercent = scrap,
        DefaultVendorId = vendorId,
    }).Entity;

var desk = P("MRP-DESK", "میز تست", ProcurementType.Make, 7, 2, LotSizingPolicy.LotForLot, 0, 0, 10m, null);
var top  = P("MRP-TOP", "صفحه‌ی میز", ProcurementType.Buy, 14, 0, LotSizingPolicy.LotForLot, 0, 0, 0, vendor.Id);
var leg  = P("MRP-LEG", "پایه‌ی میز", ProcurementType.Buy, 7, 5, LotSizingPolicy.LotForLot, 0, 40, 0, vendor.Id);
var bolt = P("MRP-BOLT", "پیچ", ProcurementType.Buy, 1, 0, LotSizingPolicy.FixedQty, 500, 0, 0, vendor.Id);
db.SaveChanges();

var bom = new Bom
{
    ProductId = desk.Id, Title = "BOM میز", IsActive = true,
    Lines = new List<BomLine>
    {
        new() { ComponentProductId = top.Id, Quantity = 1 },
        new() { ComponentProductId = leg.Id, Quantity = 4 },
        new() { ComponentProductId = bolt.Id, Quantity = 8 },
    },
};
db.Boms.Add(bom);

// سفارش فروش تأییدشده: ۱۰ میز در هفته‌ی آینده
var so = new SalesOrder
{
    Number = "SO-MRP-1", Date = today.AddDays(7), CustomerId = cust.Id,
    Status = SalesOrderStatus.Confirmed, CreatedBy = "تست", WarehouseId = wh.Id,
    Lines = new List<SalesOrderLine> { new() { ProductId = desk.Id, Quantity = 10, UnitPrice = 0 } },
};
db.SalesOrders.Add(so);

// سفارش خرید باز تأییدشده: ۲۰ صفحه (تاریخ دیرهنگام → باید پیام «عجیل» بدهد)
var po = new PurchaseOrder
{
    Number = "PO-MRP-1", Date = today.AddDays(10), VendorId = vendor.Id,
    Status = PurchaseOrderStatus.Confirmed, CreatedBy = "تست",
    Lines = new List<PurchaseOrderLine> { new() { ProductId = top.Id, Quantity = 20, UnitPrice = 0, ReceivedQuantity = 0 } },
};
db.PurchaseOrders.Add(po);
db.SaveChanges();

// ---------- اجرا ----------
var input = new MrpRunInput { Weeks = 8, IncludeOpenSalesOrders = true, Title = "تست موتور" };
var summary = await mrp.RunAsync(input, "تستر");
var run = await mrp.GetRunAsync(summary.Id);

Check("اجرا موفق و ذخیره شد", summary.Id > 0, $"Id={summary.Id}");

var deskPlan = run.Plans.FirstOrDefault(p => p.Code == "MRP-DESK");
var topPlan = run.Plans.FirstOrDefault(p => p.Code == "MRP-TOP");
var legPlan = run.Plans.FirstOrDefault(p => p.Code == "MRP-LEG");
var boltPlan = run.Plans.FirstOrDefault(p => p.Code == "MRP-BOLT");

Check("سطوح LLC: میز=۰، اجزا=۱",
    deskPlan?.Level == 0 && topPlan?.Level == 1 && legPlan?.Level == 1 && boltPlan?.Level == 1,
    $"desk={deskPlan?.Level} top={topPlan?.Level}");

// میز: دو سفارش (۲ برای اطمینان هفته ۰ + ۱۰ برای SO هفته ۱) — هر دو آزادسازی هفته ۰
var deskW1 = deskPlan!.Buckets[1];
Check("میز: نیاز ناخالص هفته ۱ = ۱۰", deskW1.Gross == 10, $"{deskW1.Gross}");
Check("میز: خالص کل = ۱۲ (اطمینان+SO)", deskPlan.Buckets.Sum(b => b.Net) == 12,
    JoinDec(deskPlan.Buckets.Select(b => b.Net)));
Check("میز: آزادسازی در هفته ۰ (LT=۷ روز)", deskPlan.Buckets[0].PlannedRelease > 0,
    $"{deskPlan.Buckets[0].PlannedRelease}");

// صفحه: انفجار (۲+۱۰)×۱×۱.۱=۱۳.۲ در هفته ۰ (هر دو آزادسازی) + رسید ۲۰تایی هفته ۴ (روز ۲۴ام)
var topW0 = topPlan!.Buckets[0];
Check("صفحه: نیاز وابسته هفته ۰ = ۱۳.۲ (۱۰٪ ضایعات والد)", topW0.Gross == 13.2m, $"{topW0.Gross}");
Check("صفحه: رسید در راه هفته ۴ = ۲۰", topPlan.Buckets[3].Scheduled == 20, $"{topPlan.Buckets[3].Scheduled}");
Check("صفحه: سفارش پیشنهادی ۱۳.۲", topW0.PlannedReceipt == 13.2m, $"{topW0.PlannedReceipt}");
Check("صفحه: پگینگ به میز", (topPlan.Pegging ?? "").Contains("میز"), topPlan.Pegging ?? "—");

// پایه: ۱۲×۴×۱.۱=۵۲.۸ + اطمینان ۵ → ۵۷.۸ ≥ حداقل ۴۰
var legNet = legPlan!.Buckets.Sum(b => b.Net);
Check("پایه: خالص ۵۷.۸ (≥ حداقل سفارش ۴۰)", legNet == 57.8m, $"{legNet}");

// پیچ: ۱۲×۸=۹۶ → FOQ=۵۰۰
var boltQty = boltPlan!.Buckets.Sum(b => b.PlannedReceipt);
Check("پیچ: سیاست FOQ → ۵۰۰", boltQty == 500, $"{boltQty}");

// پیام اقدام: رسید PO صفحه دیر است → عجیل
var expedite = run.Messages.FirstOrDefault(m => m.Type == "Expedite");
Check("پیام «عجیل» برای PO صفحه", expedite is not null && expedite.ProductName.Contains("صفحه"),
    expedite?.Text ?? "—پیامی نیست—");

// ---------- تبدیل به خرید (گروه‌بندی بر اساس تأمین‌کننده) ----------
var conv = await mrp.ConvertToPurchaseOrdersAsync(summary.Id, "تستر");
Check("تبدیل موفق", conv.Ok, conv.Message);
var run2 = await mrp.GetRunAsync(summary.Id);
Check("۳ سفارش خریدی تبدیل شد (میز=ساخت، حذف)", run2.Orders.Count(o => o.IsConverted) == 3,
    $"{run2.Orders.Count(o => o.IsConverted)}");
Check("میزِ ساختی تبدیل نشد", run2.Orders.First(o => o.Code == "MRP-DESK").IsConverted == false);

// POهای ساخته‌شده: همه برای یک تأمین‌کننده در «یک» سفارش
var newPoIds = run2.Orders.Where(o => o.PurchaseOrderId > 0).Select(o => o.PurchaseOrderId).Distinct().ToList();
Check("گروه‌بندی بر اساس تأمین‌کننده → یک PO", newPoIds.Count == 1, string.Join(",", newPoIds));
if (newPoIds.Count == 1)
{
    var created = await db.PurchaseOrders.Include(p => p.Lines).FirstAsync(p => p.Id == newPoIds[0]);
    Check("PO ساخته‌شده ۳ ردیف دارد", created.Lines.Count == 3, $"{created.Lines.Count}");
    Check("PO تأمین‌کننده‌ی پیش‌فرض", created.VendorId == vendor.Id);
    Check("PO توضیح MRP", (created.Description ?? "").Contains("MRP"), created.Description ?? "—");
}

// تبدیل دوباره → نباید چیزی اضافه کند
var conv2 = await mrp.ConvertToPurchaseOrdersAsync(summary.Id, "تستر");
var poCount = await db.PurchaseOrders.CountAsync(p => (p.Description ?? "").Contains("MRP"));
Check("تبدیل تکراری: PO جدیدی نساخت", conv2.Ok && poCount == 1, $"count={poCount}");

// ---------- نیاز دستی + سیاست L4L بدون SO ----------
var input2 = new MrpRunInput
{
    Weeks = 4, IncludeOpenSalesOrders = false, Title = "دستی",
    ManualDemands = { new MrpDemandInput(leg.Id, 10, today.AddDays(3), "سفارش ویژه") },
};
var sum2 = await mrp.RunAsync(input2, "تستر");
var run3 = await mrp.GetRunAsync(sum2.Id);
var legOnly = run3.Plans.First(p => p.Code == "MRP-LEG");
// ۱۰ دستی + ۸.۸ انفجار میزِ اطمینانی (۲×۴×۱.۱) + ۵ اطمینان = ۲۳.۸
Check("دستی: پایه خالص هفته ۰ = ۲۳.۸ (۱۰+۸.۸+۵)", legOnly.Buckets[0].Net == 23.8m, $"{legOnly.Buckets[0].Net}");

Console.WriteLine(fails == 0 ? "\n🎉 همه‌ی تست‌ها سبز" : $"\n💥 {fails} تست قرمز");
return fails == 0 ? 0 : 1;
