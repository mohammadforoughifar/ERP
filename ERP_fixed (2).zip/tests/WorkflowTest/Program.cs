// هارنس تست موتور گردش کار خرید — طراحی، شرط مبلغ، گام‌خوری، تأیید/رد، اتصال به تأیید PO
using Inventory.Application.Common;
using Inventory.Application.DTOs;
using Inventory.Application.Services;
using Inventory.Domain.Entities;
using Inventory.Domain.Enums;
using Inventory.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

var options = new DbContextOptionsBuilder<AppDbContext>().UseSqlite("Data Source=wftest.db").Options;
if (File.Exists("wftest.db")) File.Delete("wftest.db");
var db = new AppDbContext(options);
db.Database.EnsureCreated();
try { db.Database.ExecuteSqlRaw("CREATE TABLE IF NOT EXISTS AppSettings (Key TEXT NOT NULL PRIMARY KEY, Value TEXT NULL)"); } catch { }

var audit = new AuditService(db);
var settings = new SettingsService(db);
var docs = new DocumentsService(db, audit, settings);
var poSvc = new PurchaseOrdersService(db, docs, audit);
var wf = new WorkflowService(db, audit, poSvc);

var admin = new UserInfo("admin", UserRole.Admin);
var accountant = new UserInfo("acc", UserRole.Accountant);
var store = new UserInfo("store", UserRole.Storekeeper);

int fails = 0;
void Check(string name, bool ok, string detail = "")
{
    Console.WriteLine($"{(ok ? "✅" : "❌")} {name} {(detail == "" ? "" : "— " + detail)}");
    if (!ok) fails++;
}

// ---------- داده ----------
var vendor = db.Vendors.Add(new Vendor { Code = "V-WF", Name = "تأمین‌کننده WF", IsActive = true }).Entity;
var grp = db.ProductGroups.Add(new ProductGroup { Title = "گروه تست", Code = "G-WF" }).Entity;
db.SaveChanges();
var unit = db.Units.Add(new Unit { Title = "عدد", Category = UnitCategory.Count, Factor = 1 }).Entity;
db.SaveChanges();
var prod = db.Products.Add(new Product { Code = "P-WF", Name = "کالای تست", GroupId = grp.Id, MainUnitId = unit.Id, Type = ProductType.RawMaterial, IsActive = true }).Entity;
db.SaveChanges();
PurchaseOrder MakePo(string number, decimal qty, decimal price)
{
    var po = new PurchaseOrder
    {
        Number = number, Date = DateTime.Now, VendorId = vendor.Id, Status = PurchaseOrderStatus.Draft, CreatedBy = "تست",
        Lines = new List<PurchaseOrderLine> { new() { ProductId = db.Products.First().Id, Quantity = qty, UnitPrice = price } },
    };
    db.PurchaseOrders.Add(po);
    db.SaveChanges();
    return po;
}

// ---------- ۱) طراحی ----------
var def = new WorkflowDefDto
{
    Name = "گردش خرید تست", DocType = WorkflowService.PurchaseOrderDocType, IsActive = true,
    Steps = new()
    {
        new() { OrderIndex = 0, Title = "بررسی مالی", ApproverRole = UserRole.Accountant },
        new() { OrderIndex = 1, Title = "تأیید مدیریت", ApproverRole = UserRole.Admin, MinAmount = 300_000_000m },
    },
};
var r1 = await wf.SaveDefAsync(def, "admin");
Check("طراحی گردش ۲ گامی", r1.Ok, r1.Message);
Check("گردشِ فعال تکی است", await db.WorkflowDefs.CountAsync(d => d.IsActive) == 1);

var r1b = await wf.SaveDefAsync(new WorkflowDefDto
{
    Name = "گردش بد", DocType = WorkflowService.PurchaseOrderDocType,
    Steps = new() { new() { Title = "بدون تأییدکننده" } },
}, "admin");
Check("گام بدون نقش/کاربر رد می‌شود", !r1b.Ok);
var r1c = await wf.SaveDefAsync(new WorkflowDefDto { Name = "خالی", DocType = WorkflowService.PurchaseOrderDocType }, "admin");
Check("گردش بدون گام رد می‌شود", !r1c.Ok);
Check("HasActive", await wf.HasActiveAsync(WorkflowService.PurchaseOrderDocType));

// ---------- ۲) ارسال — شرط مبلغ: PO کوچک → گام مدیر عبور می‌شود ----------
var poSmall = MakePo("WF-001", 10, 1_000_000m); // ۱۰M < ۳۰۰M
var r2 = await wf.SubmitAsync(WorkflowService.PurchaseOrderDocType, poSmall.Id, store);
Check("ارسال PO کوچک", r2.Ok, r2.Message);
var inst = await wf.GetForEntityAsync(WorkflowService.PurchaseOrderDocType, poSmall.Id);
Check("پلان کوچک: فقط گام حسابدار (مدیر عبور)", inst!.Steps.Count == 1 && inst.Steps[0].Title == "بررسی مالی" && inst.Status == WorkflowRunStatus.InProgress,
    $"steps={inst.Steps.Count}");

// تأیید توسط اشتباه → رد می‌شود
var rWrong = await wf.ActAsync(inst.Id, true, null, store);
Check("تأیید توسط انباردار (گام حسابدار) رد می‌شود", !rWrong.Ok, rWrong.Message);

// تأیید توسط حسابدار → چون گام دوم عبور کرده، باید تأیید نهایی شود
var rFinal = await wf.ActAsync(inst.Id, true, "قیمت‌ها چک شد", accountant);
Check("تأیید حسابدار → تأیید نهایی (گام مدیر skip)", rFinal.Ok && rFinal.Message.Contains("نهایی"), rFinal.Message);
var poSmall2 = await db.PurchaseOrders.AsNoTracking().FirstAsync(p => p.Id == poSmall.Id);
Check("PO کوچک خودکار Confirmed شد", poSmall2.Status == PurchaseOrderStatus.Confirmed);
var instDone = await wf.GetForEntityAsync(WorkflowService.PurchaseOrderDocType, poSmall.Id);
Check("تایم‌لاین: عبور از گام ثبت شده", instDone!.Logs.Any(l => l.Action.Contains("عبور")));

// ---------- ۳) PO بزرگ → هر دو گام ----------
var poBig = MakePo("WF-002", 1000, 1_000_000m); // ۱۰۰۰M ≥ ۳۰۰M
await wf.SubmitAsync(WorkflowService.PurchaseOrderDocType, poBig.Id, store);
var instBig = await wf.GetForEntityAsync(WorkflowService.PurchaseOrderDocType, poBig.Id);
Check("پلان بزرگ: ۲ گام، گام فعلی = بررسی مالی",
    instBig!.Steps.Count == 2 && instBig.CurrentStepTitle == "بررسی مالی" &&
    instBig.Steps[0].State == WorkflowStepState.Current && instBig.Steps[1].State == WorkflowStepState.Pending);

var pendAcc = await wf.PendingForMeAsync(accountant);
Check("PendingForMe حسابدار شامل WF-002", pendAcc.Any(p => p.DocNumber == "WF-002"));
var pendAdm = await wf.PendingForMeAsync(admin);
Check("PendingForMe مدیر هنوز WF-002 را ندارد", !pendAdm.Any(p => p.DocNumber == "WF-002"));

// ---------- ۴) مسیر رد ----------
var rRej = await wf.ActAsync(instBig.Id, false, "گرون است", accountant);
Check("رد توسط حسابدار", rRej.Ok);
var poBigAfter = await db.PurchaseOrders.AsNoTracking().FirstAsync(p => p.Id == poBig.Id);
Check("PO بزرگ Draft ماند", poBigAfter.Status == PurchaseOrderStatus.Draft);
var instRej = await wf.GetForEntityAsync(WorkflowService.PurchaseOrderDocType, poBig.Id);
Check("وضعیت گردش = رد شده + یادداشت در تاریخچه",
    instRej!.Status == WorkflowRunStatus.Rejected && instRej.Logs.Any(l => l.Comment == "گرون است"));

// ارسال مجدد بعد از رد + مسیر کامل تأیید
var rResub = await wf.SubmitAsync(WorkflowService.PurchaseOrderDocType, poBig.Id, store);
Check("ارسال مجدد بعد از رد", rResub.Ok);
var inst2 = await wf.GetForEntityAsync(WorkflowService.PurchaseOrderDocType, poBig.Id);
await wf.ActAsync(inst2!.Id, true, "تخفیف گرفتیم", accountant);
var rBig = await wf.ActAsync(inst2.Id, true, null, admin);
Check("تأیید گام دوم توسط مدیر → نهایی", rBig.Ok && rBig.Message.Contains("نهایی"), rBig.Message);
var poBigFinal = await db.PurchaseOrders.AsNoTracking().FirstAsync(p => p.Id == poBig.Id);
Check("PO بزرگ Confirmed شد", poBigFinal.Status == PurchaseOrderStatus.Confirmed);

// ---------- ۵) گام با کاربر خاص ----------
await wf.SaveDefAsync(new WorkflowDefDto
{
    Name = "گردش کاربر خاص", DocType = WorkflowService.PurchaseOrderDocType, IsActive = true,
    Steps = new() { new() { Title = "مجوز انبار", ApproverUserName = "store" } },
}, "admin");
var po3 = MakePo("WF-003", 1, 500_000m);
await wf.SubmitAsync(WorkflowService.PurchaseOrderDocType, po3.Id, store);
var inst3 = await wf.GetForEntityAsync(WorkflowService.PurchaseOrderDocType, po3.Id);
var rWrongUser = await wf.ActAsync(inst3!.Id, true, null, accountant);
Check("گام کاربر خاص: حسابدار مجاز نیست", !rWrongUser.Ok);
var rRight = await wf.ActAsync(inst3.Id, true, null, store);
Check("گام کاربر خاص: خود کاربر تأیید کرد", rRight.Ok);

// ---------- ۶) لغو توسط فرستنده ----------
var po4 = MakePo("WF-004", 5, 900_000m);
await wf.SubmitAsync(WorkflowService.PurchaseOrderDocType, po4.Id, store);
var inst4 = await wf.GetForEntityAsync(WorkflowService.PurchaseOrderDocType, po4.Id);
var rCancel = await wf.CancelAsync(inst4!.Id, store);
Check("لغو توسط فرستنده", rCancel.Ok);
var rCancel2 = await wf.ActAsync(inst4.Id, true, null, store);
Check("بعد از لغو، تأیید ممکن نیست", !rCancel2.Ok);

// ---------- ۷) حذف گردشِ در جریان مسدود ----------
var po5 = MakePo("WF-005", 2, 700_000m);
await wf.SubmitAsync(WorkflowService.PurchaseOrderDocType, po5.Id, store);
var defs = await wf.GetDefsAsync();
var active = defs.First(d => d.IsActive);
var rDel = await wf.DeleteDefAsync(active.Id, "admin");
Check("حذف گردشِ دارای نمونه‌ی در جریان مسدود است", !rDel.Ok, rDel.Message);

Console.WriteLine(fails == 0 ? "\n🎉 همه‌ی تست‌های گردش کار سبز" : $"\n💥 {fails} تست قرمز");
return fails == 0 ? 0 : 1;
