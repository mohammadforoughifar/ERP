using Inventory.Application.Common;
using Inventory.Application.DTOs;
using Inventory.Application.Services;
using Inventory.Domain.Entities;
using Inventory.Domain.Enums;
using Inventory.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

var options = new DbContextOptionsBuilder<AppDbContext>().UseSqlite("Data Source=behavtest.db").Options;
var db = new AppDbContext(options);
db.Database.EnsureCreated();
try { db.Database.ExecuteSqlRaw("CREATE TABLE IF NOT EXISTS AppSettings (Key TEXT NOT NULL PRIMARY KEY, Value TEXT NULL)"); } catch { }

var settings = new SettingsService(db);
var audit = new AuditService(db);
var docs = new DocumentsService(db, audit, settings);
var user = new UserInfo("تستر", UserRole.Admin);

DocumentLineDto Dto(int pid, decimal qty, decimal price = 10000) => new(0, pid, "", "", "", qty, price, 0, qty * price);


var wh = db.Warehouses.First();
var unit = db.Units.First();
var prod = db.Products.Add(new Product { Code = "TP" + DateTime.Now.Ticks % 10000, Name = "کالای تست", GroupId = db.ProductGroups.First().Id, MainUnitId = unit.Id, ValuationMethod = ValuationMethod.Average, TrackLot = false, TrackExpiry = false, TrackSerial = false }).Entity;
db.SaveChanges();

var receipt = new InventoryDocument { Number = "R-1", Date = DateTime.Now, Type = DocumentType.OpeningReceipt, Status = DocumentStatus.Draft, WarehouseId = wh.Id, Description = "تست" };
var cr0 = await docs.CreateAsync(receipt, new() { Dto(prod.Id, 5) });
Console.WriteLine($"0) ایجاد رسید: {cr0.Ok} — {cr0.Message} | Id={receipt.Id}");
var r1 = await docs.ConfirmAsync(receipt.Id, user);
Console.WriteLine($"1) رسید اولیه ۵ عدد: {r1.Ok} — {r1.Message}");

var issue = new InventoryDocument { Number = "I-1", Date = DateTime.Now, Type = DocumentType.SalesIssue, Status = DocumentStatus.Draft, WarehouseId = wh.Id };
await docs.CreateAsync(issue, new() { Dto(prod.Id, 3) });
var r2 = await docs.ConfirmAsync(issue.Id, user);
Console.WriteLine($"2) حواله ۳ عدد (باید موفق): {r2.Ok} — {r2.Message}");

var issue2 = new InventoryDocument { Number = "I-2", Date = DateTime.Now, Type = DocumentType.SalesIssue, Status = DocumentStatus.Draft, WarehouseId = wh.Id };
await docs.CreateAsync(issue2, new() { Dto(prod.Id, 10) });
var r3 = await docs.ConfirmAsync(issue2.Id, user);
Console.WriteLine($"3) حواله ۱۰ عدد با موجودی ۲ (باید رد شود): Ok={r3.Ok} — {r3.Message}");

await settings.SetAllowNegativeStockAsync(true);
var r4 = await docs.ConfirmAsync(issue2.Id, user);
var stockNeg = db.WarehouseItems.First(w => w.ProductId == prod.Id && w.WarehouseId == wh.Id).Quantity;
Console.WriteLine($"4) با مجوز منفی (باید موفق): {r4.Ok} — موجودی الان: {stockNeg}");
await settings.SetAllowNegativeStockAsync(false);

var before = db.WarehouseItems.First(w => w.ProductId == prod.Id && w.WarehouseId == wh.Id).Quantity;
var cons = new InventoryDocument { Number = "C-1", Date = DateTime.Now, Type = DocumentType.ConsignmentReceipt, Status = DocumentStatus.Draft, WarehouseId = wh.Id };
await docs.CreateAsync(cons, new() { Dto(prod.Id, 100) });
var r5 = await docs.ConfirmAsync(cons.Id, user);
var after = db.WarehouseItems.First(w => w.ProductId == prod.Id && w.WarehouseId == wh.Id).Quantity;
Console.WriteLine($"5) سند امانی ۱۰۰ عدد (موجودی ثابت بماند): {r5.Ok} — {r5.Message} | {before} → {after}");

await settings.SetStockEffectAsync(DocumentType.ConsignmentReceipt, true);
var cons2 = new InventoryDocument { Number = "C-2", Date = DateTime.Now, Type = DocumentType.ConsignmentReceipt, Status = DocumentStatus.Draft, WarehouseId = wh.Id };
await docs.CreateAsync(cons2, new() { Dto(prod.Id, 2) });
var r6 = await docs.ConfirmAsync(cons2.Id, user);
var after2 = db.WarehouseItems.First(w => w.ProductId == prod.Id && w.WarehouseId == wh.Id).Quantity;
Console.WriteLine($"6) امانی بعد از تغییر ماهیت (+۲ شود): {r6.Ok} — {after} → {after2}");

Console.WriteLine("=== DONE ===");
