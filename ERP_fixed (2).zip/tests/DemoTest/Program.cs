// هارنس تست دیتاست دموی کارخانه آریا → MRP چندسطحی واقعی
using Inventory.Application.Common;
using Inventory.Application.DTOs;
using Inventory.Application.Services;
using Inventory.Domain.Entities;
using Inventory.Domain.Enums;
using Inventory.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

var options = new DbContextOptionsBuilder<AppDbContext>().UseSqlite("Data Source=demotest.db").Options;
if (File.Exists("demotest.db")) File.Delete("demotest.db");
var db = new AppDbContext(options);
db.Database.EnsureCreated();
try { db.Database.ExecuteSqlRaw("CREATE TABLE IF NOT EXISTS AppSettings (Key TEXT NOT NULL PRIMARY KEY, Value TEXT NULL)"); } catch { }

var audit = new AuditService(db);
var settings = new SettingsService(db);
var docs = new DocumentsService(db, audit, settings);
var poSvc = new PurchaseOrdersService(db, docs, audit);
var soSvc = new SalesOrdersService(db, docs, audit);
var mrp = new MrpService(db, audit, poSvc);
var demo = new DemoDataService(db, docs, poSvc, soSvc, mrp, audit);

int fails = 0;
void Check(string name, bool ok, string detail = "")
{
    Console.WriteLine($"{(ok ? "✅" : "❌")} {name} {(detail == "" ? "" : "— " + detail)}");
    if (!ok) fails++;
}

// ================= ۱) Seed =================
var seeded = await demo.SeedIfEmptyAsync();
Check("Seed اجرا شد", seeded);

Check("۲۶ کالای دمو ساخته شد", await db.Products.CountAsync(p => p.Code.StartsWith("F-") || p.Code.StartsWith("S-") || p.Code.StartsWith("R-")) == 26,
    $"{await db.Products.CountAsync(p => p.Code.StartsWith("F-") || p.Code.StartsWith("S-") || p.Code.StartsWith("R-"))}");
var nGroups = await db.ProductGroups.CountAsync(g => g.Code.StartsWith("G-"));
var demoVCodes = new[] { "V-01", "V-02", "V-03", "V-04" };
var demoCCodes = new[] { "C-01", "C-02", "C-03", "C-04" };
var nVendors = await db.Vendors.CountAsync(v => demoVCodes.Contains(v.Code));
var nCust = await db.Customers.CountAsync(c => demoCCodes.Contains(c.Code));
Check("۱۰ گروه + ۴ تأمین‌کننده + ۴ مشتری دمو", nGroups == 10 && nVendors == 4 && nCust == 4,
    $"g={nGroups} v={nVendors} c={nCust}");
Check("۱۱ BOM با ۳۴ ردیف",
    await db.Boms.CountAsync(b => b.Title.StartsWith("BOM ")) == 11 &&
    await db.BomLines.CountAsync() == 34,
    $"boms={await db.Boms.CountAsync()} lines={await db.BomLines.CountAsync()}");

var r101 = await db.Products.AsNoTracking().FirstAsync(p => p.Code == "R-101");
Check("R-101: خرید/LT=۱۴/اطمینان=۶/حداقل‌سفارش=۱۰/تأمین‌کننده‌ی V-01",
    r101.Procurement == ProcurementType.Buy && r101.LeadTimeDays == 14 && r101.SafetyStock == 6 &&
    r101.MinOrderQty == 10 && r101.DefaultVendorId is { } && r101.MainUnitId > 0);
var r101Stock = (await db.WarehouseItems.Where(w => w.ProductId == r101.Id).ToListAsync()).Sum(w => w.Quantity);
Check("موجودی افتتاحیه: R-101=۱۸ شیت در انبار مواد", r101Stock == 18, $"{r101Stock}");
Check("۳ سفارش فروش + ۲ سفارش خرید باز تأییدشده",
    await db.SalesOrders.CountAsync(o => o.Status == SalesOrderStatus.Confirmed && o.Lines.Any(l => l.Product!.Code.StartsWith("F-"))) == 3 &&
    await db.PurchaseOrders.CountAsync(o => o.Status == PurchaseOrderStatus.Confirmed && o.Lines.Any(l => l.Product!.Code.StartsWith("R-"))) == 2);

// اجرای آماده‌ی MRP
var savedRuns = await db.MrpRuns.CountAsync();
Check("یک اجرای MRP آماده ذخیره شد", savedRuns == 1, $"{savedRuns}");

// ================= ۲) Idempotent =================
var again = await demo.SeedIfEmptyAsync();
Check("Seed دوم اجرا نمی‌شود (کلید دمو)", again == false &&
    await db.Products.CountAsync(p => p.Code == "F-100") == 1);

// ================= ۳) اجرای دستی MRP و بررسی عمق انفجار =================
var sum = await mrp.RunAsync(new MrpRunInput { Weeks = 12, IncludeOpenSalesOrders = true, Title = "تست دمو" }, "تستر");
var run = await mrp.GetRunAsync(sum.Id);

var f100 = run.Plans.FirstOrDefault(p => p.Code == "F-100");
var s101 = run.Plans.FirstOrDefault(p => p.Code == "S-101");
var r101Plan = run.Plans.FirstOrDefault(p => p.Code == "R-101");
Check("سطوح LLC: محصول=۰، نیم‌ساخت=۱، مواد=۲",
    f100?.Level == 0 && s101?.Level == 1 && r101Plan?.Level == 2,
    $"F={f100?.Level} S={s101?.Level} R={r101Plan?.Level}");

// F-100: نیاز = ۳۰ (۲۰+۱۰) − موجودی ۵ − اطمینان ۲ = خالص ۲۷
Check("F-100 خالص = ۲۷", f100!.Buckets.Sum(b => b.Net) == 27, $"{f100.Buckets.Sum(b => b.Net)}");
// S-101: انفجار از «آزادسازی‌های واقعی» F-100 × (۱+۲٪ ضایعات میز) − موجودی ۳
var f100Releases = f100.Buckets.Sum(b => b.PlannedRelease);
var sNet = s101!.Buckets.Sum(b => b.Net);
Check("S-101 خالص = انفجار آزادسازی میز×۱.۰۲ − موجودی ۳",
    sNet == f100Releases * 1.02m - 3m, $"releases={f100Releases} net={sNet}");
// R-101: (S-101: ۲۵.۳۵×۰.۶ + S-103: خالص ۴×۱.۰۵×۱.۶ + S-301: خالص ۱۶×۱.۰۵×۲.۲)×... + اطمینان ۶ − موجودی ۱۸
var rNet = r101Plan!.Buckets.Sum(b => b.Net);
Check("R-101 نیاز خالص سطح ۲ مثبت (انفجار چندسطحی کار می‌کند)", rNet > 20,
    $"{rNet} — پگینگ: {r101Plan.Pegging}");
Check("پگینگ R-101 به نیم‌ساخت/محصول اشاره دارد",
    (r101Plan.Pegging ?? "").Contains("صفحه") || (r101Plan.Pegging ?? "").Contains("میز"),
    r101Plan.Pegging ?? "—");

Check("سفارش‌های پیشنهادی زیاد (≥ ۱۵ قلم کالا)", run.Plans.Count(p => p.TotalNet > 0) >= 15,
    $"{run.Plans.Count(p => p.TotalNet > 0)} کالا");
Check("پیام «عجیل» برای رسید دیرهنگام MDF",
    run.Messages.Any(m => m.Type == "Expedite" && m.ProductName.Contains("MDF")),
    string.Join(" | ", run.Messages.Select(m => $"{m.Type}:{m.ProductName}")));

// ================= ۴) تبدیل به خرید — گروه‌بندی ۴ تأمین‌کننده =================
var conv = await mrp.ConvertToPurchaseOrdersAsync(sum.Id, "تستر");
Check("تبدیل موفق", conv.Ok, conv.Message);
var run2 = await mrp.GetRunAsync(sum.Id);
var buyOrders = run2.Orders.Where(o => o.Type == ProcurementType.Buy).ToList();
Check("همه‌ی سفارش‌های خریدی تبدیل شدند (بدون هشدار تأمین‌کننده)", buyOrders.All(o => o.IsConverted),
    $"{buyOrders.Count(o => o.IsConverted)}/{buyOrders.Count}");
var newPoCount = await db.PurchaseOrders.CountAsync(p => (p.Description ?? "").Contains("از MRP"));
Check("سفارش‌ها بر اساس تأمین‌کننده گروه شدند (≤۴ PO)", newPoCount is >= 2 and <= 4, $"{newPoCount} PO");

// ================= ۴ب) رگرسیون NRE: لیست سفارش‌های خرید/فروش (Include ناقص MainUnit) =================
var poList = await poSvc.GetListAsync();
Check("GetListAsync خرید بدون خطا و واحد پر", poList.Count >= 2 &&
    poList.All(o => o.Lines.All(l => l.UnitTitle != null)), $"{poList.Count} سفارش");
var soList = await soSvc.GetListAsync();
Check("GetListAsync فروش بدون خطا و واحد پر", soList.Count >= 3 &&
    soList.All(o => o.Lines.All(l => !string.IsNullOrEmpty(l.UnitTitle))), $"{soList.Count} سفارش");

// ================= ۵) Reset =================
var reset = await demo.ResetAsync();
Check("Reset: دموی تازه ساخته شد", reset &&
    await db.Products.CountAsync(p => p.Code == "F-100") == 1 &&
    await db.MrpRuns.CountAsync() == 1 &&
    await db.BomLines.CountAsync() == 34);

Console.WriteLine(fails == 0 ? "\n🎉 همه‌ی تست‌های دمو سبز" : $"\n💥 {fails} تست قرمز");
return fails == 0 ? 0 : 1;
